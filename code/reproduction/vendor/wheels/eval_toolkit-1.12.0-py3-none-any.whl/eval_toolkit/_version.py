"""Single lightweight version source."""

__all__ = ["__version__"]

__version__ = "1.12.0"
