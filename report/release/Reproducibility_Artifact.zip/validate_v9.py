"""Reconcile paired API costs and verify the Boolean index's domain semantics."""
from pathlib import Path
from fractions import Fraction as F
import json,csv,hashlib,statistics
import numpy as np
from boolean_query_study import METHODS
from reuse_cost_study import CASE_IDS,BATCHES,plans,direct_answer
from scipy_documented_defect import functions,cases
from independent_oracle import candidates,select
from policy_exact import DEFAULT
from policy_domain_query import answer,contains
from domain_query_study import queries
from verified_boolean_query import VerifiedBooleanIndex
Q=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):return list(csv.DictReader(p.open(encoding='utf-8')))
def allowed(q,value):
    if q['kind']=='finite':return value in map(F,q['values'])
    return contains(q,value) and (q['kind']!='lattice' or (value*10**q['decimal_places']).denominator==1)
def main():
    R=Q/'results/v9';prior=Q/'evidence/V8_FINAL_RELEASE_EVIDENCE';report=read(prior/'RELEASE_VERIFICATION.json')
    assert report['status']=='PASS' and len(report['stages'])==31 and all(s['exit_code']==0 for s in report['stages'])
    assert report['archive_sha256_before']==report['archive_sha256_after']=='c196b5f591c9ee48e9e7d8fa6e72431204e05195b7ee7ed5365ed7742d6735ab'
    certificate_stage=next(s for s in report['stages'] if s['stage']=='independent_certificate_audit');assert certificate_stage['exit_code']==0
    for name,digest in read(prior/'EVIDENCE_MANIFEST.json').items():assert sha(prior/name)==digest
    summary=read(R/'boolean_cost_summary.json');raw=rows(R/'boolean_raw.csv');groups=rows(R/'boolean_summary.csv');saved_plans=read(R/'boolean_query_plans.json')
    assert summary['status']=='PASS' and summary['smt_unknown']==0 and len(raw)==960 and len(groups)==192 and summary['matched_method_answers']==40560
    for key,file in [('source_sha256','boolean_query_study.py'),('index_source_sha256','verified_boolean_query.py'),('v8_baseline_source_sha256','reuse_cost_study.py')]:assert summary[key]==sha(Q/file)
    assert len({(r['case_id'],r['kind'],r['batch'],r['replicate'],r['method']) for r in raw})==960
    for row in raw:
        a,b,t=map(float,[row['setup_ms'],row['queries_ms'],row['total_ms']]);assert min(a,b,t)>=0 and abs(a+b-t)<1e-8
        p=R/'boolean_outputs'/row['output_file'];assert sha(p)==row['output_sha256'];out=read(p);key=f"{row['case_id']}__{row['kind']}__b{row['batch']}"
        assert len(out)==int(row['batch']) and [r['affected'] for r in out]==saved_plans[key]['expected']
        assert int(row['affected_queries'])==sum(saved_plans[key]['expected'])
    for row in groups:
        selected=[r for r in raw if all(r[k]==row[k] for k in ['case_id','kind','batch','method'])];assert len(selected)==5 and {int(r['replicate']) for r in selected}==set(range(5))
        for phase in ['setup_ms','queries_ms','total_ms']:
            values=[float(r[phase]) for r in selected]
            assert float(row['median_'+phase])==statistics.median(values) and float(row['iqr_'+phase])==float(np.quantile(values,.75)-np.quantile(values,.25))
    lookup={(r['case_id'],r['kind'],int(r['batch']),r['method']):r for r in groups}
    for r in summary['paired_certificate_comparisons']:
        old=lookup[r['case_id'],r['kind'],128,'checked_certificate'];new=lookup[r['case_id'],r['kind'],128,'boolean_certificate']
        assert r['query_phase_speedup']==float(old['median_queries_ms'])/float(new['median_queries_ms'])
        assert r['total_speedup']==float(old['median_total_ms'])/float(new['median_total_ms'])
    for r in summary['workflow_comparisons']:
        wins=sum(float(lookup[name,r['kind'],r['batch'],'boolean_certificate']['median_total_ms'])<float(lookup[name,r['kind'],r['batch'],r['comparator']]['median_total_ms']) for name in CASE_IDS)
        assert wins==r['boolean_certificate_faster_total_cases'] and r['assurance_matched']==(r['comparator']=='checked_certificate')
    funcs,_,_=functions();count=0;witnesses=0
    for name,x,scores,y,ids,rec in cases():
        old=funcs['fixed'](x,scores,kind='nearest')(x);new=funcs['affected'](x,scores,kind='nearest')(x)
        wrapper=read(Q/'results/v6/scipy_defect_certificates'/(name+'_affected.json'));index=VerifiedBooleanIndex(y,old,new,ids,wrapper['certificate'])
        a=candidates(y,old,DEFAULT);b=candidates(y,new,DEFAULT);positive=bool(y.sum());breaks=sorted({p for p,k,n,bits in a+b})
        # All original V7 finite/lattice/interval scenarios, with exact lattice witnesses.
        for label,q in queries():
            actual=index.query(q);expected=answer(wrapper['certificate'],q);assert actual['affected']==expected['affected'];count+=1
            if actual['witness'] is not None:
                value=F(actual['witness']);assert allowed(q,value) and select(a,value,positive,DEFAULT)[2]!=select(b,value,positive,DEFAULT)[2]
        if name not in CASE_IDS:continue
        for kind in ['singleton','continuous_window']:
            for batch in BATCHES:
                key=f'{name}__{kind}__b{batch}';plan=saved_plans[key];assert plan['requests']==plans(kind,batch)
                expected=[direct_answer(a,b,positive,q,breaks)['affected'] for q in plan['requests']];assert expected==plan['expected']
                assert [index.query(q)['affected'] for q in plan['requests']]==expected
                for method in METHODS:
                    for rep in range(5):
                        out=read(R/'boolean_outputs'/f'{key}__r{rep}__{method}.json')
                        for q,r in zip(plan['requests'],out):
                            if r['witness'] is not None:
                                value=F(r['witness']);assert allowed(q,value) and select(a,value,positive,DEFAULT)[2]!=select(b,value,positive,DEFAULT)[2];witnesses+=1
    result=dict(status='PASS',prior_v8_exact_stages=31,prior_certificate_audit_exit_code=0,raw_measurements_reconciled=960,statistical_groups_reconciled=192,reused_unique_case_query_plans=2028,saved_method_query_answers_reconciled=40560,boolean_existing_domain_queries_replayed=count,saved_rational_witnesses_rechecked=witnesses,smt_unknown=0,scope='Paired certificate API comparison has matched certificate construction/checking obligations; comparisons to direct/SMT are implementation request costs with unequal assurance. No new bug/deployment/developer evidence.')
    (R/'validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
