"""Reconcile V4 raw measurements and independently replay diagnostic outputs."""
from pathlib import Path
from fractions import Fraction as F
import json,csv,hashlib,inspect
import numpy as np
from sklearn.model_selection import TunedThresholdClassifierCV
from external_selector_integration import execute,admission
from complete_region_comparison import Q,candidates,select,DEFAULT,upstream_functions,actual_table,verify_regions

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def rows(p):return list(csv.DictReader(p.open(encoding='utf-8')))
def main():
    R=Q/'results/v4';on=read(R/'onboarding_summary.json');assert on['status']=='PASS' and on['mismatches']==0 and on['upstream_source_edits']==0
    source=hashlib.sha256(inspect.getsource(TunedThresholdClassifierCV).encode()).hexdigest();assert source==on['source_class_sha256']
    records=read(Q/'inputs/manifest.json')['cases'];probes=0;callbacks=0;count=0
    for rec in records:
        if rec.get('seed')!=0:continue
        f=Q/'inputs'/rec['file'];assert sha(f)==rec['sha256'];d=np.load(f);y=d['y'][:48];s=d['old'][:48];c=read(R/(rec['case_id']+'_optimizer.json'))
        assert c['source_input_sha256']==rec['sha256'] and c['source_class_sha256']==source and c['ids']==d['ids'][:48].tolist()
        gold=candidates(y,s,DEFAULT);br=sorted({F(3,10),F(9,10)}|{p for p,*_ in gold if F(3,10)<p<F(9,10)});pp=sorted(set(br)|{(a+b)/2 for a,b in zip(br,br[1:])})
        assert [r['alpha'] for r in c['policy_probes']]==list(map(str,pp))
        for a,r in zip(pp,c['policy_probes']):
            actual,calls=execute(y,s,a);expected=select(gold,a,True,DEFAULT)[2]
            assert r['expected_bits']==hex(expected)==r['actual_bits']==hex(actual) and r['scorer_calls']==len(calls)
            probes+=1;callbacks+=len(calls)
        count+=1
    assert count==3 and probes==on['total_policy_probes']==59 and callbacks==sum(r['scorer_callbacks'] for r in on['workloads'])
    assert len(on['unsupported_configurations'])==4 and all(r['status']=='UNSUPPORTED' for r in on['unsupported_configurations'])
    sample=np.array([.1,.1,.3,.8]);rejected=0
    for th,cv,refit in [(100,'prefit',False),(np.array([.1,.8]),'prefit',False),(np.unique(sample),3,False),(np.unique(sample),'prefit',True)]:
        try:admission(sample,th,cv,refit)
        except ValueError:rejected+=1
    assert rejected==4
    vendor=Q/'vendor/external_eval_toolkit';vm=read(vendor/'SOURCE_MANIFEST.json')
    for name,rec in vm['files'].items():assert sha(vendor/name)==rec['sha256']
    assert on['second_project']['full_package_executed'] is False and on['second_project']['policy_certificate_issued'] is False
    region=read(R/'complete_region_summary.json');assert region['status']=='PASS' and region['source_sha256']==sha(Q/'complete_region_comparison.py')
    records={r['case_id']:r for r in read(Q/'inputs/external_sut/manifest.json')['cases']};functions=upstream_functions();certs={};checked=0
    for f in sorted((R/'region_certificates').glob('*.json')):
        r=read(f);rec=records[r['case_id']];p=Q/'inputs/external_sut'/rec['file'];assert sha(p)==rec['sha256'];d=np.load(p)
        gold=candidates(d['y'],d['scores'],DEFAULT);actual,_=actual_table(functions[r['variant']][0],d['y'],d['scores'])
        c=r['certificate'];assert len(c['representative_witnesses'])==len(c['divergent_regions']);verify_regions(gold,actual,c)
        key=(r['case_id'],r['variant']);assert key not in certs or certs[key]==c;certs[key]=c;checked+=1
        if r['method']=='smt_all_regions':assert r['algorithm_stats']['residual_result']=='unsat'
    rr=rows(R/'complete_region_timings.csv');assert len(rr)==48 and checked==16 and len(certs)==8
    for key,c in certs.items():
        for method in ['partition','smt_all_regions']:
            group=[r for r in rr if (r['case_id'],r['variant'])==key and r['method']==method];assert sorted(int(r['replicate']) for r in group)==[0,1,2]
            for r in group:assert int(r['regions'])==len(c['divergent_regions']) and r['psc_exact']==c['psc_exact'] and float(r['independent_checker_ms'])>0 and float(r['producer_and_serialization_ms'])>0
    raw=rows(R/'checker_cost_raw.csv');summary=rows(R/'checker_cost_summary.csv');meta=read(R/'checker_cost_metadata.json');assert len(raw)==36 and len(summary)==6 and meta['status']=='PASS'
    assert meta['checker_source_sha256']==sha(Q/'src/independent_oracle.py') and meta['timing_tracemalloc'] is False and meta['memory_timing_pooled'] is False
    for s in summary:
        group=[r for r in raw if (r['n'],r['g'],r['workload'])==(s['n'],s['g'],s['workload'])];timing=[r for r in group if r['phase']=='untraced_consumer'];memory=[r for r in group if r['phase']=='separate_memory_run']
        assert len(memory)==1 and sorted(int(r['replicate']) for r in timing)==list(range(5))
        assert all(not r['peak_aux_mib'] for r in timing) and not memory[0]['checker_ms'] and not memory[0]['parse_ms']
        assert len({r['input_sha256'] for r in group})==1 and len({r['policy_probes'] for r in group})==1
        v=[float(r['checker_ms']) for r in timing];q=np.percentile(v,[25,75],method='linear')
        for a,b in [(float(s['checker_median_ms']),np.median(v)),(float(s['checker_iqr_ms']),q[1]-q[0]),(float(s['parse_median_ms']),np.median([float(r['parse_ms']) for r in timing])),(float(s['separate_peak_aux_mib']),float(memory[0]['peak_aux_mib']))]:assert np.isclose(a,b,rtol=1e-12,atol=1e-12)
        assert float(s['separate_peak_aux_mib'])>0
    result={'status':'PASS','external_optimizer_workloads_replayed':count,'external_optimizer_policies_replayed':probes,'scorer_callbacks_replayed':callbacks,'unsupported_configurations_rejected':rejected,'region_certificates_replayed':checked,'matched_region_tasks':len(certs),'complete_region_timing_records':len(rr),'checker_raw_records_reconciled':len(raw),'checker_groups_reconciled':len(summary),'second_project_executed':False,'scope':'Executed optimizer replay, independent exact membership/region checks, raw timing reconciliation and pinned-source bindings. No second executed project or additional confirmed defect is inferred.'}
    (R/'validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
