"""Replay program certificates, version evidence and phase-level measurements."""
from pathlib import Path
from fractions import Fraction
import sys,json,csv,hashlib
import numpy as np
Q=Path(__file__).resolve().parent;sys.path.insert(0,str(Q/'src'))
from independent_oracle import candidates,select,verify
from policy_exact import DEFAULT
from program_evaluation import modules,execute_program

def main():
    R=Q/'results/v2';m=json.loads((Q/'inputs/manifest.json').read_text(encoding='utf-8'));records={r['case_id']:r for r in m['cases']};mods=modules();count=0;probes=0
    rows=list(csv.DictReader((R/'program_results.csv').open(encoding='utf-8')))
    for row in rows:
        rec=records[row['case_id']];d=np.load(Q/'inputs'/rec['file']);y=d['y'];s=d['old'];ids=d['ids'].tolist();sut,h=mods[row['program']];table=sut.build(y,s);positive=bool(y.sum())
        c=json.loads((Q/row['certificate_file']).read_text(encoding='utf-8'));assert c['source_sha256']==h and c['frozen_input_sha256']==rec['sha256']
        expected=candidates(y,s,DEFAULT);_,events=execute_program(sut,table,Fraction(3,10),positive,len(y));assert c['guard_events']==list(map(str,sorted(events)))
        br=sorted({Fraction(3,10),Fraction(9,10)}|{p for p,*_ in expected if Fraction(3,10)<p<Fraction(9,10)}|{p for p in events if Fraction(3,10)<p<Fraction(9,10)})
        pp=sorted(set(br)|{(a+b)/2 for a,b in zip(br,br[1:])});assert list(map(str,pp))==[r['alpha'] for r in c['probes']]
        bad=False
        for p in c['probes']:
            alpha=Fraction(p['alpha']);actual,traced=execute_program(sut,table,alpha,positive,len(y));ref=select(expected,alpha,positive,DEFAULT)[2]
            assert traced==events and hex(actual)==p['actual_bits_hex'] and hex(ref)==p['expected_bits_hex']
            assert p['conforms']==(actual==ref);bad |= actual!=ref;probes+=1
            if actual!=ref:
                xor=actual^ref;i=(xor&-xor).bit_length()-1;assert p['witness_row_id']==ids[i]
        assert c['conforms']==(not bad) and bad==(row['conformance_failure']=='True');count+=1
    ps=json.loads((R/'program_summary.json').read_text());assert count==ps['program_runs']==210 and probes==ps['policy_probes']
    assert sum(r['conformance_failure']=='True' for r in rows)==ps['nonconforming_runs']==136
    versions=json.loads((Q/'inputs/version_inputs/manifest.json').read_text());version_count=0
    outs={v:np.load(R/f'scipy_{v}/scores.npz') for v in ['1.15.3','1.18.1']}
    for rec in versions['cases']:
        f=Q/'inputs/version_inputs'/rec['file'];assert hashlib.sha256(f.read_bytes()).hexdigest()==rec['sha256'];d=np.load(f);cid=rec['case_id'];c=json.loads((R/'version_certificates'/f'{cid}.json').read_text())
        verify(d['y'],outs['1.15.3'][cid],outs['1.18.1'][cid],list(range(len(d['y']))),c);version_count+=1
    raw=list(csv.DictReader((R/'ablation_raw.csv').open()));summary=list(csv.DictReader((R/'ablation_summary.csv').open()));assert len(raw)==60
    for row in raw:
        phase=sum(float(row[k]) for k in ['construction_ms','sweep_excluding_witness_ms','witness_ms','assembly_and_hash_ms','serialization_ms'])
        assert abs(phase+float(row['unattributed_ms'])-float(row['total_ms']))<1e-8
        if row['witness']=='False':assert float(row['witness_ms'])==0
    for s in summary:
        rr=[r for r in raw if r['n']==s['n'] and r['witness']==s['witness']];vals=[float(r[s['phase']]) for r in rr];q=np.percentile(vals,[25,75],method='linear')
        assert len(rr)==10 and np.isclose(np.median(vals),float(s['median_ms']),rtol=0,atol=1e-12) and np.isclose(q[1]-q[0],float(s['iqr_ms']),rtol=0,atol=1e-12)
    result={'status':'PASS','program_certificates_replayed':count,'program_policy_probes':probes,'real_version_certificates_reverified':version_count,'ablation_records_reconciled':len(raw),'new_spec_provided':False}
    (R/'revision_validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
