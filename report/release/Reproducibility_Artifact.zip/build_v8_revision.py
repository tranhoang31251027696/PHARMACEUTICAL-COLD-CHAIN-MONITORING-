"""Revision focused on measured reuse costs, scope and inherited contribution."""
import json,csv,re

def integrate(Q,text):
    R=Q/'results/v8';summary=json.loads((R/'reuse_cost_summary.json').read_text(encoding='utf-8'));raw=list(csv.DictReader((R/'reuse_summary.csv').open(encoding='utf-8')))
    text=text.replace('Research manuscript V7 revised','Research manuscript V8 revised')
    text=text.replace("RQ-D External numerical contracts and operational scope: How do exact rational and binary64 policy interfaces differ, and do those differences intersect the policies an application actually permits?","RQ-D Allowed domains and the cost of verified reuse: How do rational and binary64 policy interfaces differ, which declared policy domains intersect a change, and when do measured certificate construction and checking costs amortize relative to direct masks or incremental SMT?")
    text=re.sub(r'The four groups consolidate the former seven questions:.*?Results from different corpora, numerical contracts and benchmark protocols remain separate\.', 'The four questions separate correctness, testing and diagnostics, certification cost, and permitted-domain reuse. Corpora, numerical contracts and timing protocols remain separate.',text,flags=re.S)
    intro='''### Closest contribution and inherited scope

Parametric verification already reasons about regions [6,7,20], AllSMT enumerates predicate models [23–25], and certifying computations separate production from checking [9,17]. We specialize these established ideas to selected observation IDs under a fixed empirical precision contract. The implemented contribution is an input-bound diagnostic object with exact endpoint ownership, a separately coded consumer, and executable allowed-domain decisions under explicit numerical semantics. We evaluate its correctness and computational costs; we do not claim new region-enumeration theory, a capability unavailable to SMT, or developer-productivity gains.

The supplied related manuscript, Exact Candidate Frontier Comparison for Decision Regression Testing of Precision-Constrained Selectors, already defines the observation contract, compact candidate-frontier comparison and checked proper-prefix attribution. We reuse its labels/ID conventions, score inputs and 255 counterfactual grid records. This extension quantifies selected-ID equivalence over an allowed policy domain and adds complete interval certificates, independent streaming consumption, source-program/upstream studies and checked domain queries. Neither the earlier contract nor its witness machinery is presented as a new contribution here. INHERITANCE_AND_PUBLICATION_BOUNDARY.md maps each reused component to hash-bound original source snapshots. The related manuscript's publication status is unverified and must be disclosed accurately by the human authors.

'''
    text=text.replace('## 2. Research questions',intro+'## 2. Research questions',1)
    # Retain detailed foundations and operator breakdown, but move them out of main.
    supplement=(Q/'docs/SUPPLEMENT_Q1_V7.md').read_text(encoding='utf-8').replace('for Q1 V7','for Q1 V8').replace('as described below','as described in the main paper')
    match=re.search(r'### Relation to existing verification and testing methods\n.*?(?=### Closest method comparison)',text,re.S);assert match
    supplement+='\n## S10 Detailed relation to verification and testing foundations\n\n'+match.group().split('\n',1)[1]
    relation='''### Relation to verification and testing foundations

Parameter synthesis [6,7,20] and predicate enumeration [23–25] already explore parameter regions. Regression verification [8] compares related program versions; certifying algorithms [9,17] and proof-carrying code [10] establish producer/consumer separation. Parametric monitoring [19] and robust classification [18] address other parameterized objects. Our selector, property and evidence obligations differ, but no capability absence is inferred for those methods. A suitably encoded solver can answer our questions, as the matched experiments demonstrate.

Metamorphic and mutation-based testing of optimization and ML implementations [4,11,12] motivates executed-code evaluation. Our controlled variants and two documented source replays establish narrower applicability evidence than an industrial bug corpus or developer study. The Introduction identifies the specialized contribution and inherited work; Supplement S10 retains the detailed source distinctions and Boolean SMT context.

'''
    text=text[:match.start()]+relation+text[match.end():]
    match=re.search(r'### Precise contribution relative to nearby methods\n.*?(?=## 12\. Conclusion)',text,re.S);assert match
    supplement+='\n## S11 Detailed contribution map\n\n'+match.group().split('\n',1)[1]
    text=text[:match.start()]+'''The contribution map in Supplement S11 distinguishes established foundations from the specific objects implemented and tested here. Rounding-cell reasoning [26] is applied to the actual selector interface; elementary set intersection is used by the query layer. Neither is claimed as a new general algorithm. Two documented defects strengthen applicability evidence, while first-in-literature novelty and broad effectiveness remain unestablished.

'''+text[match.end():]
    match=re.search(r'\| Variant \| Runs \| Policy-divergent \| Snapshot \| Grid \| ID violations \|\n(?:\|[^\n]*\n)+',text);assert match
    supplement+='\n## S12 Operator-level mutation records\n\n'+match.group()
    text=text[:match.start()]+'The operator-level breakdown is retained in Supplement S12 and the raw mutation records.\n\n'+text[match.end():]
    aliases={'upstream_int8':'Upstream int8','unix_seconds_int32':'Unix int32','small_int32_control':'Small int32 control','pipeline_axis_wdbc_logistic_isotonic_seed0':'WDBC seed 0','pipeline_axis_digits_svc_sigmoid_seed0':'Digits seed 0','pipeline_axis_generated_rf_quantized_seed0':'RF seed 0'}
    lookup={(r['case_id'],r['kind'],int(r['batch']),r['method']):r for r in raw};table=[]
    for name,label in aliases.items():
        for kind in ['singleton','continuous_window']:
            entries=[lookup[name,kind,128,method] for method in ['checked_certificate','direct_masks','incremental_z3']]
            cells=[f"{float(r['median_total_ms']):.2f} ({float(r['iqr_total_ms']):.2f})" for r in entries]
            table.append(f"| {label} | {'Point' if kind=='singleton' else 'Window'} | "+' | '.join(cells)+' |')
    wins={}
    for kind in ['singleton','continuous_window']:
        for other in ['direct_masks','incremental_z3']:
            wins[kind,other]=sum(float(lookup[name,kind,128,'checked_certificate']['median_total_ms'])<float(lookup[name,kind,128,other]['median_total_ms']) for name in aliases)
    crossings=[r for r in summary['observed_crossings'] if r['comparator']=='direct_masks' and r['first_observed_sustained_batch'] is not None]
    cross_text='None of the tested configurations has an observed sustained crossing against direct masks.' if not crossings else 'Observed sustained crossings against direct masks are '+ '; '.join(f"{aliases[r['case_id']]} / {r['kind']} at batch {r['first_observed_sustained_batch']}" for r in crossings)+'.'
    reuse='''### Measured cost of repeated allowed domain decisions

We now test whether reuse pays for certificate setup, rather than treating a large query count as a productivity result. Six inputs are fixed before measurement: the upstream int8 fixture, Unix-second int32 fixture, small-int32 control, and seed zero of each pipeline family. These are existing controlled SciPy propagation inputs, not six new projects or production configurations. Two request types use distinct rational singleton policies or width-1/20 windows spread deterministically over [0.30,0.90], with varying endpoint ownership. Batches contain 1, 8, 32 or 128 requests. The scenarios test computational costs; no application policy-frequency distribution is asserted.

The common output is Boolean existence of a difference plus a rational witness. Direct masks prepare candidate memberships once, then evaluate the requested point or all relevant critical points/open cells for a window, stopping on a difference. Incremental Z3 prepares the independent selected-bitset encoding once per batch and uses push/pop for each request; unknown/timeout fails the study. The certificate route includes construction, a JSON roundtrip and independent full verification once per batch before queries. Its current API materializes intersections before projecting the Boolean answer, so that actual implementation cost remains included. No route memoizes query results; requests within a batch are distinct. All routes reuse the same executed interpolation outputs outside timing. These totals start from frozen score vectors; they exclude common SUT execution, imports, disk I/O and human investigation.

Each case/type has one warmup per method, followed by five fresh setups per batch and method with seeded randomized method order and no allocation tracing. There are 720 timing records, 144 statistical groups and 2,028 distinct case/query plans. All 30,420 method/request answers across methods and repetitions agree, and every reported rational witness is checked against independent selection. These are repeated computational observations, not independent defects or deployment trials. Raw phase costs, query outputs and median/IQR records are retained; medians are not pooled across inputs.

The table reports total median milliseconds (IQR) for batch 128, including setup. The other batch sizes and the separately measured setup/query phases remain in reuse_summary.csv.

| Workload | Request | Checked certificate | Direct masks | Incremental Z3 |
|---|---|---|---|---|
'''+ '\n'.join(table)+f'''

At batch 128 the checked certificate is faster than direct masks on {wins['singleton','direct_masks']}/6 singleton and {wins['continuous_window','direct_masks']}/6 window inputs; it is faster than this incremental Z3 encoding on {wins['singleton','incremental_z3']}/6 and {wins['continuous_window','incremental_z3']}/6 respectively. {cross_text} A sustained crossing means the first tested batch with a lower certificate total median at that and every larger tested batch; it is a discrete observed comparison, not an inferred exact threshold, significance test or extrapolation beyond 128 requests. Five repetitions on one host do not establish a population advantage.

The mostly negative comparison against direct masks constrains the practical claim. Reuse alone does not justify building a certificate for a small finite decision set or guarantee an advantage even for continuous windows. A separately checkable, persistable diagnostic object may be required for exact localization or handoff, but this experiment does not monetize that requirement or measure a developer's debugging time. It measures a computational tradeoff against specified implementations, including a reused solver, and leaves industrial policies, human triage benefit and superiority over an independently optimized parametric tool unresolved.

'''
    text=text.replace('## 10. Threats to validity',reuse+'## 10. Threats to validity',1)
    start=text.index('### Immutable final archive evidence');end=text.index('The contribution map in Supplement',start)
    text=text[:start]+'''### Immutable final archive evidence

The exact V7 ZIP, SHA-256 a14ac1fc458b1b76e8a6cc25031723597648045dcaae866fd46a9b6a0f806d9a, has a detached report recording all 29 stages passing, 1,682 verified manifest entries and unchanged before/after archive hashes. That report, environment, logs and output digests are included under evidence/V7_FINAL_RELEASE_EVIDENCE; validate_v8.py verifies every sidecar hash and the report's archive identity. This supplies the evidence absent from the review upload without relabeling its partial external execution a full reproduction.

V8 adds the reuse-cost study and audit for 31 default stages. The exact frozen research ZIP and its subsequent detached execution report are paired in the complete DELIVERY bundle. New raw timings and rebuilt Markdown are separately supplied from the final extraction; the reading copy retains the measured snapshot frozen before packaging. These are local author-side executions, not independent institutional reproduction or remote CI.

'''+text[end:]
    text=text.replace('the actual frequency and utility of such reuse were not measured.','its actual frequency and human utility remain unmeasured.')
    text=text.replace('Per-query records retain descriptive single-invocation costs and separately measured initial verification; they are not a repeated timing benchmark or an amortization/speed claim.','Those per-query records retain descriptive single-invocation costs and initial verification; the repeated batch-cost protocol below is a separate experiment.')
    text=text.replace('The added domain-query interface produces 288 answers matching SMT, with 24,408 direct policy checks. It makes permitted-domain diagnosis executable after certificate verification; it establishes functional reuse on controlled fixtures, while developer benefit and deployment break-even remain unmeasured.','The domain-query interface has 288 answers matching SMT and 24,408 direct policy checks. The added 720-record batch experiment includes construction and independent checking costs and finds that direct masks usually remain cheaper. Verified reuse is an evidence representation and a measured engineering tradeoff, not an automatic speed or productivity benefit.')
    abstract='''## Abstract

Sampled precision policies can miss changed threshold decisions elsewhere in an allowed domain. We specialize established region reasoning and certifying computation to exact finite-input selected-ID equivalence, endpoint-sensitive diagnostics and independently checked certificates. Controlled program experiments detect 136 nonconforming runs, versus 111 with a thirteen-point grid. Historical-source replay of two documented upstream defects demonstrates applicability but adds no affected workload over that grid. An installed eval-toolkit selector exposes 27 rational-versus-binary64 contract differentials, none intersecting the studied decimal lattices. Partition and SMT agree on complete diagnostics through G=500. A separately implemented streaming consumer reduces measured checking memory and time without improving the worst-case O(NG) work bound. Allowed-domain queries agree with SMT on 288 scenarios and with 24,408 direct policy checks. A new 720-record reuse experiment includes construction and independent verification: direct masks usually remain cheaper, so reuse does not imply a universal computational benefit. The contribution is a scoped diagnostic contract, checked evidence and an explicit cost assessment, with inherited candidate-frontier work separated from the extension. Immutable releases carry hash-bound execution evidence. Production policy requirements, developer productivity and broad industrial effectiveness remain unmeasured.

'''
    text=text[:text.index('## Abstract')]+abstract+text[text.index('Keywords:'):]
    corrections={4:'Duque-Torres, A.; Klammer, C.; Fischer, S.; Pfahl, D.; Ramler, R. (2025). Assessing the strength of Metamorphic Testing applied to optimisation software—Experience from industry. Information and Software Technology, 186, 107807. https://doi.org/10.1016/j.infsof.2025.107807',
      5:'scikit-learn developers. CalibratedClassifierCV, version 1.9.1 documentation. https://scikit-learn.org/stable/modules/generated/sklearn.calibration.CalibratedClassifierCV.html (accessed 30 October 2026).',
      6:'Storm project. Running Storm on Parametric Models. Official documentation. https://www.stormchecker.org/documentation/usage/running-storm-on-parametric-models (accessed 30 October 2026).',
      7:'Junges, S.; Ábrahám, E.; Hensel, C.; Jansen, N.; Katoen, J.-P.; Quatmann, T.; Volk, M. (2024). Parameter synthesis for Markov models: covering the parameter space. Formal Methods in System Design, 62, 181–259. https://doi.org/10.1007/s10703-023-00442-x',
      11:'Yang, Y.; Li, Z.; Wang, H.; Xu, C.; Ma, X. (2021). Towards effective metamorphic testing by algorithm stability for linear classification programs. Journal of Systems and Software, 180, 111012. https://doi.org/10.1016/j.jss.2021.111012',
      12:'Xie, X.; Ho, J. W. K.; Murphy, C.; Kaiser, G.; Xu, B.; Chen, T. Y. (2011). Testing and validating machine learning classifiers by metamorphic testing. Journal of Systems and Software, 84(4), 544–558. https://doi.org/10.1016/j.jss.2010.11.920',
      20:'Dehnert, C.; Junges, S.; Jansen, N.; Corzilius, F.; Volk, M.; Bruintjes, H.; Katoen, J.-P.; Ábrahám, E. (2015). PROPhESY: A PRObabilistic ParamEter SYnthesis Tool. CAV, LNCS 9206, 214–231. https://www.cs.ru.nl/personal/nilsjansen/files/publications/dehnert-et-al-cav-2015.pdf',
      24:'Morettin, P.; Passerini, A.; Sebastiani, R. (2017). Efficient Weighted Model Integration via SMT-Based Predicate Abstraction. IJCAI, 720–728. https://www.ijcai.org/proceedings/2017/100'}
    for number,entry in corrections.items():text=re.sub(r'^\['+str(number)+r'\].*$',f'[{number}] '+entry,text,flags=re.M)
    supplement+='\n## S13 Repeated reuse cost protocol and limits\n\nSee results/v8/reuse_protocol.json for the predeclared selection and requests, reuse_raw.csv for 720 chronological observations, reuse_summary.csv for 144 median/IQR groups, reuse_query_plans.json for 2,028 distinct plans and reuse_outputs/ for every saved method answer. Setup includes certificate construction/JSON/full independent verification or independent mask/SMT preparation. The shared interpolation computation is outside all method timers. Request types, endpoints, batch sizes and all six inputs are retained even when a method is slower. Raw observations and deterministic query answers are separately audited. A crossing is defined only on tested batches 1/8/32/128. No developer study, production-policy inventory or universal amortization bound is claimed.\n'
    (Q/'docs/SUPPLEMENT_Q1_V8.md').write_text(supplement,encoding='utf-8')
    return text

def vietnamese_report(Q):
    return '''# Kết quả Q1 V8 ngày 30 tháng 10 năm 2026

V8 thêm phép đo chi phí tái sử dụng gồm setup, construction và independent verification: sáu input có sẵn, hai loại query, batch 1/8/32/128, năm repetitions, ba phương pháp gồm incremental Z3. 720 timing records, 144 median/IQR groups, 2.028 distinct case/query plans và 30.420 câu trả lời lặp theo method/repetition khớp nhau. Direct masks thường rẻ hơn; không khẳng định reuse luôn hòa vốn hoặc tăng năng suất developer.

Introduction phân định closest contribution và phần kế thừa Q2. Đã đối chiếu nguồn sơ cấp cho 28 reference ở mức được ghi trong BIBLIOGRAPHY_AUDIT_V8, bổ sung metadata và sửa URL; không gọi đây là systematic review. Related Work thu gọn, chi tiết chuyển Supplement. Snapshot nguồn Q2 và hash được giữ để kiểm tra overlap; không tự tạo publication metadata.

Đúng report ZIP V7 29/29 stages nằm ngay trong evidence/V7_FINAL_RELEASE_EVIDENCE. V8 có 31 default stages; báo cáo trên đúng ZIP cuối được giao trong DELIVERY. Hai documented defects vẫn chỉ là hai và grid vẫn phát hiện đủ trên cả hai case studies. Chưa có production requirements hay developer triage study. Hồ sơ Q2 gốc giữ nguyên.
'''

