"""Build inspectable research narrative directly from recorded local results."""
from pathlib import Path
import csv,json
from collections import Counter
Q=Path(__file__).resolve().parent;R=Q/'results';D=Q/'docs'
def read(name):return list(csv.DictReader((R/name).open(encoding='utf-8')))
def pct(k,n):return f'{100*k/n:.1f}%'
def table(headers,rows):return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(map(str,row))+' |' for row in rows])

def main():
    s=json.loads((R/'summary.json').read_text(encoding='utf-8'));p=read('policy_cases.csv');m=read('mutations.csv');t=read('certificate_timing_summary.csv')
    divergent=[r for r in m if r['policy_divergent']=='True'];miss=[r for r in divergent if r['grid_detected']=='False']
    positive_miss=sum(float(r['psc'])>0 for r in miss);point_miss=len(miss)-positive_miss
    cohort=table(['Cohort','Pairs','Policy-sensitive pairs','Domain'],[(k,v['cases'],v['sensitive'],'[0.30,0.90]' if k in ['Public_WDBC','Independent_pipeline'] else '[0.30,0.80]') for k,v in s['cohorts'].items()])
    detections=table(['Test observation','Detected / 183 divergent mutants','Rate'],[(label,f'{s["detections_on_policy_divergent"][key]}/183',pct(s['detections_on_policy_divergent'][key],183)) for key,label in [('snapshot_detected','Selected membership at alpha=0.50'),('grid_detected','Thirteen-point output harness'),('score_b4_flag','Score-only B4 structural flag (different scope)'),('current_guard_flag','Current score guard at alpha=0.50 (different scope)'),('exact_detected','Exact configured policy certificate')]])
    mutationrows=[]
    for name in sorted({r['mutant'] for r in m}):
        rr=[r for r in m if r['mutant']==name]
        mutationrows.append([name,len(rr),sum(r['policy_divergent']=='True' for r in rr),sum(r['snapshot_detected']=='True' for r in rr),sum(r['grid_detected']=='True' for r in rr),sum(r['contract_failure']=='True' for r in rr)])
    muttable=table(['Variant','Runs','Policy-divergent','Snapshot','Grid','ID violations'],mutationrows)
    timingtable=table(['N','G old (nominal bins)','Workload','Witness enabled','Median ms','IQR ms','Peak aux MiB','Witness cells'],[(r['n'],r['g'],r['workload'],r['witness'],f"{float(r['median_ms']):.2f}",f"{float(r['iqr_ms']):.2f}",f"{float(r['median_peak_mib']):.2f}",r['median_witness_cells']) for r in t])
    historical=[r for r in p if int(r['old_grid_configs'])];assert len(historical)==23
    text=f'''# Exact Policy-Robust Regression Testing for Precision-Constrained Decision Pipelines

**Research extension draft; local experiments completed 29 October 2026.** Author identities and publication status of the inherited work must be supplied before submission. This is a new research narrative with explicit inherited components, not a claim of a Q1 acceptance or completed novelty review.

## Abstract

Regression tests for threshold decision pipelines often inspect one selected output or the entire score-induced candidate frontier. Neither observation by itself specifies exactly which precision policies cause changed selected membership. We define policy equivalence over a closed rational precision domain for fixed aligned binary labels, finite scores, and a deterministic selector maximizing true positives and then selected count. A finite characterization reduces universal comparison to critical precision ratios and intervening open cells, with exact endpoint treatment. An implementation combines monotone candidate invalidation, rank-based membership equality and optional observation witnesses; an independent threshold-mask verifier checks input-bound certificates. We evaluate 98 versioned input pairs, including 50 retained cold-chain comparisons, 17 synthetic fixtures, one public pilot, and 30 newly fitted pipelines from three distinct local families. The method reproduces all 255 earlier grid outcomes. In 360 controlled mutant/control runs, 183 are policy-divergent, 57 fault variants are equivalent on the evaluated input/domain, 30 violate the row-identity contract, and 90 are valid controls. Exact configured verification detects all 183 observed policy divergences, compared with 157 for thirteen-point testing and 112 for a nominal snapshot; the grid misses {positive_miss} positive-length changes and {point_miss} endpoint-only changes. No policy alarm occurs on the 90 controls. Certificate benchmarks separately exercise invariant and witness-producing paths up to N=100,000. These findings support an exact finite-input testing capability, subject to explicit adapter semantics, local data, hand-designed mutants and a still-incomplete prior-art review.

Keywords: regression testing; precision constraint; threshold selector; policy equivalence; mutation testing; verifiable certificate.

## 1. Problem and motivation

A numerical change can alter attainable candidate memberships without changing the output at alpha=0.50. Conversely, a changed selector implementation can alter policy decisions while receiving identical scores. An actionable regression report should distinguish structural change, change under an agreed policy domain, and contract failure. A sampled alpha grid describes only its sampled points unless further structure establishes complete coverage.

We ask whether two fixed selector versions return identical observation IDs for every allowed empirical precision constraint, and otherwise report where they differ. We use exact empirical ratios, not estimates of out-of-sample precision. The testing domain and deterministic selector specification must be agreed by the caller. Policy divergence is an observation; whether it is a defect depends on whether the change was permitted.

The extension inherits aligned fixed-input data, the candidate-frontier contract, the current score comparator, and B4 from the earlier manuscript. It adds universal policy-domain comparison, endpoint-sensitive certificates, a domain-length metric, and controlled selector/numerical mutations. The elementary finite-partition fact is not advertised as an unprecedented general theorem. Related-work overlap remains a publication gate.

## 2. Research questions

RQ1: Does the exact implementation agree with an independently implemented threshold-mask oracle across exhaustive, randomized and application cases, including policy endpoints and abstention?

RQ2: How does continuous-domain evidence relate to the 255 inherited grid outcomes and to newly fitted numerical pipeline variants?

RQ3: Which controlled policy-sensitive changes are observed by snapshots, sampled policies, structural comparators and exact configured verification? Which structural flags have no policy divergence?

RQ4: What is the measured end-to-end cost of producing a certificate, with and without actual observation witnesses, on invariant and divergent inputs?

## 3. Contract and formal characterization

Observation IDs are fixed, unique and aligned across versions. Labels are binary and fixed. Scores are finite. Each observed score threshold induces a nonempty complete-group candidate C_j with TP k_j and count n_j. Feasibility means alpha <= k_j/n_j, including equality. Among feasible candidates choose lexicographic maximum (k_j,n_j); abstain if none is feasible or the entire label vector has no positives. The policy domain A=[L,H] is specified with exact rational endpoints, 0<=L<H<=1. The inherited API excluded alpha=0; the extension defines its natural feasibility behavior explicitly.

**Finite partition theorem.** Let B contain L, H and all candidate precision ratios of either version in (L,H). Both selected memberships are constant on each open interval between successive B values. Therefore equivalence throughout A holds if and only if memberships agree at each B value and one representative in each open interval.

**Proof.** Candidate feasibility is a comparison to its fixed ratio. Without a critical ratio inside an open interval, no feasibility predicate can change there. With fixed candidate priority and abstention, the selected membership is fixed. Singletons handle inclusive boundaries. These atoms partition the domain, proving necessity and sufficiency. Strict-feasibility mutants use the same critical values with different singleton outcomes. A midpoint alone is insufficient unless the critical set is complete.

Define D_A={{alpha in A: S_old(alpha) != S_new(alpha)}}. The policy sensitivity coverage is PSC=length(D_A)/(H-L), computed as an exact fraction. This is a uniform-domain length ratio, not a failure probability or risk measure. Equivalence implies PSC=0; the converse fails for endpoint-only divergences. With y=[1,0], s=[1,0] and A=[1/2,1], inclusive and strict feasibility differ only at 1/2 and 1, yielding PSC=0 while full equivalence is false. An explicit automated test checks this counterexample.

Detailed assumptions, proof of prefix-membership equality, complexity, certificate trust boundaries and witness limitations are in [FORMAL_SPECIFICATION_AND_PROOFS.md](FORMAL_SPECIFICATION_AND_PROOFS.md).

## 4. Algorithm and certificate

Sort each version's scores, accumulate complete-group TP/N counts, and form exact reduced fractions. Sweep the union of critical policies in increasing order, evaluating every singleton and open midpoint. A priority heap removes candidates once they become infeasible; each candidate is removed at most once. Empirical precision need not be monotone along score prefixes. For reference selectors the largest feasible prefix is optimal because TP is nondecreasing with prefix size, but an explicit heap supports the reverse-secondary-order mutant too.

Given equally sized winning prefixes of size n, selected membership is equal exactly when the maximum new rank among old selected IDs is below n. Inverse ranks and prefix maxima make each equality check constant-time after preprocessing. For a divergent pair, a scan counts changed rows and supplies one observation ID whose old/new membership differs. Cache each distinct state pair and merge only adjacent identical states while preserving endpoint closure.

The certificate records selector contracts, input SHA-256, domain, all critical fractions, state intervals, membership counts, an equality verdict, optional observation witness and exact PSC. It does not store all selected IDs; the original input arrays are needed for verification. The independent verifier constructs actual threshold masks and integer bitsets, independently derives critical values, and checks coverage, winners, witnesses, counts and PSC. It shares the mathematical contract, but not the production heap or rank comparator.

With G total score candidates and K critical values, core time is O(N log N+G log G+K) under unit-cost rational operations; witness scans add O(ND) for D distinct divergent state pairs. Auxiliary memory is O(N+G+K). Arbitrary-precision comparison has additional bit complexity. The independent verifier deliberately uses more expensive threshold-mask enumeration. No machine-checked proof or arbitrary black-box program verification is claimed.

## 5. Evaluation design

Inherited evidence comprises all 50 retained comparisons (not only prior frontier-only positives), all 17 frozen synthetic fixtures and the public WDBC pilot. Their original data lineage is preserved. The 23 cases contributing the earlier 255 grid configurations are checked directly against those CSV records.

New pipelines comprise ten seeded splits for each of WDBC logistic + isotonic calibration, digits zero-vs-rest LinearSVC + sigmoid calibration, and generated imbalanced classification with random forest + score quantization. Fitting/calibration/evaluation indices are disjoint and exported; the RF reserves its unused calibration split. Test labels do not train or calibrate the model, but do define the empirical selector being tested. Ten splits are repetitions on one dataset family, not ten independent deployments. Small WDBC isotonic calibration is used as a structural workload; no calibration-quality advantage is claimed. Base numerical comparisons use float32 score casts, not naturally observed dependency releases.

Each newly fitted base input has eight selector/numerical variants, one row-ID fault and three valid controls. Variants change inclusive precision, threshold comparison, secondary priority, candidate omission, complete ties, feasibility counts, quantization or roundoff-scale scores. They are executable semantic fault models rather than a general source-code mutation engine. Full details appear in [MUTATION_PROTOCOL.md](MUTATION_PROTOCOL.md).

Snapshot and grid tests observe actual configured mutant outputs. B4/current guard observe score arrays and do not inspect changed selector code. Their aggregate scores therefore have different scope. An exact certificate is configured with the mutant's declared finite contract; applying it to arbitrary real software requires a faithful adapter. Detection of the declared fault model does not certify that adapter automatically.

Correctness tests enumerate 4,680 binary-score/label pairs up to N=4 and 6,174 ternary-score cases up to N=3 (10,854 total), plus 1,000 seeded randomized variants. Additional pytest checks cover endpoint-only changes, invalid values/shapes, aligned identities, abstention, certificate tampering and actionable CI failures. These are finite implementation checks, not a proof of universal program correctness.

## 6. RQ1–RQ2: correctness and policy evidence

All 19 pytest test items pass, including the exhaustive and randomized loops. Application and mutation certificates are independently reverified against frozen inputs; detailed counts are in `results/artifact_verification.json`.

{cohort}

All 255 old grid outcomes and selected counts match. Among those 23 selected historical cases, exactly 15 are sensitive on their complete domains, the same case count found by the old grid; the extension supplies exact intervals rather than discovering additional historical sensitive cases. It would be misleading to present the new method as uncovering missed cases in that subset.

For public WDBC, the precise divergent set is (43/51,9/10] on [3/10,9/10], giving divergent length 29/510 and PSC=29/306 (approximately 0.09477). The boundary 43/51 is excluded: equality still holds there. The old grid's two divergent values 0.85 and 0.90 are consistent with this interval.

Of 30 newly trained float32-cast comparisons, only `digits_svc_sigmoid_seed2` is policy-sensitive, with PSC=25/5084. This low frequency is reported as observed, without treating engineered mutations as naturally occurring numerical regressions.

## 7. RQ3: controlled testing effectiveness

There are 360 runs: 240 selector/numerical variants, 30 row-identity violations, and 90 valid controls. Of the 240 variants, 183 are policy-divergent and 57 are equivalent on the tested input/domain. All 30 identity violations are separately rejected; PSC is not assigned to them. No exact policy alarm is raised for the 90 controls.

{detections}

The thirteen-point grid misses {len(miss)} divergent variants: {positive_miss} have positive-length divergent intervals and {point_miss} differ only at critical points. Exact verification's 183/183 is agreement with an independent finite oracle for configured variants, not a general real-fault detection rate. Shared formal assumptions and known mutant semantics limit this evidence.

{muttable}

Across observed policy-equivalent variant/control runs, B4 raises 9 structural flags and the current guard raises 42 broad regression flags. These are not automatically errors: the tools have different observation contracts, and the current guard also observes numerical cutoff changes. We therefore avoid relabeling every frontier difference or threshold change as a policy defect. On selector-only faults with unchanged scores, the score tools lack the observation needed to see the modified code.

## 8. RQ4: certificate construction cost

{timingtable}

All rows use ten measured repetitions after warmup on one Windows host, Python {s['environment']['python'].split()[0]}/NumPy {s['environment']['numpy']}, with randomized mode order, tracemalloc enabled and JSON serialization included. Peak is auxiliary MiB with preallocated inputs excluded, not process RSS. The N=100,000 divergent witness-enabled median is 472.95 ms (IQR 24.79), emitting 111 witness-bearing state cells; the corresponding witness-disabled median is 440.52 ms (IQR 15.98). These runs activate witness construction, unlike the earlier one-policy invariant guard benchmark. No significance, independence, universal speed advantage, or direct cross-protocol latency ratio is asserted. Raw chronological records and exact seeds/generation code are included.

## 9. Integration and practical output

`policy_cli.py` loads aligned NPZ arrays and writes a certificate after independent verification. `--fail-on-divergence` yields exit code 1 and a concrete interval/row witness. The pytest assertion wrapper reports the first divergent state; equality returns a certificate. An example GitHub Actions workflow runs tests and artifact verification locally configured for this folder. The workflow is supplied as a template; it has not been uploaded or executed on a remote CI service.

## 10. Threats to validity

Internal validity: exact ratio arithmetic eliminates feasibility rounding at the chosen empirical contract but does not repair floating model training. The independent verifier shares the same written assumptions; it may share conceptual mistakes. Exhaustive small cases and tamper tests are finite. Input hashes establish accidental integrity, not authenticity. Caller-supplied IDs can be misleading.

Construct validity: PSC measures length under a uniform policy coordinate, ignores isolated points and has no deployment probability interpretation. A Boolean equivalence verdict and endpoint evidence must accompany it. Mutants are injected semantic changes, and the method is explicitly configured with their semantics. Numerical changes are not intrinsically defects. B4/current score-guard totals are limited by their intended scope.

External validity: inherited cold-chain cases are related, synthetic fixtures are designed, and new pipelines use three local dataset families with repeated seeds. There is no independent institution, prospective deployment or naturally occurring bug corpus. Isotonic calibration has small sample size. Only fixed labeled empirical decision sets are verified, not generalization to new observations or trained-model quality.

Performance validity: one host, modest repetition count and background load; tracemalloc changes timing. Input shapes and candidate counts matter. Witness scans can be O(ND). Measurements are descriptive and cannot establish universal dominance.

Novelty/publication validity: critical-point partitioning and constrained classification have substantial prior foundations. The focused primary-source check is not systematic. No JCR quartile or acceptance conclusion follows from these experiments. If the inherited paper is already submitted or published, an extension requires its citation, transparent overlap and the destination's extension policy.

## 11. Related work and contribution boundary

Rath and Hughes [1] study recall optimization under precision constraints; Mackey et al. [2] model threshold-dependent classification constraints; Tasche [3] analyzes optimal thresholding under related constrained objectives. These establish that constrained threshold selection is not new. Mutation-based assessment of metamorphic testing for optimization software is also established [4]. Calibration implementations and caveats follow official scikit-learn documentation [5]. Our proposed contribution is the specific endpoint-correct policy-equivalence contract, executable interval/ID certificates, independent checker and controlled evaluation, not the general idea of finite breakpoints or mutation testing. Full comparison against directly matching parametric-verification work remains necessary before a novelty claim.

## 12. Conclusion

The extension replaces sampled-policy evidence with exact finite-input membership certificates on an agreed policy domain. Local controlled experiments show both interval and endpoint cases missed by sampled policies, while unchanged historical sensitive-case counts and mostly invariant float32-cast pipelines delimit the gains. Input identity, selector semantics, endpoint ownership and the difference between structural change and defect are explicit. Further prior-art work and real-SUT validation are needed before a publication-readiness claim.

## Reproducibility and declarations

Frozen inputs, split manifests, source, tests, raw timing records and all certificates are in this Q1 artifact. The original submission package and sealed archive are preserved. Author-owned source carries the accompanying MIT LICENSE; the existing copyright-holder placeholder is unchanged. Dataset and dependency licenses are not replaced. Newly trained pipeline arrays derive from the bundled WDBC snapshot, scikit-learn digits and generated data. The extension includes local assistant-generated code and prose; human authors must validate, assume responsibility for results, and complete author/funding/contribution and generative-AI declarations before submission.

## References

[1] Rath, P.; Hughes, M. (2022). Optimizing Early Warning Classifiers to Control False Alarms via a Minimum Precision Constraint. PMLR 151, 4895–4914. https://proceedings.mlr.press/v151/rath22a.html

[2] Mackey, A.; Luo, X.; Eban, E. (2018). Constrained Classification and Ranking via Quantiles. https://arxiv.org/abs/1803.00067

[3] Tasche, D. (2018). A plug-in approach to maximising precision at the top and recall at the top. https://arxiv.org/abs/1804.03077

[4] Assessing the strength of Metamorphic Testing applied to optimisation software—Experience from industry (2025). Information and Software Technology. https://doi.org/10.1016/j.infsof.2025.107807 (Indexed publisher description verified; full text not retrieved.)

[5] scikit-learn 1.9.1. CalibratedClassifierCV. https://scikit-learn.org/stable/modules/generated/sklearn.calibration.CalibratedClassifierCV
'''
    matched=read('matched_method_summary.csv');matched_rows=[]
    for family,work in sorted({(r['pipeline'],r['workload']) for r in matched}):
        row=[family,work]
        for method in ['snapshot','grid_13','score_B4','current_guard','exact_certificate']:
            r=next(r for r in matched if r['pipeline']==family and r['workload']==work and r['method']==method)
            row.append(f"{float(r['median_ms']):.3f} ({float(r['iqr_ms']):.3f})")
        matched_rows.append(row)
    matched_table=table(['Pipeline seed 0','Workload','Snapshot','Grid 13','Score B4','Current guard','Exact + witness'],matched_rows)
    text=text.replace('## 9. Integration and practical output',
        '### Matched-input implementation costs\n\n'+matched_table+'\n\nEntries are median milliseconds (linear IQR), six rounds per group, 270 chronological measurements total. Every invocation rebuilds its input summaries, tracing is disabled, and method order is randomized after one warmup. The snapshot/grid use the declared SUT adapter and scan all 13 targets for the grid. Exact includes witness construction but omits JSON serialization in this comparison. Score B4/current guard flags retain their different scopes, especially for the strict-selector workload. These data describe implementation costs, not an equal-capability speed ranking. Do not pool them with the separate traced end-to-end certificate protocol.\n\n## 9. Integration and practical output')
    measured={r['witness']:r for r in t if r['n']=='100000' and r['workload']=='divergent'}
    for before,after in [('472.95',f"{float(measured['True']['median_ms']):.2f}"),('24.79',f"{float(measured['True']['iqr_ms']):.2f}"),('440.52',f"{float(measured['False']['median_ms']):.2f}"),('15.98',f"{float(measured['False']['iqr_ms']):.2f}")]:
        text=text.replace(before,after)
    from build_revision_text import write_extension
    write_extension(Q)
    extension=D/'JOURNAL_EXTENSION_V2.md'
    if extension.exists():
        extra=extension.read_text(encoding='utf-8')
        headings=['## Appendix A ','## Appendix B ','## Appendix C ','## Appendix D ','## Appendix E ']
        parts=[]
        for j,h in enumerate(headings):
            block=extra.split(h,1)[1]
            if j+1<len(headings):block=block.split(headings[j+1],1)[0]
            title,body=block.split('\n',1);parts.append('### '+title+'\n'+body)
        text=text.replace('## 8. RQ4',parts[0]+'\n\n## 8. RQ4')
        text=text.replace('## 7. RQ3',parts[1]+'\n\n## 7. RQ3')
        text=text.replace('## 9. Integration',parts[2]+'\n\n## 9. Integration')
        text=text.replace('## 12. Conclusion',parts[3]+'\n\n## 12. Conclusion')
        text=text.replace('## References',parts[4]+'\n\n## References')
        text=text.replace('Keywords:', 'A separate instrumented program study executes six source mutants without supplying new_spec to the checker: it finds 136 nonconforming runs, versus 111 by grid and 72 by snapshot. Fresh SciPy 1.15.3/1.18.1 workers yield policy differences in 9 of 11 inherited input pairs, without establishing any library defect. Phase-level ablation and a clean standalone run distinguish algorithm evidence from delivery assurance.\n\nKeywords:')
    text+='\n'+(D/'V2_REFERENCES.md').read_text(encoding='utf-8')
    text=text.replace('Research extension draft; local experiments completed 29 October 2026.','Research manuscript revised after technical review on 29 October 2026.')
    from build_v3_revision import integrate
    text=integrate(Q,text)
    from build_v4_revision import integrate as integrate_v4
    text=integrate_v4(Q,text)
    from build_v5_revision import integrate as integrate_v5
    text=integrate_v5(Q,text)
    from build_v6_revision import integrate as integrate_v6
    text=integrate_v6(Q,text)
    from build_v7_revision import integrate as integrate_v7
    text=integrate_v7(Q,text)
    from build_v8_revision import integrate as integrate_v8
    text=integrate_v8(Q,text)
    from build_v9_revision import integrate as integrate_v9
    text=integrate_v9(Q,text)
    from build_v10_revision import integrate as integrate_v10
    text=integrate_v10(Q,text)
    from build_v11_revision import integrate as integrate_v11
    text=integrate_v11(Q,text)
    (D/'MANUSCRIPT_Q1.md').write_text(text,encoding='utf-8')
    # Durable Vietnamese readout, with exact deliverable status rather than a timeline.
    report=f'''# Kết quả triển khai hướng Q1

Đã chạy trọn chuỗi thực hiện cục bộ, không chia lịch tuần: formalization → thuật toán → kiểm chứng → huấn luyện pipeline → mutation evaluation → benchmark tạo certificate → tích hợp pytest/CI → bản thảo và kiểm toán artifact.

## Kết quả chính

- 98 cặp đầu vào: 50 retained, 17 synthetic, 1 public pilot, 30 pipeline mới (3 họ × 10 seeds).
- 10.854 tổ hợp vét cạn và 1.000 trường hợp ngẫu nhiên; 23 pytest test items PASS.
- Cả 255 cấu hình grid cũ khớp. Trong 23 case lịch sử này, cả grid và exact đều tìm 15 case nhạy: không tuyên bố tìm thêm case lịch sử.
- WDBC có khoảng phân kỳ chính xác `(43/51, 9/10]`; PSC=`29/306`. Trong pipeline mới, cast float32 gây phân kỳ ở 1/30 case, không phải 30/30.
- 360 lượt: 183 variant phân kỳ policy, 57 variant tương đương trên input/domain đã xét, 30 lỗi ID, 90 control hợp lệ.
- Exact phát hiện 183/183; grid 157/183; snapshot 112/183. Trong 26 trường hợp grid bỏ sót, 15 có khoảng dương độ dài và 11 chỉ khác ở điểm biên. Không đánh đồng PSC=0 với tương đương.
- 30/30 lỗi ID bị từ chối; 0/90 control có policy false alarm. Đây là tần suất quan sát cục bộ.
- Benchmark 120 bản ghi thực đo, 12 nhóm × 10 lần, có cả nhánh thực sự tạo witness. Tại N=100.000/G=500, median tạo và serialize certificate có witness: 472,95 ms; IQR 24,79 ms. Không so trực tiếp với full guard 112,42 ms của giao thức cũ.

## Đọc và chạy

- `docs/MANUSCRIPT_Q1.md`: bản thảo tiếng Anh theo narrative mới, kèm kết quả, RQs, lý thuyết và threats.
- `docs/FORMAL_SPECIFICATION_AND_PROOFS.md`: điều kiện, chứng minh và độ phức tạp kể cả O(ND) chi phí witness.
- `docs/PRIOR_ART_AND_NOVELTY.md`: đối chiếu nguồn sơ cấp; chưa chứng minh first-in-literature novelty.
- `docs/MUTATION_PROTOCOL.md`: biến thể thực thi, controls, baseline scopes, splits và giao thức thời gian.
- `results/`: CSV thô, certificates, logs, summary và kiểm toán.

Các con số 183/183 dựa trên đặc tả mutant được khai báo rõ và oracle độc lập về implementation; không chứng minh khả năng tự hiểu mã selector bất kỳ. Ba họ pipeline là benchmark huấn luyện cục bộ, không phải xác nhận triển khai độc lập. Workflow CI đã viết và lệnh tương ứng chạy cục bộ; chưa chạy trên GitHub. Bản thảo mới chưa phải bản được xác nhận novelty hay sẵn sàng nộp Q1; còn cần rà soát prior art đầy đủ, đối chứng công cụ trực tiếp phù hợp nếu có, và validation trên real SUT/bug corpus. Không tạo dữ liệu hay tuyên bố về các bước bên ngoài chưa thực hiện.
'''
    report=report.replace('472,95',f"{float(measured['True']['median_ms']):.2f}".replace('.',',')).replace('24,79',f"{float(measured['True']['iqr_ms']):.2f}".replace('.',','))
    report='''# Kết quả Q1 V4 ngày 30/10/2026

Đã chạy các thí nghiệm bổ sung theo phản biện V3, không chia theo tuần. Bản đọc hiện tại là docs/MANUSCRIPT_Q1_V4.pdf và .docx; nguồn nội dung là docs/MANUSCRIPT_Q1.md.

- 25 pytest items PASS. Các số liệu cốt lõi về 360 mutant/control runs và 210 executed-program runs được giữ nguyên, không đổi thành số lỗi ngoài thực tế.
- Đúng ZIP V3 cuối đã chạy sạch 15/15 stages và giữ nguyên SHA-256. Bằng chứng tách rời tại Q1_revision_v4/V3_FINAL_RELEASE_EVIDENCE.
- Selector TunedThresholdClassifierCV thực thi qua public API: ba workload, 59 policy, 2.150 callbacks, không mismatch. Từ chối bốn cấu hình không tương thích. Cùng thư viện scikit-learn nên không tính thêm external project.
- So sánh complete-region partition/SMT: tám task, 48 timing records, cùng regions/endpoints/PSC/representative witnesses; kiểm chứng độc lập 16 certificates được lưu.
- Checker độc lập: 30 timing records không tracing và sáu memory runs tách riêng. Với fixture divergent N=100.000/G=500, chi phí lớn hơn nhiều so với producer; xem bảng đo hiện tại trong bản thảo và results/v4/checker_cost_summary.csv.
- eval-toolkit được ghim source/license nhưng yêu cầu Python >=3.13, chưa chạy trong môi trường Python 3.12.10, không cấp certificate.

Gói V4 có 19 stages. Kết quả chạy trên đúng ZIP cuối nằm trong detached RELEASE_VERIFICATION.json đi kèm, có hash trước/sau, môi trường, exit codes, logs và output digests. Không đưa báo cáo tự tham chiếu vào ZIP và không đóng lại ZIP sau kiểm chứng.

Giới hạn: một external project thực thi, một upstream-confirmed defect; grid cũng tìm đủ 15 workload bị ảnh hưởng của lỗi này. Không xác nhận first-in-literature novelty, independent deployment hoặc sẵn sàng nộp Q1. Xem RESPONSE_TO_REVIEW_V4.md để đối chiếu từng yêu cầu. MIT là giấy phép mã nguồn, không phải tuyên bố mã do viện MIT phát triển. Hồ sơ Q2 gốc được giữ nguyên.
'''
    from build_v10_revision import vietnamese_report
    (Q/'KET_QUA_Q1.md').write_text(vietnamese_report(Q),encoding='utf-8')
    (R/'mutation_by_operator.csv').write_text('operator,runs,policy_divergent,snapshot,grid,id_violations\n'+'\n'.join(','.join(map(str,r)) for r in mutationrows)+'\n',encoding='utf-8')
    print('Wrote English manuscript and Vietnamese result report')
if __name__=='__main__':main()




