"""Integrate external-case, safe-rejection and solver evidence into the paper."""
import json,csv

def integrate(Q,text):
    R=Q/'results/v3'
    e=json.loads((R/'external_sut_summary.json').read_text(encoding='utf-8'));f=json.loads((R/'failure_and_ci_summary.json').read_text(encoding='utf-8'));s=json.loads((R/'smt_summary.json').read_text(encoding='utf-8'))
    external=f'''### Documented external defect and independent upstream code

To move beyond a locally designed source-mutant corpus, we add scikit-learn issue #23213 [14] and its merged fix #23214 [15]. The confirmed defect concerns truncation of the precision-recall curve after first reaching full recall. A curve consumer can consequently miss lower thresholds that retain all positives while adding further observations. That matters to this paper's explicit secondary objective: among candidates with maximum TP, prefer the largest feasible selected set. The omission is not automatically a defect in every downstream application; we evaluate its propagation under this particular, unchanged consumer contract.

We freeze the full upstream metrics source file at scikit-learn 1.0.2 commit `7e1e6d09bcc2eaeba98f7e737aac2ac782f0e5f1` and at the PR merge commit `32c53bc69cc0d1f142700dd6c02281a000b855b9`. SHA-256 values, upstream URLs, and BSD license files accompany them. We compile and execute the original `precision_recall_curve` function nodes without rewriting their bodies. The installed scikit-learn 1.9.1 supplies its public counting routine through a compatibility bridge; every returned precision/recall value is checked against direct membership counts. This is isolated historical-source replay, not installation of an old release binary. We also execute the installed current curve implementation and check its returned thresholds against the fixed-source result. A 1.1.0 snapshot inspected during provenance checks still contained the truncation path, so we do not incorrectly label that tag as the fix.

The frozen inputs comprise the upstream report's synthetic-data/logistic protocol fitted using the current environment, plus the same thirty pipeline workloads used earlier. The report protocol fits and evaluates its classifier on the same rows to expose a metrics defect; no generalization claim follows. One bug exercised on these inputs remains one independently documented defect, not thirty-one independent software projects or defects. Historical fitted coefficients and a historical binary environment were not reproduced.

All methods receive the same actual upstream threshold outputs and the same exact TP/N feasibility and selected-membership objective. The common consumer adapter compares the complete-group reference family to the returned threshold family. It excludes the plotting sentinel that has no corresponding threshold. It derives exact integer counts from the associated masks rather than mistaking floating-point precision rounding for the upstream truncation bug. This curve-consumer adapter is separate from the local alpha-guard program adapter; it does not imply that arbitrary upstream Python passed our local source-admission policy.

| Evidence | Result |
|---|---|
| External projects and upstream-confirmed defects | {e['external_projects']} project, {e['upstream_confirmed_defects']} defect |
| Input workloads and variant/input executions | {e['input_cases']} workloads, {e['executed_variant_input_pairs']} executions |
| Affected-source workloads with policy divergence | {e['affected_policy_divergent_inputs']} |
| Snapshot / grid / full-domain detections on those workloads | {e['snapshot_detected']} / {e['grid_detected']} / {e['complete_detected']} |
| Fixed-source and installed-current policy false alarms | {e['fixed_or_current_false_alarms']} |

The original report protocol reproduces a policy difference, with exact PSC 2059/5862 on [0.30,0.90]. Across all thirty-one workloads, fifteen exhibit policy effects; snapshot detects fourteen, while grid and full-domain checking both detect fifteen. Thus this external case establishes useful detection and localization of a documented external defect, but supplies no additional detected case over the thirteen-point grid. We report that null comparison directly. Sixteen workloads show no policy effect in the permitted domain despite the documented library defect. The fixed and current variants conform in all evaluated workloads. We do not pool these workloads with the internal mutant denominators or relabel the nine SciPy version differentials as confirmed bugs.

'''
    safety=f'''### Fail closed when program assumptions are unsupported

V2 checked alpha placement inside the selection routine, but that syntactic check alone could not exclude state, indirect policy dependencies or unreviewed helpers. The revised adapter uses explicit source admission before execution. Its registry contains hashes of only seven manually reviewed finite programs: the reference and six previously inspected source variants. The adapter additionally rejects direct alpha uses outside the designated guard, global/nonlocal state, top-level mutable state, and unreviewed decorators/defaults. Unknown source is refused even if it appears syntactically harmless. The registry is an auditable compatibility boundary, not an automatic proof that arbitrary Python is safe and not a security sandbox. Hashes do not inspect the semantics of a newly changed executable; an unreviewed source change requires a new review before it can receive a certificate.

Runtime checks require Boolean, correctly aligned membership vectors and valid integer guard counts. Transformed policy arguments, changed guard-event sets and nondeterministic repeated outputs prevent certification. Unsupported input/program behavior is a distinct outcome, not evidence of policy equivalence or a detected regression. The CLI uses exit 0 for a passing checked mode, exit 1 for observed nonconformance, and exit 2 for unsupported operation. Snapshot/grid passes are labeled only as no failure at their probes and are never marked as full-domain certified.

We test twelve unsupported source fixtures, including hidden state, alpha-dependent candidates/objectives, indirect guard access, dynamic evaluation, random priority, mutable defaults and unreviewed imports. Three additional runtime fixtures test wrong shape, non-Boolean membership and invalid guard arguments. All fifteen are refused without a certificate; all seven reviewed source programs remain admitted. These are designed compatibility/failure tests, not a measured detection rate on adversarial or arbitrary code. A safe refusal may require manual integration work even for a correct third-party program. Source allowlisting limits automation and must be treated as a deployment cost, not hidden behind a claim of general-purpose program verification.

### Local CI execution and frequency context

We execute actual CLI subprocesses for three pipeline representatives, the reference and strict-precision program, three probe modes and three repetitions, then six complete-mode invocations on a separate controlled N=100,000/G=500 input. The sixty timed processes are accompanied by three negative CLI checks that require exit 2 for unsupported source. All reference jobs pass and every complete-mode strict-precision job fails as expected. Partial-mode outcomes reflect only their evaluated points.

For the small pipeline representatives, the across-invocation median process time is {f['small_pipeline_median_process_ms']:.2f} ms and median in-gate time is {f['small_pipeline_median_gate_ms']:.2f} ms. On the separate 100,000-row fixture, the corresponding medians are {f['scale_100k_median_process_ms']:.2f} ms and {f['scale_100k_median_gate_ms']:.2f} ms. Process time includes Python startup, imports, input loading and report writing; in-gate time excludes startup and includes repeated-determinism checks, candidate masks and reference comparison. They are paired measurements from these invocations, not directly comparable to the traced compact-certificate benchmark or an estimate for a remote runner. Only three repetitions per program at this scale were measured.

This is practical local workflow evidence: CI can distinguish pass, regression and unsupported programs and attach a concrete report. It does not establish an acceptable latency budget for every team, the best testing frequency, remote GitHub execution, or a production SLO. A team could choose checks per commit or per release according to its own case count and latency budget; we make no numerical frequency recommendation from one host. Actual deployment across projects remains an external-validity limitation.

'''
    smt=f'''### Direct SMT baseline on the same equivalence contract

Beyond broad capability comparisons, we encode the external threshold-consumer task directly in Z3 [16]. Alpha is a real variable in [3/10,9/10]. A candidate is feasible under the exact linear inequality alpha*n <= k. Candidates are ordered by their fixed (TP,N) priority, and nested if-then-else terms compute the winning selected count. For this same-score task, candidates from both versions belong to one chain of score-prefix memberships, so different winning counts are equivalent to different selected memberships. That reduction does not apply to arbitrary score reorderings; we do not use it for them.

The solver asks whether any policy makes the two winning counts unequal. SAT supplies a rational policy witness; UNSAT asserts full-domain equality for the encoded task. Timeout/unknown is never interpreted as equivalence. We independently re-evaluate each SAT model with direct memberships. The complete partition checker separately emits all interval/endpoint evidence and PSC. Both therefore share a Boolean equivalence contract, while their diagnostic outputs differ. The baseline is our explicit finite SMT encoding using an established solver, not a reproduction of a published threshold-testing tool.

Across {s['distinct_equivalence_tasks']} variant/input tasks and three repetitions, all {s['queries']} solver verdicts agree with partition verification; there are {s['unknown_queries']} unknown outcomes and every SAT policy is independently checked. Persisted SMT-LIB queries are resolved again by the artifact validator. Median encoding time is {s['median_encoding_ms']:.3f} ms and median solving time is {s['median_solver_ms']:.3f} ms across those queries. Counts/masks are prepared before these timers. These measurements do not establish a speed ranking against full interval construction with input validation, hashing, witnesses and JSON serialization. The direct SMT results demonstrate that full-domain Boolean comparison is also attainable with a general reasoning engine, narrowing the defensible contribution to the selector-specific contract, complete diagnostics, independently checkable output and scoped integration.

### Closest method comparison and remaining novelty boundary

The certifying-algorithm literature explicitly separates an algorithm's mathematical correctness from correctness of a particular computed output [17]. Parameter synthesis in PROPhESY [20] and Storm studies regions for probabilistic properties; parametric monitoring [19] studies parameter-indexed runtime properties; robust classification under uncertain operating conditions [18] studies selection across varying environments. These works establish relevant foundations, not negative capability claims. None should be described as lacking endpoint handling merely because our inspected example targets a different property. A broader systematic search may still uncover a closer selector-specific tool.

| Method considered | Matched question here | Evidence actually compared | Remaining distinction |
|---|---|---|---|
| Snapshot and thirteen-point probes | Membership compatibility at chosen policies | Executed on identical SUT outputs and contract | Cannot certify unprobed policies |
| Direct Z3 encoding | Existence of any divergent policy on finite nested candidates | 93 actual equivalence tasks, rational counterexample rechecks | One counterexample/Boolean rather than all intervals and PSC |
| Our partition and checker | Same Boolean task plus full divergence localization | Exact endpoints, intervals and independently replayed memberships | Specialized finite contract and explicit adapter assumptions |
| Certifying computations [9,17] | Trust in a particular computation and checker | Primary-source conceptual comparison | General foundation, not an empirical competing selector tool |
| PROPhESY/Storm [6,7,20] | Parameter-region property verification | Primary-source property/input-model comparison | No faithful probabilistic encoding benchmark claimed |
| Parametric monitoring [19] | Monitoring properties across parameter instances | Primary-source semantic comparison | Object/trace parameters differ from empirical precision breakpoints |
| Robust classification [18] | Classifier choice as operating conditions vary | Primary-source objective comparison | Does not make the finite-breakpoint idea novel |

We consequently make no first-in-literature claim for parameter partitioning, regression equivalence or producer/checker separation. The additional same-task SMT experiment is a useful check against overstating novelty: a general solver reaches the same Boolean answers. The proposed research contribution remains the integrated finite selector contract and its endpoint-sensitive diagnostic certificates, scoped executable adapters, and evidence across controlled and one independently documented upstream case. This is stronger substantiation than a scope-only table, but does not certify novelty at a particular journal tier.

'''
    start=text.find('| Approach | Domain and boundary treatment |')
    if start>=0:
        end=text.find('A focused search across these five areas',start)
        if end>start:text=text[:start]+text[end:]
    text=text.replace('## 8. RQ4',external+'## 8. RQ4')
    text=text.replace('## 10. Threats',safety+'## 10. Threats')
    text=text.replace('## 12. Conclusion',smt+'## 12. Conclusion')
    text=text.replace('There is no independent institution, prospective deployment or naturally occurring bug corpus.','There is no independent institution or prospective deployment. The external study adds one documented upstream defect, not a multi-project naturally occurring bug corpus.')
    text=text.replace('A separate upstream-confirmed bug corpus and deployment study remain work outside the evidence completed here.','A broader upstream-confirmed bug corpus and prospective deployment study remain work outside this revision; one isolated-source upstream defect case is now included.')
    text=text.replace('All 19 pytest test items pass','All 23 pytest test items pass')
    abstract='''## Abstract

Threshold decision pipelines can preserve a nominal selected output while changing decisions under another allowed precision policy. We characterize exact membership equivalence over a closed policy domain for fixed finite binary observations and a deterministic threshold-selector contract. The method checks critical empirical precision ratios, including endpoint ownership, and exports input-bound interval and observation certificates for an independently implemented checker. Controlled program experiments show differences missed by sampled policies, while a separate external study replays an upstream-confirmed scikit-learn curve-truncation defect through an unchanged policy consumer. On that case, full-domain checking and a thirteen-point grid find the same affected workloads; the method additionally localizes the exact policy region. A direct SMT encoding agrees on every evaluated Boolean equivalence task, showing that full-domain comparison itself is not unique to our partition implementation. The revised executable adapter refuses unreviewed sources and invalid runtime behavior rather than treating unsupported programs as equivalent. Local subprocess measurements assess integration cost, including a 100,000-observation fixture. The evidence supports a specialized, endpoint-correct verification and diagnostic capability. It does not establish arbitrary-program verification, a general real-defect detection rate, independent deployment validation, or first-in-literature novelty of parameter-region reasoning.

Keywords: regression testing; precision constraint; policy equivalence; certifying computation; independently checkable evidence.

'''
    text=text[:text.index('## Abstract')]+abstract+text[text.index('## 1. Problem'):]
    refs='''
[14] scikit-learn issue #23213 (2022). precision_recall_curve is not returning the full curve at high recall. Upstream bug report and maintainer discussion. https://github.com/scikit-learn/scikit-learn/issues/23213

[15] scikit-learn PR #23214 (2022). FIX compute precision-recall at 100% recall. Merged 2 May 2022. https://github.com/scikit-learn/scikit-learn/pull/23214

[16] de Moura, L.; Bjørner, N. (2008). Z3: an efficient SMT solver. TACAS. https://www.microsoft.com/en-us/research/publication/z3-an-efficient-smt-solver/

[17] McConnell, R. M.; Mehlhorn, K.; Näher, S.; Schweitzer, P. (2011). Certifying algorithms. Computer Science Review, 5(2), 119–161. https://doi.org/10.1016/j.cosrev.2010.09.009

[18] Provost, F.; Fawcett, T. (2001). Robust Classification for Imprecise Environments. Machine Learning, 42, 203–231. https://arxiv.org/abs/cs/0009007

[19] Chen, F.; Roşu, G. (2009). Parametric trace slicing and monitoring. TACAS, 246–261. https://experts.illinois.edu/en/publications/parametric-trace-slicing-and-monitoring/

[20] Dehnert et al. (2015). PROPhESY: A PRObabilistic ParamEter SYnthesis Tool. CAV. Author manuscript: https://www.cs.ru.nl/personal/nilsjansen/files/publications/dehnert-et-al-cav-2015.pdf
'''
    (Q/'docs/RELATED_WORK_V3.md').write_text(smt+'\n'+refs,encoding='utf-8')
    (Q/'docs/EXTERNAL_CASE_AND_FAIL_CLOSED_V3.md').write_text(external+safety,encoding='utf-8')
    return text+'\n'+refs
