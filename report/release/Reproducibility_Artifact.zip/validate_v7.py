"""Audit query evidence, exact prior-release evidence and interface refusals."""
from pathlib import Path
from fractions import Fraction as F
import json,csv,hashlib,copy
from policy_domain_query import answer,verified_answer
from domain_query_study import queries
Q=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    R=Q/'results/v7';prior=Q/'evidence/V6_FINAL_RELEASE_EVIDENCE';p=read(prior/'RELEASE_VERIFICATION.json')
    assert p['status']=='PASS' and len(p['stages'])==27 and all(s['exit_code']==0 for s in p['stages'])
    assert p['archive_sha256_before']==p['archive_sha256_after']=='ec708e725b6ee0f369c156ddaec401f6bdcc8d8ad0681d1e8026638096128de0'
    for name,digest in read(prior/'EVIDENCE_MANIFEST.json').items():assert sha(prior/name)==digest
    summary=read(R/'domain_query_summary.json');assert summary['status']=='PASS' and summary['smt_unknown']==0
    assert summary['study_source_sha256']==sha(Q/'domain_query_study.py') and summary['query_source_sha256']==sha(Q/'policy_domain_query.py')
    rows=list(csv.DictReader((R/'domain_query_results.csv').open(encoding='utf-8')));protocol=dict(queries())
    assert len(rows)==288 and len({(r['case_id'],r['query']) for r in rows})==288
    for row in rows:
        w=read(Q/'results/v6/scipy_defect_certificates'/(row['case_id']+'_affected.json'));q=protocol[row['query']];r=answer(w['certificate'],q)
        assert r['affected']==(row['affected']=='True')==(row['smt_verdict']=='sat')
        assert row['certificate_witness']==(r['witness'] or '') and row['affected_count']==str(r.get('affected_count',''))
        if int(row['direct_policies']):assert int(row['direct_affected'])==r['affected_count'] and int(row['direct_policies'])==r['allowed_count']
        assert float(row['certificate_query_ms'])>=0 and float(row['smt_build_solve_ms'])>=0
    assert sum(int(r['direct_policies']) for r in rows)==summary['direct_policies_enumerated']
    for group in summary['by_query']:
        selected=[r for r in rows if r['query']==group['query']];assert len(selected)==36 and group['affected_workloads']==sum(r['affected']=='True' for r in selected)
        if group['affected_policy_workload_pairs'] is not None:assert group['affected_policy_workload_pairs']==sum(int(r['affected_count']) for r in selected)
    # Input binding must run before permitting certificate reuse, even for a safe query.
    w=read(Q/'results/v6/scipy_defect_certificates/upstream_int8_affected.json');q=protocol['declared_three'];assert verified_answer(w,q)['verification']['verified']
    bad=copy.deepcopy(w);bad['actual_scores'][0]+=0.125
    try:verified_answer(bad,q)
    except AssertionError:pass
    else:raise AssertionError('Tampered input was accepted')
    result={'status':'PASS','prior_v6_exact_stages':27,'prior_v6_archive_sha256':p['archive_sha256_before'],'query_answers_reconciled':len(rows),'direct_policy_checks':summary['direct_policies_enumerated'],'smt_answers_agree':288,'tampered_input_rejected_before_query':True,'scope':'Local controlled functional validation, not independent developer evaluation or new bug corpus'}
    (R/'validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
