"""Replay the additional documented defect and reconcile targeted V6 evidence."""
from pathlib import Path
from fractions import Fraction as F
import json,csv,math,hashlib
import numpy as np
from scipy_documented_defect import Q,functions,regression_test,sha,cases
from streaming_checker import verify
from independent_oracle import candidates,select
from policy_exact import DEFAULT
from expanded_region_benchmark import fixture,prepare
from complete_region_comparison import verify_regions,member
from policy_significance import lattice_hits

def read(p):return json.loads(p.read_text(encoding='utf-8'))
def rows(p):return list(csv.DictReader(p.open(encoding='utf-8')))
def main():
    R=Q/'results/v6';prior=Q/'evidence/V5_FINAL_RELEASE_EVIDENCE';pr=read(prior/'RELEASE_VERIFICATION.json')
    assert pr['status']=='PASS' and len(pr['stages'])==23 and pr['archive_sha256_before']==pr['archive_sha256_after']=='4a580830ee0a2c4d5cf78290b80312c28e8cc4a2f66fabfcc40568432492a2c1'
    for name,digest in read(prior/'EVIDENCE_MANIFEST.json').items():assert sha(prior/name)==digest
    sig=read(R/'policy_significance_summary.json');assert sig['status']=='PASS' and sig['source_sha256']==sha(Q/'policy_significance.py')
    rr=rows(R/'policy_significance_cases.csv');assert len(rr)==30;values=[];visible=0;records={r['case_id']:r for r in read(Q/'inputs/manifest.json')['cases']};observed_max=F(0);supremum_max=F(0)
    for row in rr:
        c=read(Q/'results/v5/second_project_certificates'/(row['case_id']+'.json'));psc=F(c['psc_exact']);assert row['psc_exact']==str(psc)
        if psc>0:values.append(psc)
        assert int(row['max_changed_observations'])==max((int(p['reference_bits'],16)^int(p['actual_bits'],16)).bit_count() for p in c['probes'])
        assert F(row['precision_shortfall_supremum_exact'])>=F(row['max_actual_precision_shortfall_exact'])
        data=np.load(Q/'inputs'/records[row['case_id']]['file']);y=data['y'][:64];observed=F(0);supremum=F(0);lookup={F(p['alpha']):int(p['actual_bits'],16) for p in c['probes']};cuts=list(map(F,c['critical_values']))
        def precision(bits):return F(sum(int(y[i]) for i in range(len(y)) if bits>>i&1),bits.bit_count())
        for a,bits in lookup.items():
            if bits:observed=max(observed,a-precision(bits))
        supremum=observed
        for left,right in zip(cuts,cuts[1:]):
            bits=lookup[(left+right)/2]
            if bits:supremum=max(supremum,right-precision(bits))
        assert F(row['max_actual_precision_shortfall_exact'])==observed and F(row['precision_shortfall_supremum_exact'])==supremum
        observed_max=max(observed_max,observed);supremum_max=max(supremum_max,supremum)
        visible+=int(row['representable_policy_differences'])>0
        for digits in [2,3,4,6]:
            count=0;scale=10**digits
            for r in c['divergent_regions']:
                lo=F(r['lo'])*scale;hi=F(r['hi'])*scale;first=math.floor(lo)+1;last=math.ceil(hi)-1
                if r['left_closed'] and lo.denominator==1:first=int(lo)
                if r['right_closed'] and hi.denominator==1:last=int(hi)
                count+=max(0,last-first+1)
            assert count==int(row[f'decimal_{digits}_affected_policies'])==0
            if digits==2:
                brute=sum(any(member(r,F(i,scale)) for r in c['divergent_regions']) for i in range(3*scale//10,9*scale//10+1))
                assert brute==count
    assert len(values)==27 and visible==19
    assert sig['max_precision_shortfall']==float(observed_max) and sig['max_precision_shortfall_supremum']==float(supremum_max)
    for key,q in [('min',0),('q25',.25),('median',.5),('q75',.75),('max',1)]:assert np.isclose(float(F(sig['positive_psc_distribution'][key]['exact'])),np.quantile([float(v) for v in values],q,method='linear'),rtol=1e-12,atol=1e-30)
    funcs,manifest,nodes=functions();assert regression_test(funcs['affected'])=='FAIL_EXPECTED_REGRESSION' and regression_test(funcs['fixed'])==regression_test(funcs['current'])=='PASS'
    sr=rows(R/'scipy_defect_results.csv');assert len(sr)==108;div=0;grid=0;snapshot=0;inputs={name:(x,knots,y,ids,rec) for name,x,knots,y,ids,rec in cases()};assert len(inputs)==36
    for row in sr:
        saved=read(R/'scipy_defect_certificates'/row['certificate_file']);x=np.asarray(saved['axis_values'],dtype=saved['axis_dtype']);knots=np.asarray(saved['knot_scores']);y=np.asarray(saved['labels']);ids=saved['ids'];scores=np.asarray(funcs[row['variant']](x,knots,kind='nearest')(x),dtype=float)
        xx,kk,yy,ii,rec=inputs[row['case_id']];assert x.dtype==xx.dtype and np.array_equal(x,xx) and np.array_equal(knots,kk) and np.array_equal(y,yy) and ids==ii
        assert saved['source_input_sha256']==(rec['sha256'] if rec else None)
        assert np.array_equal(scores,saved['actual_scores']) and np.array_equal(knots,saved['reference_scores'])
        if row['variant']!='current':assert saved['source_ast_sha256']==nodes[row['variant']]
        c=saved['certificate'];v=verify(y,knots,scores,ids,c);assert v['probes']==int(row['independent_probes'])
        gold=candidates(y,knots,DEFAULT);actual=candidates(y,scores,DEFAULT);snap=select(gold,F(1,2),True,DEFAULT)[2]!=select(actual,F(1,2),True,DEFAULT)[2];gr=any(select(gold,F(3,10)+F(3,5)*i/12,True,DEFAULT)[2]!=select(actual,F(3,10)+F(3,5)*i/12,True,DEFAULT)[2] for i in range(13))
        assert str(snap)==row['snapshot_detected'] and str(gr)==row['grid_detected'] and c['psc_exact']==row['psc_exact'] and str(not c['equivalent'])==row['policy_divergent']
        if row['variant']=='affected':div+=not c['equivalent'];grid+=gr;snapshot+=snap
        else:assert c['equivalent']
    sm=read(R/'scipy_defect_summary.json');assert sm['status']=='PASS' and sm['source_sha256']==sha(Q/'scipy_documented_defect.py') and div==sm['affected_policy_divergent']==31 and grid==sm['grid_detected']==31 and snapshot==sm['snapshot_detected']==26
    allowed=rows(R/'scipy_allowed_policy_counts.csv');assert len(allowed)==36
    for row in allowed:
        wrapper=read(R/'scipy_defect_certificates'/(row['case_id']+'_affected.json'));regions=[c for c in wrapper['certificate']['cells'] if not c['equal']]
        for digits in [2,3,4,6]:assert int(row[f'decimal_{digits}_affected_policies'])==lattice_hits(regions,digits)
    for summary in sig['documented_scipy_defect_decimal_resolution']:
        key=f"decimal_{summary['decimal_places']}_affected_policies";assert summary['affected_workloads']==sum(int(r[key])>0 for r in allowed)==31 and summary['affected_policy_workload_pairs']==sum(int(r[key]) for r in allowed)
    lm=read(R/'large_g_summary.json');assert lm['status']=='PASS' and lm['source_sha256']==sha(Q/'large_g_region_benchmark.py');raw=rows(R/'large_g_raw.csv');assert len(raw)==36;certs={};checks=0
    for p in (R/'large_g_certificates').glob('*.json'):
        c=read(p);y,s=fixture(c['n'],c['g']);assert hashlib.sha256(y.astype('<i8').tobytes()+s.astype('<f8').tobytes()).hexdigest()==c['input_sha256'];gold,actual=prepare(y,s,c['pattern']);verify_regions(gold,actual,c['certificate'])
        if c['case_id'] in certs:assert certs[c['case_id']]==c['certificate']
        certs[c['case_id']]=c['certificate'];checks+=1
        if c['method']=='smt_all_regions':assert c['algorithm_stats']['residual_result']=='unsat'
    assert checks==12 and len(certs)==6
    for case,c in certs.items():
        for method in ['partition','smt_all_regions']:
            group=[r for r in raw if r['case_id']==case and r['method']==method];assert sorted(int(r['replicate']) for r in group)==[0,1,2]
            for r in group:assert int(r['components'])==len(c['divergent_regions']) and r['psc_exact']==c['psc_exact'] and np.isclose(float(r['total_checked_ms']),sum(float(r[k]) for k in ['preparation_ms','producer_serialization_ms','checker_ms']),rtol=1e-12)
    result={'status':'PASS','prior_v5_final_stages':23,'significance_workloads_reconciled':len(rr),'decimal_policy_resolutions_checked':[2,3,4,6],'scipy_certificates_replayed':len(sr),'scipy_affected_policy_divergent':int(div),'scipy_grid_detections':int(grid),'scipy_snapshot_detections':int(snapshot),'additional_documented_defects':1,'larger_g_tasks':6,'larger_g_certificates_replayed':checks,'larger_g_timing_records_reconciled':len(raw)}
    (R/'validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
