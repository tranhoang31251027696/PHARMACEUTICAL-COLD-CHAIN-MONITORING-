# Exact Policy-Aware Regression Diagnosis for Precision-Constrained Threshold Selectors

**Research manuscript V11, revised on 30 October 2026.**

## Abstract

Changes to precision-constrained threshold selectors can preserve selected observations at one policy while changing them elsewhere. We present exact policy-aware regression diagnostics for fixed observations, returning complete divergent regions with endpoint ownership and input-bound certificates checked by a separate implementation. The method specializes established finite-region and certifying-computation techniques; it does not introduce a new general parameter-synthesis algorithm. Controlled program experiments identify 136 nonconforming runs, versus 111 with a thirteen-point grid. Historical-source replay of two documented upstream defects supports applicability, while adding no affected workload over that grid. A Boolean-only query index avoids constructing full intersection output while retaining the full certificate's independent verification obligations. Paired measurements separate this API cost from certificate preparation and from direct-mask or incremental-SMT request costs, whose evidence obligations differ. The resulting contribution is auditable regression localization with explicit numerical semantics and measured engineering tradeoffs. Developer triage benefit and production-policy effectiveness remain unmeasured.

Keywords: regression diagnosis; precision constraints; policy equivalence; independently checked certificates; allowed policy domains.

## 1. Problem, scope and contribution

For a precision-constrained threshold selector, a software change may preserve the selected observations at one policy while changing them elsewhere in an allowed domain. A score-structural change alone does not establish a policy regression. We compare selected observation IDs under an agreed empirical contract: labels and aligned IDs are fixed, candidates come from a finite family of score thresholds, and feasibility, priority and abstention are explicit. The question is equality throughout the caller's permitted policy set and, when equality fails, its exact location and a checkable observation witness.

Parameter-region reasoning [6,7,20], predicate enumeration [23–25] and certifying computations [9,17] provide the closest foundations. Our contribution is their specialization to this selector contract and an executable evidence pipeline. It comprises endpoint-sensitive diagnostic cells with exact numerical-interface semantics; input-bound certificates and a separately implemented consumer; and checked permitted-domain queries, evaluated with controlled programs, documented source replays and explicit cost protocols. Boolean and full-output certificate APIs are compared under the same certificate obligations, while direct-mask/SMT request costs are kept distinct. The finite partition, interval indexing and producer/checker principles are established techniques.

The related work Exact Candidate Frontier Comparison for Decision Regression Testing of Precision-Constrained Selectors [29] is an unpublished manuscript supplied by the authors, who confirmed that status for this revision. It already introduces the observation contract, compact candidate-frontier comparison and checked proper-prefix attribution. Its labels/ID conventions, inherited observations and 255 counterfactual grid records are reused here. This extension studies selected-ID equivalence over policy domains and adds complete interval certificates, independent streaming consumption, explicit rational/binary64 semantics, executable conformance studies and verified domain-query interfaces. INHERITANCE_AND_PUBLICATION_BOUNDARY.md maps the reused and added components to hash-bound source snapshots. The earlier contract, witness machinery and reused data are not counted as new contributions.

## 2. Research questions

RQ-A Correctness and inherited evidence: Does exact comparison preserve the stated selector contract, endpoint ownership and inherited grid outcomes, including zero-measure differences?

RQ-B Testing and complete diagnostics: Which changes are detected in executed programs and documented upstream cases, and how do partition and SMT costs vary when both must return the same complete diagnostic output?

RQ-C Certification and cost: Can independent certificate consumption retain coverage, membership, witness and metric obligations with lower measured memory/time, and what computational costs remain?

RQ-D Allowed domains and the cost of verified reuse: How do rational and binary64 policy interfaces differ, which declared policy domains intersect a change, and how do query-API cost and evidence-production obligations change the measured workflow tradeoff?

The four questions separate correctness, testing and diagnostics, certification cost, and permitted-domain reuse. Corpora, numerical contracts and timing protocols remain separate.

## 3. Contract and formal characterization

Observation IDs are fixed, unique and aligned across versions. Labels are binary and fixed. Scores are finite. Each observed score threshold induces a nonempty complete-group candidate C_j with TP k_j and count n_j. Feasibility means alpha <= k_j/n_j, including equality. Among feasible candidates choose lexicographic maximum (k_j,n_j); abstain if none is feasible or the entire label vector has no positives. The policy domain A=[L,H] is specified with exact rational endpoints, 0<=L<H<=1. The inherited API excluded alpha=0; the extension defines its natural feasibility behavior explicitly.

**Finite partition theorem.** Let B contain L, H and all candidate precision ratios of either version in (L,H). Both selected memberships are constant on each open interval between successive B values. Therefore equivalence throughout A holds if and only if memberships agree at each B value and one representative in each open interval.

**Proof.** Candidate feasibility is a comparison to its fixed ratio. Without a critical ratio inside an open interval, no feasibility predicate can change there. With fixed candidate priority and abstention, the selected membership is fixed. Singletons handle inclusive boundaries. These atoms partition the domain, proving necessity and sufficiency. Strict-feasibility mutants use the same critical values with different singleton outcomes. A midpoint alone is insufficient unless the critical set is complete.

Define D_A={alpha in A: S_old(alpha) != S_new(alpha)}. The policy sensitivity coverage is PSC=length(D_A)/(H-L), computed as an exact fraction. This is a uniform-domain length ratio, not a failure probability or risk measure. Equivalence implies PSC=0; the converse fails for endpoint-only divergences. With y=[1,0], s=[1,0] and A=[1/2,1], inclusive and strict feasibility differ only at 1/2 and 1, yielding PSC=0 while full equivalence is false. An explicit automated test checks this counterexample.

Detailed assumptions, proof of prefix-membership equality, complexity, certificate trust boundaries and witness limitations are in [FORMAL_SPECIFICATION_AND_PROOFS.md](FORMAL_SPECIFICATION_AND_PROOFS.md).

## 4. Algorithm and certificate

Sort each version's scores, accumulate complete-group TP/N counts, and form exact reduced fractions. Sweep the union of critical policies in increasing order, evaluating every singleton and open midpoint. A priority heap removes candidates once they become infeasible; each candidate is removed at most once. Empirical precision need not be monotone along score prefixes. For reference selectors the largest feasible prefix is optimal because TP is nondecreasing with prefix size, but an explicit heap supports the reverse-secondary-order mutant too.

Given equally sized winning prefixes of size n, selected membership is equal exactly when the maximum new rank among old selected IDs is below n. Inverse ranks and prefix maxima make each equality check constant-time after preprocessing. For a divergent pair, a scan counts changed rows and supplies one observation ID whose old/new membership differs. Cache each distinct state pair and merge only adjacent identical states while preserving endpoint closure.

The certificate records selector contracts, input SHA-256, domain, all critical fractions, state intervals, membership counts, an equality verdict, optional observation witness and exact PSC. It does not store all selected IDs; the original input arrays are needed for verification. The independent verifier constructs actual threshold masks and integer bitsets, independently derives critical values, and checks coverage, winners, witnesses, counts and PSC. It shares the mathematical contract, but not the production heap or rank comparator.

With G total score candidates and K critical values, core time is O(N log N+G log G+K) under unit-cost rational operations; witness scans add O(ND) for D distinct divergent state pairs. Auxiliary memory is O(N+G+K). Arbitrary-precision comparison has additional bit complexity. The independent verifier deliberately uses more expensive threshold-mask enumeration. No machine-checked proof or arbitrary black-box program verification is claimed.

## 5. Evaluation design

Inherited evidence comprises all 50 retained comparisons (not only prior frontier-only positives), all 17 frozen synthetic fixtures and the public WDBC pilot. Their original data lineage is preserved. The 23 cases contributing the earlier 255 grid configurations are checked directly against those CSV records.

New pipelines comprise ten seeded splits for each of WDBC logistic + isotonic calibration, digits zero-vs-rest LinearSVC + sigmoid calibration, and generated imbalanced classification with random forest + score quantization. Fitting/calibration/evaluation indices are disjoint and exported; the RF reserves its unused calibration split. Test labels do not train or calibrate the model, but do define the empirical selector being tested. Ten splits are repetitions on one dataset family, not ten independent deployments. Small WDBC isotonic calibration is used as a structural workload; no calibration-quality advantage is claimed. Base numerical comparisons use float32 score casts, not naturally observed dependency releases.

Each newly fitted base input has eight selector/numerical variants, one row-ID fault and three valid controls. Variants change inclusive precision, threshold comparison, secondary priority, candidate omission, complete ties, feasibility counts, quantization or roundoff-scale scores. They are executable semantic fault models rather than a general source-code mutation engine. Full details appear in [MUTATION_PROTOCOL.md](MUTATION_PROTOCOL.md).

Snapshot and grid tests observe actual configured mutant outputs. B4/current guard observe score arrays and do not inspect changed selector code. Their aggregate scores therefore have different scope. An exact certificate is configured with the mutant's declared finite contract; applying it to arbitrary real software requires a faithful adapter. Detection of the declared fault model does not certify that adapter automatically.

Correctness tests enumerate 4,680 binary-score/label pairs up to N=4 and 6,174 ternary-score cases up to N=3 (10,854 total), plus 1,000 seeded randomized variants. Additional pytest checks cover endpoint-only changes, invalid values/shapes, aligned identities, abstention, certificate tampering and actionable CI failures. These are finite implementation checks, not a proof of universal program correctness.

## 6. RQ-A Correctness and inherited evidence

All 42 core pytest test items pass, including the exhaustive and randomized loops. Application and mutation certificates are independently reverified against frozen inputs; detailed counts are in `results/artifact_verification.json`.

| Cohort | Pairs | Policy-sensitive pairs | Domain |
| --- | --- | --- | --- |
| Independent_pipeline | 30 | 1 | [0.30,0.90] |
| Public_WDBC | 1 | 1 | [0.30,0.90] |
| Retained | 50 | 40 | [0.30,0.80] |
| Synthetic | 17 | 11 | [0.30,0.80] |

All 255 old grid outcomes and selected counts match. Among those 23 selected historical cases, exactly 15 are sensitive on their complete domains, the same case count found by the old grid; the extension supplies exact intervals rather than discovering additional historical sensitive cases. It would be misleading to present the new method as uncovering missed cases in that subset.

For public WDBC, the precise divergent set is (43/51,9/10] on [3/10,9/10], giving divergent length 29/510 and PSC=29/306 (approximately 0.09477). The boundary 43/51 is excluded: equality still holds there. The old grid's two divergent values 0.85 and 0.90 are consistent with this interval.

Of 30 newly trained float32-cast comparisons, only `digits_svc_sigmoid_seed2` is policy-sensitive, with PSC=25/5084. This low frequency is reported as observed, without treating engineered mutations as naturally occurring numerical regressions.

Version outputs, numerical bridges and the distinction between policy differences and defects are detailed in Supplement S1.


## 7. RQ-B Executed testing and diagnostic value

There are 360 runs: 240 selector/numerical variants, 30 row-identity violations, and 90 valid controls. Of the 240 variants, 183 are policy-divergent and 57 are equivalent on the tested input/domain. All 30 identity violations are separately rejected; PSC is not assigned to them. No exact policy alarm is raised for the 90 controls.

| Test observation | Detected / 183 divergent mutants | Rate |
| --- | --- | --- |
| Selected membership at alpha=0.50 | 112/183 | 61.2% |
| Thirteen-point output harness | 157/183 | 85.8% |
| Score-only B4 structural flag (different scope) | 47/183 | 25.7% |
| Current score guard at alpha=0.50 (different scope) | 47/183 | 25.7% |
| Exact configured policy certificate | 183/183 | 100.0% |

The thirteen-point grid misses 26 divergent variants: 15 have positive-length divergent intervals and 11 differ only at critical points. Exact verification's 183/183 is agreement with an independent finite oracle for configured variants, not a general real-fault detection rate. Shared formal assumptions and known mutant semantics limit this evidence.

The operator-level breakdown is retained in Supplement S12 and the raw mutation records.


Across observed policy-equivalent variant/control runs, B4 raises 9 structural flags and the current guard raises 42 broad regression flags. These are not automatically errors: the tools have different observation contracts, and the current guard also observes numerical cutoff changes. We therefore avoid relabeling every frontier difference or threshold change as a policy defect. On selector-only faults with unchanged scores, the score tools lack the observation needed to see the modified code.

Supplement S2 documents source admission and the distinction between observed conformance and inference of an arbitrary program specification.


### Documented external defect and independent upstream code

To move beyond a locally designed source-mutant corpus, we add scikit-learn issue #23213 [14] and its merged fix #23214 [15]. The confirmed defect concerns truncation of the precision-recall curve after first reaching full recall. A curve consumer can consequently miss lower thresholds that retain all positives while adding further observations. That matters to this paper's explicit secondary objective: among candidates with maximum TP, prefer the largest feasible selected set. The omission is not automatically a defect in every downstream application; we evaluate its propagation under this particular, unchanged consumer contract.

We freeze the full upstream metrics source file at scikit-learn 1.0.2 commit `7e1e6d09bcc2eaeba98f7e737aac2ac782f0e5f1` and at the PR merge commit `32c53bc69cc0d1f142700dd6c02281a000b855b9`. SHA-256 values, upstream URLs, and BSD license files accompany them. We compile and execute the original `precision_recall_curve` function nodes without rewriting their bodies. The installed scikit-learn 1.9.1 supplies its public counting routine through a compatibility bridge; every returned precision/recall value is checked against direct membership counts. This is isolated historical-source replay, not installation of an old release binary. We also execute the installed current curve implementation and check its returned thresholds against the fixed-source result. A 1.1.0 snapshot inspected during provenance checks still contained the truncation path, so we do not incorrectly label that tag as the fix.

The frozen inputs comprise the upstream report's synthetic-data/logistic protocol fitted using the current environment, plus the same thirty pipeline workloads used earlier. The report protocol fits and evaluates its classifier on the same rows to expose a metrics defect; no generalization claim follows. One bug exercised on these inputs remains one independently documented defect, not thirty-one independent software projects or defects. Historical fitted coefficients and a historical binary environment were not reproduced.

All methods receive the same actual upstream threshold outputs and the same exact TP/N feasibility and selected-membership objective. The common consumer adapter compares the complete-group reference family to the returned threshold family. It excludes the plotting sentinel that has no corresponding threshold. It derives exact integer counts from the associated masks rather than mistaking floating-point precision rounding for the upstream truncation bug. This curve-consumer adapter is separate from the local alpha-guard program adapter; it does not imply that arbitrary upstream Python passed our local source-admission policy.

| Evidence | Result |
|---|---|
| External projects and upstream-confirmed defects | 1 project, 1 defect |
| Input workloads and variant/input executions | 31 workloads, 93 executions |
| Affected-source workloads with policy divergence | 15 |
| Snapshot / grid / full-domain detections on those workloads | 14 / 15 / 15 |
| Fixed-source and installed-current policy false alarms | 0 |

The original report protocol reproduces a policy difference, with exact PSC 2059/5862 on [0.30,0.90]. Across all thirty-one workloads, fifteen exhibit policy effects; snapshot detects fourteen, while grid and full-domain checking both detect fifteen. Thus this external case establishes useful detection and localization of a documented external defect, but supplies no additional detected case over the thirteen-point grid. We report that null comparison directly. Sixteen workloads show no policy effect in the permitted domain despite the documented library defect. The fixed and current variants conform in all evaluated workloads. We do not pool these workloads with the internal mutant denominators or relabel the nine SciPy version differentials as confirmed bugs.

### Additional documented defect in an independent upstream project

SciPy issue #6318 [27] reports incorrect nearest-neighbor interpolation for integer axes; merged PR #6351 [28] fixes overflow in midpoint construction by dividing before addition. We freeze the exact pre-merge parent `3565a801587a699d2f320a6406d0f38f86c0c4b0` and merge `7a46deb6b272fb8cdf4348cb3db45ca0ef3b2636`, with source, upstream tests, SHA-256 values and BSD license. The original regression test uses int8 knots [0,50,127] and requires interpolation at those knots to reproduce their values. Executing its unchanged test body fails on affected source and passes on fixed source and installed SciPy 1.18.1.

We compile the original interp1d class and its two fill-value helpers without rewriting method bodies. A compatibility namespace maps the removed NumPy float_ alias to float64 and supplies the modern _Interpolator1D base helper. Only the nearest branch on the stated finite one-dimensional inputs is evaluated. AST/source digests and the helper hash are recorded. This is isolated historical-source replay with a transparent bridge, not installation of an old SciPy binary, the reporter's complete original time series, or general equivalence of the historical and modern libraries. The overflow-causing integer addition remains unchanged; the matched fixed/current controls reproduce knot scores exactly.

The six prespecified axis fixtures include the upstream int8 axis, derived int16, Unix-second int32 and aligned large int64 axes, plus small-int32 and float64 controls. We additionally attach synthetic int32 Unix-second axes to the first 64 rows of all thirty existing pipeline score vectors and query at the observed knots. The scores/labels remain frozen; these row-index time carriers are constructed propagation fixtures, not independently collected time-series applications. Correct interpolation at observed knots is an identity requirement. The unchanged downstream consumer then compares selected IDs under the same rational precision objective.

| Evidence | Result |
|---|---|
| Workloads / variant-workload executions | 36 / 108 |
| Affected-source score changes / policy-divergent workloads | 34 / 31 |
| Snapshot / grid / full-domain detections on divergent workloads | 26 / 31 / 31 |
| Fixed-source and current policy false alarms | 0 |

The 108 input-bound core certificates are independently replayed using actual interpolation outputs, exact membership checking and source/input bindings. Among the 31 affected workloads, PSC ranges from 0.055556 to 1.000000, markedly wider than the binary64 contract differences below. Five affected workloads are missed by snapshot; grid and full-domain both detect all 31. Thus incremental real-defect workload detection over grid remains zero; complete diagnostics add localization and replayable membership evidence. Thirty-four changed score vectors do not imply thirty-four policy regressions, and thirty-one divergent workloads remain one documented defect. Across studies, the confirmed-defect count is now two, in scikit-learn and SciPy; eval-toolkit remains a separate contract-differential case. These projects share numerical dependencies and provide no multi-team deployment or real-bug detection-rate estimate.

## 8. RQ-C Certificate production cost

| N | G old (nominal bins) | Workload | Witness enabled | Median ms | IQR ms | Peak aux MiB | Witness cells |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1000 | 20 | divergent | False | 9.55 | 1.53 | 0.10 | 0.0 |
| 1000 | 20 | divergent | True | 8.26 | 1.55 | 0.10 | 4.0 |
| 1000 | 20 | invariant | False | 4.81 | 1.05 | 0.09 | 0.0 |
| 1000 | 20 | invariant | True | 4.99 | 0.84 | 0.09 | 0.0 |
| 10000 | 100 | divergent | False | 62.46 | 14.70 | 1.00 | 0.0 |
| 10000 | 100 | divergent | True | 63.02 | 22.87 | 1.00 | 29.0 |
| 10000 | 100 | invariant | False | 35.65 | 2.15 | 0.91 | 0.0 |
| 10000 | 100 | invariant | True | 34.97 | 1.71 | 0.91 | 0.0 |
| 100000 | 500 | divergent | False | 520.59 | 120.04 | 9.22 | 0.0 |
| 100000 | 500 | divergent | True | 528.06 | 40.73 | 9.24 | 111.0 |
| 100000 | 500 | invariant | False | 368.19 | 103.85 | 8.80 | 0.0 |
| 100000 | 500 | invariant | True | 341.13 | 60.75 | 8.80 | 0.0 |

All rows use ten measured repetitions after warmup on one Windows host, Python 3.12.10/NumPy 2.3.5, with randomized mode order, tracemalloc enabled and JSON serialization included. Peak is auxiliary MiB with preallocated inputs excluded, not process RSS. The N=100,000 divergent witness-enabled median is 528.06 ms (IQR 40.73), emitting 111 witness-bearing state cells; the corresponding witness-disabled median is 520.59 ms (IQR 120.04). These runs activate witness construction, unlike the earlier one-policy invariant guard benchmark. No significance, independence, universal speed advantage, or direct cross-protocol latency ratio is asserted. Raw chronological records and exact seeds/generation code are included.

Supplement S3 retains the preparation-matched implementation timing protocol. Its methods have different diagnostic scope and are not a capability-adjusted speed ranking.


Supplement S4 reports the within-invocation phase ablation. Component medians need not sum to the median total.


### RQ-B Diagnostic-complete comparison across workload structure

Both implementations must return the same maximal divergent components, exact endpoint ownership, exact PSC, separate Boolean equivalence and one representative policy/row witness per component. A representative witness is existential at its reported policy, not one observation changing throughout a component. SMT repeatedly finds a QF_LRA model, expands it to its complete feasibility-predicate cell, blocks that cell, and finishes only at residual UNSAT. Unknown/timeout prevents certification. General predicate enumeration is established [23-25]; complete diagnostics are not a unique capability of our partition method.

The eight V4 external affected/fixed tasks remain a separate check and still agree. We add a prespecified factorial design: N in {1,000,10,000,100,000}, G in {10,30,90}, and no, one-middle, or alternating candidate omission. Scores form G tied groups with gradually decreasing group-positive proportions; fixed-seed permutations remove dependence on row order. These designed families yield 0–39 divergent components. They are controlled tasks, not new upstream defects or independent deployments. Every one of the 27 tasks is retained, including empty-divergence controls.

Five repetitions per method/task, with randomized method order inside each repetition, produce 270 timing records and 54 saved certificates. Both methods receive the same candidate family, regenerate counts/masks during each timed preparation, emit the same diagnostic JSON and invoke the same independent region checker. All complete outputs agree and every saved certificate is replayed. Preparation, producer plus serialization, checker, total checked cost, candidate counts, exact critical-point count, divergent components, probes, bytes and solver calls are retained separately. Thus input-size effects are not inferred from a preparation-excluded timer alone.

The table shows N=100,000; the raw factorial records preserve the other scales. Total includes fresh preparation, complete diagnostic production/JSON and independent checking. Entries are within-task medians of five runs, not pooled medians across heterogeneous tasks.

| G / omission | Critical points | Components | Partition total ms | SMT total ms |
|---|---|---|---|---|
| 10 / alternating | 10 | 5 | 59.26 | 78.39 |
| 10 / none | 10 | 0 | 52.90 | 65.71 |
| 10 / one | 10 | 1 | 58.68 | 64.17 |
| 30 / alternating | 27 | 13 | 111.01 | 193.82 |
| 30 / none | 27 | 0 | 100.06 | 109.05 |
| 30 / one | 27 | 1 | 103.76 | 129.67 |
| 90 / alternating | 79 | 39 | 494.01 | 1058.73 |
| 90 / none | 79 | 0 | 323.85 | 317.51 |
| 90 / one | 79 | 1 | 329.47 | 391.97 |

Across all 27 designed tasks, partition has the smaller total median on 25; the other 2 have an equal or smaller SMT median. These descriptive comparisons do not establish statistical significance, superiority for arbitrary selectors or parity with an optimized general AllSMT solver. This is our direct Z3 encoding and generic external-table partition adapter, not a reproduction of TabularAllSMT or a benchmark of the compact rank-based producer. The region checker still enumerates prepared memberships and is distinct from the new streaming consumer for the core certificate format. Evidence supports scoped cost characterization and common diagnostic correctness; broader performance claims remain unsupported.

### RQ-B Extension to larger candidate counts

The previous G<=90 factorial is extended with six additional prespecified tasks at N=10,000, G in {250,500} and the same none/one/alternating omission patterns. Both algorithms still produce identical complete diagnostics. Three repetitions per method, randomized within each replicate, yield 36 raw timing records and twelve independently replayed certificates. No task is dropped for being unfavorable. Residual UNSAT is required for SMT completion; unknown or timeout would prevent certification.

| G / omission | Critical points | Components | Partition total ms | SMT total ms |
|---|---|---|---|---|
| 250 / none | 215 | 0 | 986.40 | 797.28 |
| 250 / one | 215 | 1 | 735.13 | 918.14 |
| 250 / alternating | 215 | 107 | 973.93 | 3649.18 |
| 500 / none | 430 | 0 | 3618.14 | 2268.31 |
| 500 / one | 430 | 1 | 3993.99 | 4715.14 |
| 500 / alternating | 430 | 215 | 5291.80 | 21336.96 |

Totals include fresh candidate preparation, complete region/witness production plus JSON and the same region checker. The new cases reach 430 critical points and 215 divergent components. Three repetitions are descriptive and are not pooled with the older five-repetition protocol. The prepared-membership region checker is distinct from the streaming consumer for the core certificate schema. These results extend the evaluated candidate range, but do not establish asymptotic superiority, a deployment SLO, or a win over an independently optimized AllSMT implementation. The baseline remains our direct Z3 encoding; modern enumeration methods [25] retain capabilities and optimizations this study does not benchmark.

## 9. Integration and practical output

`policy_cli.py` loads aligned NPZ arrays and writes a certificate after independent verification. `--fail-on-divergence` yields exit code 1 and a concrete interval/row witness. The pytest assertion wrapper reports the first divergent state; equality returns a certificate. An example GitHub Actions workflow runs tests and artifact verification locally configured for this folder. The workflow is supplied as a template; it has not been uploaded or executed on a remote CI service.

Supplement S5 documents unsupported-source fixtures, runtime refusals and CLI exit semantics. Refusal is never interpreted as equivalence.


Supplement S6 reports actual local subprocess invocations. There is no remote CI, deployment SLO or measured policy-frequency claim.


Supplement S7 documents the executed TunedThresholdClassifierCV public-API adapter, its exact scorer and configuration refusals. It is another component of scikit-learn, not an additional independent project.


### RQ-C Streaming certificate consumption

The legacy verifier first materializes all Boolean threshold masks. Its independently measured cost motivated a second consumer, not a change to the producer or finite partition theorem. The new implementation imports neither production code nor the legacy checker. It counts one threshold mask at a time, retaining only exact ratios, actual TP/N and candidate descriptors. A reverse suffix-maximum table over ascending feasibility ratios supplies exhaustive-priority winners by exact bisection. It reconstructs and packs only the current winning mask for each version. It uses no production priority heap or rank-containment comparator and retains no all-candidate bitset cache.

The suffix winner argument is direct: feasible candidates form a suffix (lower bound for inclusive feasibility, upper bound for strict feasibility), and reverse induction computes that suffix's maximum fixed priority. Independent critical-point construction, ordered certificate coverage and endpoint ownership then justify checking all atom representatives. A forward cell cursor validates each probe; actual bitsets validate equality, witness IDs/memberships and changed-row counts. Exact divergent length and PSC are independently recomputed. Detailed lemmas and conditional soundness are in STREAMING_CHECKER_AND_FLOAT_CUT_PROOFS.md. These are mathematical arguments plus tests, not a machine-checked proof or independent human replication.

The consumer uses O(N+G+K+C) auxiliary descriptors/probes and current-mask storage, excluding arbitrary-precision operand sizes, for K critical values and C certificate cells. Direct counting and winner reconstruction retain worst-case O(NG) work; split-tie ordering adds O(N log N), with ratio/query/probe sorting costs stated in the proof supplement. In particular, G=N can still be quadratic. Suffix maxima, bisection and streaming are established techniques [17], not new general primitives.

All 428 frozen application/mutation certificates are accepted under the same obligations as the legacy checker, covering 41,348 probes. New exhaustive small-input comparisons exercise seven specifications; tamper tests reject altered bindings, partitions, winners and metrics, and retain point-only non-equivalence. 42 core tests pass; eval-toolkit's eighteen threshold tests are counted separately; the SciPy regression-test replay belongs to its dedicated study.

The paired experiment regenerates the same six N/G fixtures as the earlier checker study, prepares an identical certificate/payload outside timing, warms up both consumers, and randomizes their order within each of five repetitions. JSON parsing is recorded separately. A sixth invocation per consumer/group traces memory independently. The sixty untraced timing records and twelve separate memory records are never pooled. Each row below compares identical inputs, policies, coverage, hash and witness obligations; these are not ratios against the differently instrumented producer benchmark.

| N / fixture | Legacy median (IQR), ms | Streaming median (IQR), ms | Legacy peak MiB | Streaming peak MiB |
|---|---|---|---|---|
| 1,000 / invariant | 6.41 (0.67) | 2.56 (0.15) | 0.04 | 0.04 |
| 1,000 / divergent | 26.98 (1.38) | 6.24 (0.46) | 0.09 | 0.04 |
| 10,000 / invariant | 130.23 (12.14) | 27.72 (6.19) | 1.33 | 0.63 |
| 10,000 / divergent | 1859.66 (59.43) | 145.62 (22.20) | 3.56 | 0.63 |
| 100,000 / invariant | 7097.14 (759.47) | 1843.19 (48.92) | 61.42 | 6.00 |
| 100,000 / divergent | 35034.92 (360.42) | 3557.72 (139.89) | 169.85 | 6.00 |

Memory peaks are auxiliary allocations with inputs/certificate prepared in advance and one traced run per group. Five timings on one host do not establish a universal CI budget. The implementation preserves a deliberately different verification route while reducing retained masks; shared dependencies and mathematical assumptions remain trusted. Results show an implementation tradeoff under this contract, not a general theorem that checking is always cheaper than production.

### RQ-D An executed second project and its actual policy semantics

We build a wheel from the complete, unmodified eval-toolkit 1.12.0 source at commit `a6400e74c4534d6d79f17dee11ad903b6d664980`, retaining hashes, its MIT license and package metadata. Python 3.13.18 satisfies its >=3.13 requirement. The installed TargetPrecisionSelector is called through its actual public API; no method body is extracted, patched or replaced with a custom scorer. All eighteen packaged upstream threshold tests pass. The package and source are distributed for offline installation. The external case studies now execute code from scikit-learn, eval-toolkit and SciPy; eval-toolkit depends on scikit-learn's precision-recall routine, so this is not independent numerical infrastructure or independent institutional deployment.

The workload rule is fixed: first 64 rows of all thirty existing pipeline inputs, with no positive-case filtering. The wrapper passes float(alpha) to the public precision parameter and maps only the documented no-feasible RuntimeError to abstention. Its exact-reference objective is still maximum (TP,N); in the same nested family, this equals the project's smallest-feasible-threshold objective. Input validation, source identity and candidate counts are checked. Actual floating precision values are compared against direct integer membership counts.

It would be unsound to assume a binary64 guard changes exactly at the rational ratio k/n. For an actual binary64 precision p, let q=nextafter(p,+infinity) and c=(exact(p)+exact(q))/2. The public predicate p >= float(alpha) changes at c, including equality exactly when p has the even significand. The proof follows monotone nearest/even rounding and is a selector-specific application of established rounding-preimage reasoning [26]. We explicitly check midpoint ownership and both neighboring cells on the runtime. The complete critical set is the union of rational-reference cuts, these rounding-cell cuts and domain endpoints. A model of these guards is checked against every actual public-API output, including all endpoints; unsupported numerical behavior must prevent certification.

Across thirty workloads, 884 critical-point/midpoint policies and 1500 public invocations (including the grid/snapshot baselines) are executed. The guard model matches every actual output. Twenty-seven workloads have narrow differences from the exact rational reference; neither snapshot nor the thirteen-point grid detects any of them. These are twenty-seven semantic differentials, not twenty-seven bugs or regressions between upstream releases. The library documents a floating policy interface, so the rational reference is a caller-selected stronger/different contract, not an upstream requirement it is shown to violate. This numerical-contract case adds no confirmed defect; on the documented scikit-learn defect, incremental detection over grid remains zero.

Each input-bound certificate preserves exact rounding-cut fractions, ownership, actual/reference bitsets, row witnesses, complete divergent regions and PSC. The validator calls the installed selector again at all 884 policies and checks every stored field. We additionally probe actual representable binary64 precision policies: 196 such probes expose differences on 19 workloads. Grid/snapshot targets are exact rational fractions, whereas this additional group embeds each binary64 value by its exact integer ratio; it does not reinterpret a decimal grid target as its binary approximation. Thus the continuous-domain finding is not automatically equated to a difference at a policy the float API can represent. With labels [1,1,0,0,0] ordered by decreasing distinct score, the representable float 0.4 exceeds exact 2/5: at the exact rational embedding of that float, the float selector admits all five while the rational reference admits four. At exact decimal 2/5 both admit five. This is a designed explanation of distinct policy contracts, not a newly documented upstream bug. Tiny interval length is not a deployment probability or impact estimate. Adoption should decide whether binary64 semantics are acceptable, rather than treating every differential as a release-blocking defect.

### RQ-D Policy width and practical significance

The twenty-seven numerical-contract differentials have extremely small policy measure. We compute all quantiles using exact fractions and linear interpolation before converting only display values to scientific notation. Three further workloads have zero PSC; Boolean equivalence and endpoint evidence remain separate properties. The distribution below is conditional on the 27 positive-PSC workloads, not all thirty observations and not a probability distribution of deployed policies.

| Positive-PSC statistic | Value |
|---|---|
| min | 1.541976e-17 |
| q25 | 1.659852e-16 |
| median | 3.747190e-16 |
| q75 | 6.795052e-16 |
| max | 1.660140e-15 |

At individual verified policies, membership can still change: across these fixtures the maximum changed-ID count is 41 of 64. The largest precision shortfall observed at stored probes is 1.048544e-16; separately, the exact supremum across all covered cells is 1.048544e-16. That supremum includes limits at open cell endpoints and need not be attained. These quantities do not turn a tiny arithmetic discrepancy into demonstrated harm. The observed labels provide no deployment-frequency, utility, monetary loss or human-outcome data.

We intersect the exact divergent components with four explicitly declared policy lattices on [0.30,0.90]. Policies are rational decimal targets, not exact embeddings of their binary64 approximations. Intersection is computed algebraically from integer bounds and endpoint ownership; it does not claim to make millions of public-API calls. Earlier complete partition validation supplies coverage of the intervals, and the validator cross-checks closed/open lattice boundaries.

| Decimal places | Allowed policies per workload | Workloads with an affected policy | Affected policy/workload pairs |
|---|---|---|---|
| 2 | 61 | 0 / 30 | 0 |
| 3 | 601 | 0 / 30 | 0 |
| 4 | 6,001 | 0 / 30 | 0 |
| 6 | 600,001 | 0 / 30 | 0 |

For these measured workloads, applications restricted to any one of those decimal lattices have no affected allowed policy under the declared reference/interface mapping. That is equality on a specified finite policy set, not continuous-domain equivalence or a proof that arbitrary workloads are safe. Conversely, zero interval length can still include an allowed singleton; a dedicated boundary test prevents confusing PSC=0 with finite-set equality. The nineteen representable-binary64 examples use a different exact policy embedding, as explained above, and are not silently substituted for decimal targets.

The practical role of the tiny-region certificates is therefore narrow: auditing a strict numerical contract, documenting a numerical-interface migration, or deciding whether an explicitly permitted policy set intersects a difference. They do not demonstrate an extra bug or justify blocking every routine CI job. An application may accept the binary64 contract or define a restricted decimal policy set; such a choice must be declared before interpreting a report. We preserve the exact diagnostic result rather than erasing small regions with a tolerance and calling the versions universally equivalent. The separate SciPy defect study shows broad policy effects, but its constructed propagation cases likewise do not supply operational impact or deployment rates.

If an application already declares a small finite allowed set, exhaustive checking of every member is itself complete for that set. Continuous-domain certification is not required for completeness on that set; its cost tradeoff is evaluated separately below. Its additional value is the reusable exact region description and contract-localized explanation; its actual frequency and human utility remain unmeasured.

The same exact permitted-set assessment is applied separately to the SciPy defect fixtures: at two decimal places, 31 of 36 workloads have affected targets, comprising 1,611 of 2,196 allowed policy/workload pairs. Per-case counts for all four resolutions are retained in scipy_allowed_policy_counts.csv. These are constructed-fixture coverage counts, not observed deployment frequencies or independent defect counts.

### Verified reuse for declared policy domains

A positive grid result answers whether a tested policy exhibits a difference. A release decision may instead ask which allowed targets are affected, whether every target in a proposed interval is safe, or whether a changed permitted set still intersects a previously diagnosed difference. We implement an explicit rational-domain query interface after independent input-bound certificate verification. It accepts finite sets, decimal lattices and intervals with declared endpoint ownership; it returns affected counts for finite domains or exact intersected cells for intervals, plus a rational witness when affected. Tampered input, an out-of-domain request and a binary64 query passed to the rational interface are refused. The result is conditional on the frozen inputs, admitted selector contract and successful certificate verification.

We predeclare eight scenarios and apply every one to all 36 existing SciPy affected-source workloads, without selecting for query outcomes. The finite set {0.50,0.80,0.90}, decimal lattices on [0.30,0.90], and continuous intervals are study scenarios, not elicited requirements from deployed applications. Original interpolation code is executed once per variant/workload to obtain the scores. Certificates are then independently checked before reuse. Direct mask enumeration uses those cached executed outputs and separately prepared candidate masks; it does not rerun interpolation for every target.

| Allowed policy scenario | Policies per workload | Workloads with an affected target | Affected policy/workload pairs |
|---|---|---|---|
| Thirteen-point grid | 13 | 31 / 36 | 340 |
| Declared set {0.50,0.80,0.90} | 3 | 30 / 36 | 86 |
| Decimal lattice 2 places | 61 | 31 / 36 | 1,611 |
| Decimal lattice 3 places | 601 | 31 / 36 | 15,886 |
| Decimal lattice 4 places | 6,001 | 31 / 36 | 158,657 |
| Decimal lattice 6 places | 600,001 | 31 / 36 | 15,863,561 |
| Closed interval [0.30,0.90] | Continuous | 31 / 36 | Not a finite count |
| Closed interval [0.80,0.90] | Continuous | 30 / 36 | Not a finite count |

All 288 query answers agree with a direct Z3 encoding constructed from independently enumerated candidate masks, not from certificate regions. The SMT objective compares selected-ID bitsets, so differing score orderings remain covered. A lattice uses an integer policy index; an interval uses a real policy variable. SAT supplies a rational witness checked against direct selection, UNSAT establishes absence for that encoded query, and timeout/unknown aborts the study. No unknown occurs. Exhaustive enumeration of both finite sets and the two- and three-place lattices checks 24,408 policies and agrees on all affected counts. Four- and six-place counts come from exact lattice intersection, not millions of API calls. Those per-query records retain descriptive single-invocation costs and initial verification; the repeated batch-cost protocol below is a separate experiment.

For pipeline_axis_generated_rf_quantized_seed7, the continuous interval is affected but the declared three-element set is not. Thus a domain-specific report can support accepting that scenario's finite policy set while continuing to report non-equivalence elsewhere. This does not make that policy set a real deployment requirement, nor does it show a new defect missed by grid. On both documented defects the thirteen-point grid already detects every affected workload. The added evidence concerns exact scope, counts, boundaries and reuse of a checked diagnostic object.

General SMT can answer the same questions and agrees here. For a fixed small finite set, exhaustive direct testing is complete for that set and can be the simpler engineering choice. A checked certificate is a useful reusable representation when multiple rational-domain queries or exact localization are required; its net cost depends on construction, verification, storage and query volume. We have not measured developer triage benefit, a deployment break-even point, or superiority over an independently optimized parametric verification tool. This study supports functional diagnostic utility and explicit limitations, rather than a broader real-bug detection claim.

### Evidence obligations and the Boolean only certificate API

The earlier V8 experiment measured the cost of current implementations answering Boolean queries, not equal evidence-production obligations. Its full certificate API created counts or all intersections before projection. Direct masks and incremental Z3 did not emit or independently verify a complete diagnostic certificate. We retain those 720 measurements separately in Supplement S14 and results/v8; they are not pooled with the following experiment.

We add VerifiedBooleanIndex. Its constructor copies and independently verifies the complete input-bound certificate, merges adjacent unequal cells only when their shared endpoint is included, and freezes a rational interval index with the checked input digest. A matching singleton hole between two open unequal regions is preserved. A query searches the ordered component endpoints and returns only Boolean existence plus one rational policy witness; it never constructs the full intersection list. Finite-set and decimal-lattice queries retain explicit rational semantics, domain validation and endpoint ownership. Counts and complete intersected regions remain available from the original API. This is an application of established interval union and binary search, not new parameter-region theory.

After construction, interval and singleton queries take O(log C) rational comparisons plus bounded candidate checks over C maximal components. A finite set performs point queries after validation/deduplication. A lattice may scan O(C) components before finding a lattice member or establishing absence, so it has no logarithmic worst-case claim. Construction and full independent checking remain separate costs; arbitrary-precision operands matter. BOOLEAN_QUERY_AND_ASSURANCE.md gives the reasoning and exact interface. Four targeted tests exercise zero-measure divergence, a matching singleton hole, input tamper/immutable reuse and unsupported domains.

| Route | Complete certificate produced | Independent full certificate check | Query operation used here |
|---|---|---|---|
| Full certificate API | Yes | Yes | Full API, then Boolean/witness projection |
| Boolean certificate API | Yes | Yes, with the same checker | Indexed Boolean/witness lookup |
| Direct masks | No persisted complete certificate | No certificate to check | Exact masks/critical-cell evaluation |
| Incremental Z3 | No complete diagnostic certificate | No exported proof/certificate checked | SAT/UNSAT with rational SAT witness |

All four answer the same selected-ID existence question. This table distinguishes evidence obligations, not exact versus approximate answers. The assurance-matched panel compares the two certificate routes: both include construction, JSON roundtrip and independent full verification; the Boolean route additionally includes copying, merging, freezing and indexing. The four-route panel measures implementation request costs with different evidence artifacts and trust boundaries. Rechecking a positive witness outside timing does not independently certify a direct negative result or a solver's UNSAT proof.

### Paired query API costs on the existing plans

We reuse the same six V8 inputs, two request types and distinct rational point/window plans, with batch sizes 1/8/32/128. No new cases or production policies are claimed. Five fresh setups per batch/method, one warmup per case/type/method and seeded randomized method order yield 960 measurements and 192 median/IQR groups. The 2,028 existing case/query plans yield 40,560 repeated answers across four methods and five repetitions; all agree and saved rational witnesses are checked against independent selection. These repetitions do not enlarge the empirical defect corpus. The original direct-mask and incremental push/pop Z3 implementations are reused unchanged. Common interpolation, imports, disk I/O and human activity are excluded for every route. There is no result memoization and all requests within a batch differ.

The table shows batch-128 total median milliseconds, including each route's setup. Phase medians, IQRs and every other batch remain in boolean_summary.csv and boolean_raw.csv; no medians are pooled across inputs. The paired comparison uses these new measurements only.

| Workload | Request | Full certificate | Boolean certificate | Direct masks | Incremental Z3 |
|---|---|---|---|---|---|
| Upstream int8 | Point | 3.41 | 2.62 | 1.75 | 45.44 |
| Upstream int8 | Window | 11.23 | 6.03 | 10.50 | 74.22 |
| Unix int32 | Point | 7.16 | 4.89 | 2.06 | 91.57 |
| Unix int32 | Window | 7.84 | 2.61 | 7.63 | 56.65 |
| Small int32 control | Point | 3.59 | 3.68 | 1.95 | 32.11 |
| Small int32 control | Window | 5.52 | 3.26 | 9.53 | 24.25 |
| WDBC seed 0 | Point | 15.01 | 7.59 | 2.77 | 111.84 |
| WDBC seed 0 | Window | 27.29 | 5.70 | 11.96 | 84.00 |
| Digits seed 0 | Point | 43.92 | 10.80 | 19.31 | 189.20 |
| Digits seed 0 | Window | 177.87 | 16.38 | 32.18 | 164.59 |
| RF seed 0 | Point | 11.40 | 6.01 | 6.05 | 163.68 |
| RF seed 0 | Window | 21.06 | 5.93 | 10.75 | 129.52 |

In the assurance-matched panel, Boolean lookup lowers the query-phase median in 12/12 batch-128 combinations, by 2.06–35.39 times. Including all setup, its total median is lower in 11/12 combinations; the remaining cases are retained. Thus part of V8's cost came from the full API's output construction, while construction and independent certificate checking still have a price. These are descriptive paired medians on one host, not a statistical significance result or a universal speed guarantee.

In the four-route request-cost panel, the Boolean route has lower total medians than direct masks for 2/6 point and 6/6 window inputs, and than this incremental Z3 encoding for 6/6 and 6/6. Those comparisons have the unequal obligations shown above and are not a ranking of equal verification guarantees or optimized external tools. Direct checking remains a valid simpler choice for a small finite allowed set. Computational reuse results do not measure developer debugging time, production policy requirements, institutional adoption or deployment break-even. The contribution remains exact diagnosis and checkable evidence with explicit interface and cost boundaries.

## 10. Threats to validity

Internal and construct validity. The independently coded checker shares the written contract with the producer and may share conceptual errors; finite tests are not a machine-checked proof. Input hashes protect accidental binding integrity, not source authenticity or label quality. PSC measures interval length, excludes isolated points and is not a deployment probability. The declared-semantics study supplies mutant contracts; the program-conformance study instead uses an unchanged reference, with source admission and guard-coverage assumptions limiting its scope.

External validity. Historical cases are related, generated fixtures are controlled, and pipeline seeds repeat three local dataset families. The two documented defects are historical-source replays through compatibility bridges with constructed propagation carriers and shared dependencies. Grid13 detects every affected workload in both cases, so no added real-bug detection rate is established. Results concern fixed labeled inputs, not predictive generalization. There is no independent developer triage study, production-policy inventory or prospective deployment.

Performance validity. Results come from one host and modest repetitions; allocation tracing and untraced timings are separate protocols. Input/candidate structure and arbitrary-precision arithmetic matter, and checking/witness work can remain O(NG)/O(ND). The paired certificate APIs share full construction/checking obligations; four-route request costs do not share evidence-production obligations. Reported medians and speedups remain descriptive for each workload and protocol.

Contribution and overlap. Region partitioning, constrained selection, AllSMT and certificate checking have established foundations. The 28-source check is focused, not systematic, and does not prove absence of closer work. The related unpublished manuscript [29] is disclosed with its reused components; the current integration and evaluation do not establish general algorithmic originality or industrial effectiveness.

## 11. Related work and closest comparison

Rath and Hughes [1], Mackey et al. [2] and Tasche [3] establish constrained threshold-selection foundations; scikit-learn documents the calibration [5] and public selector [21] interfaces used here. Metamorphic/mutation testing of optimization and classifier implementations [4,11,12] provides the testing context. The inherited candidate-frontier manuscript [29] is related prior work, with its reused contract, data and witness machinery identified in Section 1.

Storm and parameter synthesis [6,7,20], regression verification [8], certifying computations [9,17], proof-carrying code [10], robust classification [18] and parametric monitoring [19] reason about related properties or evidence boundaries. Predicate enumeration and AllSMT [23–25] already support general solution-region exploration; rounding-preimage reasoning [26] underlies the numerical-interface mapping. These are positive foundations, not claims that existing tools lack endpoint or full-region capabilities. Our empirical SMT baselines encode the selected-ID contract directly; they do not reproduce an independently optimized AllSMT implementation.

The table separates executed same-contract comparisons from conceptual foundations. Complete-region protocols and request-cost protocols retain different outputs, obligations and timing boundaries. Supplement S10–S11 contains the detailed source distinctions; BIBLIOGRAPHY_AUDIT_V8.md and its V10 addendum record the source/metadata-check scope.

| Method considered | Matched question here | Evidence actually compared | Remaining distinction |
|---|---|---|---|
| Snapshot and thirteen-point probes | Membership compatibility at chosen policies | Executed on identical SUT outputs and contract | Cannot certify unprobed policies |
| Direct Z3 encoding | Existence of any divergent policy on finite nested candidates | 93 actual equivalence tasks, rational counterexample rechecks | One counterexample/Boolean rather than all intervals and PSC |
| SMT predicate-cell enumeration [16,23] | Complete divergent regions, exact PSC and representative witnesses | Eight external, 27 factorial and six larger-G tasks; complete outputs and checker agree | Same-score nested candidate encoding and finite feasibility predicates |
| Our partition and checker | Same Boolean task plus full divergence localization | Exact endpoints, intervals and independently replayed memberships | Specialized finite contract and explicit adapter assumptions |
| Certifying computations [9,17] | Trust in a particular computation and checker | Primary-source conceptual comparison | General foundation, not an empirical competing selector tool |
| PROPhESY/Storm [6,7,20] | Parameter-region property verification | Primary-source property/input-model comparison | No faithful probabilistic encoding benchmark claimed |
| Parametric monitoring [19] | Monitoring properties across parameter instances | Primary-source semantic comparison | Object/trace parameters differ from empirical precision breakpoints |
| Robust classification [18] | Classifier choice as operating conditions vary | Primary-source objective comparison | Does not make the finite-breakpoint idea novel |

## 12. Conclusion

For fixed observations and precision-constrained threshold selectors, the specified contract supports exact selected-ID equivalence, complete divergent regions with endpoint ownership and input-bound diagnostic evidence. An independently implemented consumer checks that evidence; the Boolean index avoids full query-output construction while retaining the same certificate obligations as the full API. Matched API costs and four-route request costs answer different questions and remain separated.

The evaluation supports scoped correctness, localization and engineering-cost findings. It does not establish additional affected-workload detection over grid on the two documented defects, general speed superiority, developer productivity or production-policy effectiveness. The contribution is a specialized auditable diagnostic pipeline, with established foundations and inherited work [29] explicitly disclosed.

## Reproducibility and declarations

Frozen inputs, split manifests, source, tests, raw timing records and all certificates are in this research artifact. The original submission package and sealed archive are preserved. Author-owned source carries the accompanying MIT LICENSE; the existing copyright-holder placeholder is unchanged. Dataset and dependency licenses are not replaced. Newly trained pipeline arrays derive from the bundled WDBC snapshot, scikit-learn digits and generated data. The extension includes local assistant-generated code and prose; human authors must validate, assume responsibility for results, and complete author/funding/contribution and generative-AI declarations before submission.

Supplement S9 details the historical standalone repair, frozen-input execution, optional retraining and the limits of each assurance layer.


### Reproduction and source integrity

The standalone artifact contains the code, frozen inputs, dependencies and source-integrity bindings needed by its 33-stage default entry point. Files named after earlier revisions implement cumulative experiments and audits within this single artifact; reproducing the study does not require executing earlier release ZIPs, installing earlier project versions, or accessing a neighboring submission directory. Default execution reuses frozen scores; optional retraining and historical dependency-binary execution are distinct procedures with additional requirements.

V11 repairs platform-dependent output of generated Python snapshots: mutant and failure-fixture source files are written as explicit UTF-8 bytes with LF newlines. Their byte hashes remain checked; newline normalization is not applied to arbitrary source or input files. Copied execution-source snapshots retain the actual source bytes. A focused regression test exercises generation from CRLF input and rejects subsequent byte tampering. All source changes are recorded in the V11 binding manifest; the historical V10 classification of 138 strict bindings plus one controlled generated snapshot is not an assertion that V11 source remains unchanged.

The exact final artifact is frozen before execution; its detached execution report binds its SHA-256 and records every stage exit status. The report is distributed alongside the artifact, avoiding a self-referential archive hash. A local Windows execution establishes neither native Linux validation nor independent institutional reproduction. The reading copy uses the recorded measurement snapshot; rerun results retain their own timing records. See REPRODUCIBILITY_V11.md for commands, scope and release-evidence locations.

## References

[1] Rath, P.; Hughes, M. (2022). Optimizing Early Warning Classifiers to Control False Alarms via a Minimum Precision Constraint. PMLR 151, 4895–4914. https://proceedings.mlr.press/v151/rath22a.html

[2] Mackey, A.; Luo, X.; Eban, E. (2018). Constrained Classification and Ranking via Quantiles. https://arxiv.org/abs/1803.00067

[3] Tasche, D. (2018). A plug-in approach to maximising precision at the top and recall at the top. https://arxiv.org/abs/1804.03077

[4] Duque-Torres, A.; Klammer, C.; Fischer, S.; Pfahl, D.; Ramler, R. (2025). Assessing the strength of Metamorphic Testing applied to optimisation software—Experience from industry. Information and Software Technology, 186, 107807. https://doi.org/10.1016/j.infsof.2025.107807

[5] scikit-learn developers. CalibratedClassifierCV, version 1.9.1 documentation. https://scikit-learn.org/stable/modules/generated/sklearn.calibration.CalibratedClassifierCV.html (accessed 30 October 2026).


[6] Storm project. Running Storm on Parametric Models. Official documentation. https://www.stormchecker.org/documentation/usage/running-storm-on-parametric-models (accessed 30 October 2026).

[7] Junges, S.; Ábrahám, E.; Hensel, C.; Jansen, N.; Katoen, J.-P.; Quatmann, T.; Volk, M. (2024). Parameter synthesis for Markov models: covering the parameter space. Formal Methods in System Design, 62, 181–259. https://doi.org/10.1007/s10703-023-00442-x

[8] Godlin, B.; Strichman, O. (2009). Regression Verification. DAC. Author manuscript: https://ofers.dds.technion.ac.il/publications/dac09.pdf

[9] Alkassar, E.; Böhme, S.; Mehlhorn, K.; Rizkallah, C. (2013). A Framework for the Verification of Certifying Computations. https://arxiv.org/abs/1301.7462

[10] Necula, G. C.; Schneck, R. R. (2002). Proof-Carrying Code with Untrusted Proof Rules. International Symposium on Software Security. Author manuscript and formalization: https://people.eecs.berkeley.edu/~necula/ISSS02/

[11] Yang, Y.; Li, Z.; Wang, H.; Xu, C.; Ma, X. (2021). Towards effective metamorphic testing by algorithm stability for linear classification programs. Journal of Systems and Software, 180, 111012. https://doi.org/10.1016/j.jss.2021.111012

[12] Xie, X.; Ho, J. W. K.; Murphy, C.; Kaiser, G.; Xu, B.; Chen, T. Y. (2011). Testing and validating machine learning classifiers by metamorphic testing. Journal of Systems and Software, 84(4), 544–558. https://doi.org/10.1016/j.jss.2010.11.920

[13] SciPy project. Release news and versions 1.15.3 and 1.18.1. https://scipy.org/news/


[14] scikit-learn issue #23213 (2022). precision_recall_curve is not returning the full curve at high recall. Upstream bug report and maintainer discussion. https://github.com/scikit-learn/scikit-learn/issues/23213

[15] scikit-learn PR #23214 (2022). FIX compute precision-recall at 100% recall. Merged 2 May 2022. https://github.com/scikit-learn/scikit-learn/pull/23214

[16] de Moura, L.; Bjørner, N. (2008). Z3: an efficient SMT solver. TACAS. https://www.microsoft.com/en-us/research/publication/z3-an-efficient-smt-solver/

[17] McConnell, R. M.; Mehlhorn, K.; Näher, S.; Schweitzer, P. (2011). Certifying algorithms. Computer Science Review, 5(2), 119–161. https://doi.org/10.1016/j.cosrev.2010.09.009

[18] Provost, F.; Fawcett, T. (2001). Robust Classification for Imprecise Environments. Machine Learning, 42, 203–231. https://arxiv.org/abs/cs/0009007

[19] Chen, F.; Roşu, G. (2009). Parametric trace slicing and monitoring. TACAS, 246–261. https://experts.illinois.edu/en/publications/parametric-trace-slicing-and-monitoring/

[20] Dehnert, C.; Junges, S.; Jansen, N.; Corzilius, F.; Volk, M.; Bruintjes, H.; Katoen, J.-P.; Ábrahám, E. (2015). PROPhESY: A PRObabilistic ParamEter SYnthesis Tool. CAV, LNCS 9206, 214–231. https://www.cs.ru.nl/personal/nilsjansen/files/publications/dehnert-et-al-cav-2015.pdf


[21] scikit-learn developers. TunedThresholdClassifierCV API: callable scorer, explicit threshold arrays and prefit configuration. https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.TunedThresholdClassifierCV.html (accessed 30 October 2026).

[22] Behring, B. eval-toolkit: threshold selection methodology and source. https://brandon-behring.github.io/eval-toolkit/methodology/thresholds.html ; pinned packaging/source at https://github.com/brandon-behring/eval-toolkit/tree/a6400e74c4534d6d79f17dee11ad903b6d664980 (accessed 30 October 2026).

[23] MathSAT developers. API reference: msat_all_sat, enumeration over important atoms. https://mathsat.fbk.eu/apireference.html (accessed 30 October 2026). Used to contextualize predicate enumeration, not as an evaluated implementation.


[24] Morettin, P.; Passerini, A.; Sebastiani, R. (2017). Efficient Weighted Model Integration via SMT-Based Predicate Abstraction. IJCAI, 720–728. https://www.ijcai.org/proceedings/2017/100

[25] Spallitta, G.; Sebastiani, R.; Biere, A. (2025). Disjoint projected enumeration for SAT and SMT without blocking clauses. Artificial Intelligence, 345, 104346. https://doi.org/10.1016/j.artint.2025.104346

[26] Andrlon, M. (2023). Finding Normal Binary Floating-Point Factors Efficiently. Journal of Automated Reasoning, 67, article 11. https://doi.org/10.1007/s10817-023-09659-1


[27] SciPy issue #6318 (2016). Scipy interp1d nearest not working for high values on x-axis. Upstream defect report. https://github.com/scipy/scipy/issues/6318

[28] SciPy PR #6351 (2016). BUG: #6318 Interp1d nearest integer x-axis overflow issue fixed. Merged 6 July 2016. https://github.com/scipy/scipy/pull/6351

[29] Exact Candidate Frontier Comparison for Decision Regression Testing of Precision-Constrained Selectors. (2026). Unpublished related manuscript supplied by the authors; status confirmed by the authors for this revision. Source snapshot: provenance/q2_reference/main.tex.
