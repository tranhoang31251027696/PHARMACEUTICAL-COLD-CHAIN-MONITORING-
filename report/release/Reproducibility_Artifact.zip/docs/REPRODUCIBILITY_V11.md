# Reproduction V11

Run `python run_all.py` from the artifact root after installing requirements.txt in Python 3.13.18. All 33 stages use the one current artifact. Earlier revision numbers name cumulative stages, not required old releases. Bundled historical reports are read as provenance, not executed. Default execution uses frozen scores, the included historical CSV and offline eval-toolkit wheel.

V11 changes program_evaluation.py and failure_and_ci_evaluation.py to write generated Python snapshots as UTF-8 bytes with LF. The renderer preserves the canonical title punctuation. A focused CRLF-input and tamper regression is added. The repaired binding manifest is provenance/v11_source_bindings.json. V10's 138 strict + 1 controlled binding classification is historical, not a statement that all V11 source is unchanged.

The exact submission artifact is packaged once, then extracted to a fresh isolated directory and run. Detached RELEASE_VERIFICATION.json records its exact SHA-256, interpreter, environment, all stage exit codes and outputs; the archive is not rewritten afterwards. Execution is local Windows unless explicitly recorded otherwise. LF/CRLF tests simulate portability; they do not establish a native Linux full run.

Main and supplement PDF/DOCX are separate submission documents. Word/PDF production is outside the computational reproduction entry point. The main reading copy uses recorded benchmark snapshots; fresh timing outputs and regenerated Markdown remain separate records.
