"""Integrate measured onboarding, matched diagnostics and checker costs."""
import json,csv,re
import numpy as np

def integrate(Q,text):
    R=Q/'results/v4';on=json.loads((R/'onboarding_summary.json').read_text());cost=list(csv.DictReader((R/'checker_cost_summary.csv').open()));raw=list(csv.DictReader((R/'complete_region_timings.csv').open()))
    text=text.replace('29 October 2026.**','30 October 2026.**').replace('All 23 pytest test items pass','All 25 pytest test items pass')
    text=re.sub(r'The comparison below records what is demonstrated.*?directly comparable\.\n\n','',text,flags=re.S)
    text=text.replace('This is stronger substantiation than a scope-only table, but does not certify novelty at a particular journal tier.','This does not certify novelty at a particular journal tier.')
    text=text.replace('| Our partition and checker |','| SMT predicate-cell enumeration [16,23] | Complete divergent regions, exact PSC and representative witnesses | Eight matched tasks; complete outputs and independent checker agree | Same-score nested candidate encoding and finite feasibility predicates |\n| Our partition and checker |')
    start=text.index('## Abstract');end=text.index('Keywords:',start)
    abstract='''## Abstract

Regression tests at a nominal precision constraint can miss changed decisions elsewhere in an allowed policy domain. For a fixed finite binary dataset and deterministic threshold-selector contract, we compute exact selected-membership equivalence, endpoint-sensitive divergent regions, and input-bound certificates. In 210 controlled program runs, full-domain checking detects all 136 nonconforming runs, versus 111 for a thirteen-point grid. A separate replay of one upstream-confirmed scikit-learn defect yields fifteen affected workloads, all detected by both grid and full-domain methods. A matched SMT region-enumeration baseline returns the same complete diagnostics on eight tasks, limiting novelty claims to the specialized contract, diagnostic representation and scoped integration. Public-API onboarding of another selector component conforms at all 59 checked policies; it adds no independent project or confirmed defect. Separate measurements expose substantial certificate-checker cost at 100,000 observations. Immutable release archives are verified through detached hash-bound execution evidence. The results support a specialized verification technique, while multi-project defect validation and broader novelty assessment remain open.

'''
    text=text[:start]+abstract+text[end:]
    onboarding=f'''### Onboarding a public external selector beyond the source allowlist

We execute the installed scikit-learn `TunedThresholdClassifierCV` through its documented public API [21]. Its optimizer body is neither extracted nor edited, and it is not admitted by adding another local-program hash. A prefit score-carrier estimator exposes the frozen scores; a custom scorer returns TP*(N+1)+selected_count when the exact rational precision constraint holds and -1 otherwise. The multiplier preserves the lexicographic (TP,N) objective. Complete unique-score thresholds are passed explicitly. The adapter maps an infeasible optimum and the contract's no-positive case to abstention. These are explicit trusted integration choices, not claims about the library's default balanced-accuracy or cross-validation behavior. No predictive generalization or tuning-quality estimate is made from these fixed observations.

The workload rule is fixed before checking outcomes: seed zero from each of the three existing pipeline families, first 48 rows. WDBC, digits and random forest expose respectively 9, 48 and 13 unique thresholds. All {on['total_policy_probes']} critical-point and midpoint policies conform, with 2,150 actual scorer callbacks and zero membership mismatches. The validator independently rebuilds the exact masks and executes all 59 optimizer fits again. Four configurations are explicitly refused: an integer sampled grid, a missing observed threshold, cross-validation resampling, and refitting. Full-domain coverage follows only under the complete finite candidate and exact scorer contract. It does not extend to arbitrary changes of scorer, interpolation, resampling or estimator state.

Observed onboarding effort consists of {on['adapter_physical_lines']} physical Python lines in the executable study (including its measurement/report code), four public configuration hooks and zero upstream source edits. Source/class hashes, callbacks, decisions and execution times are retained. These are inspectable integration artifacts; programmer hours, independent team effort and maintenance costs were not measured. The scorer, score carrier and abstention mapping remain trusted glue.

We also inspect a second independently authored project, eval-toolkit [22], at commit `a6400e74c4534d6d79f17dee11ad903b6d664980`. Its source, tests, license and packaging metadata are hash-pinned. Its Python >=3.13 requirement is incompatible with our Python 3.12.10 environment. We record unsupported runtime, do not execute its package, and issue no policy certificate. This is a documented onboarding barrier, not a negative correctness result. The completed additional selector case is therefore a new component in the same external scikit-learn project; the executed external-project count remains one and the confirmed-defect count remains one.

'''
    regionrows=[]
    for variant in ['affected','fixed']:
        for method in ['partition','smt_all_regions']:
            rr=[r for r in raw if r['variant']==variant and r['method']==method]
            producer=[float(r['producer_and_serialization_ms']) for r in rr];checker=[float(r['independent_checker_ms']) for r in rr]
            regionrows.append(f"| {variant} | {method} | {np.median(producer):.3f} | {np.median(checker):.3f} |")
    regions='''### Matched complete-region diagnostics, including certification costs

The Boolean SMT comparison above is extended to the same diagnostic contract as a finite partition adapter: all maximal connected divergent components with exact endpoint ownership, exact PSC, a separate Boolean equivalence flag, and one representative policy/row witness per component. A representative witness is existential at its reported policy; it is not one observation that changes throughout the whole component. A point-only difference retains non-equivalence even when PSC is zero. Two added tests exercise that case and the empty-divergence case.

The second algorithm is an explicit Z3 QF_LRA encoding with finite predicate-cell enumeration. Each SAT model identifies a cell of constant feasibility truth; the algorithm blocks that entire cell and repeats until residual UNSAT. Blocking individual real-valued model points would not establish termination. There are finitely many empirical-ratio cuts, so at most their number plus two solver checks are allowed. This uses established AllSMT-style predicate reasoning [23]; MathSAT's reference documents AllSat over important atoms, but MathSAT itself was not benchmarked. Timeout or unknown prevents certification.

Both implementations receive identical prepared nested threshold tables. They use the same witness representation, serialization and independent membership-based coverage checker. The issue protocol and seed zero of each existing pipeline family provide four fixed representatives; affected and fixed variants yield eight tasks. Three repetitions per algorithm produce 48 measurements. Every complete output agrees; sixteen first-repetition certificates persist and are replayed independently. Rows below are descriptive medians across four workloads times three repetitions per variant/method, not independent defect counts.

| Variant | Method | Region construction + JSON (ms) | Independent checking (ms) |
|---|---|---|---|
'''+ '\n'.join(regionrows)+'''

Per-task raw records retain the differing input sizes, region counts, solver calls, certificate bytes and checker probes. Counts/mask preparation is excluded for both methods; representative witness construction and serialization are included in producer time. Input loading and whole-release validation are excluded. These timings describe the generic external-table partition adapter, not the faster rank-based comparison core. The shared checker can dominate either producer. No universal speed ranking, unique ability to find complete regions, or new general parameter-synthesis principle follows. The remaining contribution is the explicit precision-selector contract and diagnostic format, its checked implementation and scoped software integration.

'''
    cr=[]
    for r in cost:cr.append(f"| {int(r['n']):,} / {r['g']} | {r['workload']} | {float(r['checker_median_ms']):.2f} ({float(r['checker_iqr_ms']):.2f}) | {float(r['parse_median_ms']):.3f} | {float(r['separate_peak_aux_mib']):.2f} |")
    check='''### Independent certificate consumption at scale

The compact producer timings do not measure the independent verifier. We therefore time certificate consumption separately on invariant and divergent controlled fixtures at N/G=1,000/20, 10,000/100 and 100,000/500. The certificate and input arrays are prepared before measurement. After a warmup, five untraced repetitions time JSON parsing separately from full independent verification, including candidate reconstruction, hashes, coverage, PSC and witness checks. A separate sixth run measures traced peak auxiliary memory. Its time is not pooled with the untraced repetitions. The 36 raw records comprise thirty timings and six memory measurements; medians and linear IQRs are recomputed by the artifact validator.

| N / G | Fixture | Checker median (IQR), ms | JSON median, ms | Separate peak auxiliary MiB |
|---|---|---|---|---|
'''+ '\n'.join(cr)+'''

These costs are materially larger than compact production costs, especially for the divergent 100,000-row fixture. The independent implementation first materializes Boolean threshold masks before bitset packing; its peak scratch therefore includes O(NG) bytes, while packed memberships use O(NG) bits. Python integer operations have operand-size costs. The verifier is deliberately independent of the production heap/rank comparator, but it is not a constant-cost or universally cheap CI consumer. Five repetitions on one host and one separate memory run per group do not support a deployment SLO. A team must budget producer, checker, process startup and its actual case count separately.

'''
    release='''### Immutable final-archive reproduction

Earlier evidence described a candidate archive and matching source hashes. That is insufficient to claim execution of a differently hashed final ZIP. We close the historical V3 gap by extracting the exact delivered archive, SHA-256 `e45f431d77bd8102376aafd43c558b01a398cdbf98d9bb919ef079d90a7671c8`, and executing all fifteen stages successfully without an adjacent original submission. The detached report records the environment, each exit status, stage logs, output digests and unchanged archive hash. It verifies 1,219 manifest entries and hashes 1,001 output files. This demonstrates a fresh run of the actual V3 release, not independent human replication or identical wall-clock measurements.

The V4 release follows the same non-circular protocol with nineteen stages. Freeze source, measured tables and rendered reading copies first; package once; execute the extracted final ZIP; then publish its execution evidence outside the archive. `verify_release.py` accepts an archive, new work root, detached report directory and expected stage count. Its report binds the archive hash before and after execution. The new execution's raw timings and rebuilt Markdown are evidence in the extraction, while the frozen reading copy retains its original measured run. Timing values may differ. A report is not inserted into the archive whose hash it records, and the archive is not repackaged after verification. The actual V4 pass/fail outcome and digest belong to the detached release report delivered with the archive, not a self-referential claim in this manuscript.

'''
    text=text.replace('## 10. Threats',onboarding+check+'## 10. Threats')
    text=text.replace('## 12. Conclusion',regions+release+'## 12. Conclusion')
    text=text.replace('O(N*G) bits for stored membership masks','O(N*G) bits for packed membership masks, with O(N*G) bytes of Boolean scratch in this implementation')
    refs='''
[21] scikit-learn developers. TunedThresholdClassifierCV API: callable scorer, explicit threshold arrays and prefit configuration. https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.TunedThresholdClassifierCV.html (accessed 30 October 2026).

[22] Behring, B. eval-toolkit: threshold selection methodology and source. https://brandon-behring.github.io/eval-toolkit/methodology/thresholds.html ; pinned packaging/source at https://github.com/brandon-behring/eval-toolkit/tree/a6400e74c4534d6d79f17dee11ad903b6d664980 (accessed 30 October 2026).

[23] MathSAT developers. API reference: msat_all_sat, enumeration over important atoms. https://mathsat.fbk.eu/apireference.html (accessed 30 October 2026). Used to contextualize predicate enumeration, not as an evaluated implementation.
'''
    (Q/'docs/V4_ADDITIONAL_EVIDENCE.md').write_text(onboarding+regions+check+release+refs,encoding='utf-8')
    return text+'\n'+refs
