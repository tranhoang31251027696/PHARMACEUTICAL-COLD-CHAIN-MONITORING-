"""Targeted revision: operational scope, additional defect and grouped RQs."""
import json,csv,re
from fractions import Fraction as F
import numpy as np

def vietnamese_report(Q):
    return '''# Kết quả Q1 V6 ngày 30/10/2026

Bản đọc hiện tại: docs/MANUSCRIPT_Q1_V6.pdf/.docx. Xem RESPONSE_TO_REVIEW_V6.md và READ_ME_FIRST.md.

- Phân bố PSC của 27 numerical differentials được tính chính xác: median khoảng 3,75e-16, max khoảng 1,66e-15. Không có policy bị ảnh hưởng trên các lattice thập phân 2/3/4/6 chữ số trong 30 workload. Đây là kết quả giới hạn thực tế, không phải continuous equivalence hay xác suất lỗi.
- Sai khác có thể đổi tối đa 41 observation IDs tại một policy cụ thể dù precision shortfall chỉ khoảng 1,05e-16. Không có dữ liệu tần suất policy, utility, thiệt hại hay triển khai thực để suy ra risk/SLO.
- Thêm documented defect SciPy #6318, fix #6351: chạy nguyên class/helpers lịch sử qua bridge minh bạch, test hồi quy gốc fail ở affected và pass ở fixed/current. 36 workload/108 variant pairs; 31 có policy divergence rộng PSC 0,0556–1, snapshot 26, grid/full 31; fixed/current không false alarm. Đây là một lỗi mới, không phải 31 lỗi; không phải cài binary SciPy cũ hay tái lập dữ liệu đầy đủ của người báo lỗi.
- Mở rộng matched-region tới G=250/500: sáu task, 36 timing records, 12 certificates; complete outputs khớp. Không claim vượt mọi AllSMT hiện đại.
- Nhóm bảy RQ cũ thành bốn nhóm: correctness, testing/diagnostics, certification/cost, external contracts/operational scope. Làm rõ contribution là công cụ chẩn đoán chuyên biệt và checker đã kiểm chứng, không phát minh finite partition/streaming/AllSMT.
- Báo cáo đúng ZIP V5 đủ 23 stages nằm trong evidence/V5_FINAL_RELEASE_EVIDENCE. V6 có 27 stages; báo cáo chạy đúng ZIP cuối được giao riêng cùng DELIVERY bundle.

Hồ sơ hiện có hai upstream-confirmed defects ở scikit-learn và SciPy, cùng evaluation của eval-toolkit. Ba dự án vẫn có shared dependencies; dữ liệu propagation gồm các fixture/carrier có kiểm soát. Chưa có independent deployment hoặc kết luận sẵn sàng nộp Q1. Hồ sơ Q2 gốc giữ nguyên.
'''

def integrate(Q,text):
    R=Q/'results/v6';read=lambda p:json.loads(p.read_text(encoding='utf-8'));sig=read(R/'policy_significance_summary.json');bug=read(R/'scipy_defect_summary.json');large=read(R/'large_g_summary.json');raw=list(csv.DictReader((R/'large_g_raw.csv').open()))
    text=text.replace('Research manuscript V5 revised','Research manuscript V6 revised')
    text=text.replace('checks integration on two externally authored projects.','checks integration on three externally authored projects.')
    text=text.replace('The two externally authored projects executed across the studies are now scikit-learn and eval-toolkit, although the latter depends on scikit-learn\'s precision-recall routine;','The external case studies now execute code from scikit-learn, eval-toolkit and SciPy; eval-toolkit depends on scikit-learn\'s precision-recall routine, so')
    text=text.replace('The upstream-confirmed defect count remains one; on that documented scikit-learn defect, incremental detection over grid remains zero.','This numerical-contract case adds no confirmed defect; on the documented scikit-learn defect, incremental detection over grid remains zero.')
    text=text.replace('integration on two external projects','integration on three external projects').replace('Executing two external projects','Executing three external projects')
    text=text.replace('and one independently documented upstream case','and two independently documented upstream cases')
    text=text.replace('one isolated-source upstream defect case is now included','two isolated-source upstream defect case studies are now included')
    text=text.replace("the upstream project's eighteen tests are counted separately.","eval-toolkit's eighteen threshold tests are counted separately; the SciPy regression-test replay belongs to its dedicated study.")
    grouped='''## 2. Research questions

RQ-A Correctness and inherited evidence: Does exact comparison preserve the stated selector contract, endpoint ownership and inherited grid outcomes, including zero-measure differences?

RQ-B Testing and complete diagnostics: Which changes are detected in executed programs and documented upstream cases, and how do partition and SMT costs vary when both must return the same complete diagnostic output?

RQ-C Certification and cost: Can independent certificate consumption retain coverage, membership, witness and metric obligations with lower measured memory/time, and what computational costs remain?

RQ-D External numerical contracts and operational scope: How do exact rational and binary64 policy interfaces differ, and do those differences intersect the policies an application actually permits?

The four groups consolidate the former seven questions: A covers old RQ1–2, B old RQ3/5, C old RQ4/6 and D old RQ7. Results from different corpora, numerical contracts and benchmark protocols remain separate.

'''
    text=re.sub(r'## 2\. Research questions\n.*?(?=## 3\. Contract)',grouped,text,flags=re.S)
    text=re.sub(r'## 6\. .*?\n','## 6. RQ-A Correctness and inherited evidence\n',text,count=1)
    text=re.sub(r'## 7\. .*?\n','## 7. RQ-B Executed testing and diagnostic value\n',text,count=1)
    text=re.sub(r'## 8\. .*?\n','## 8. RQ-C Certificate production cost\n',text,count=1)
    text=text.replace('### RQ5 ','### RQ-B ').replace('### RQ6 ','### RQ-C ').replace('### RQ7 ','### RQ-D ')
    abstract='''## Abstract

Sampled precision policies can miss changed threshold decisions elsewhere in an allowed domain. We specify exact finite-input membership equivalence, endpoint-sensitive divergent regions and independently checkable certificates for a fixed selector contract. Controlled program experiments detect 136 nonconforming runs, versus 111 with a thirteen-point grid. Historical-source replay of documented scikit-learn and SciPy defects demonstrates broad policy effects, although full-domain checking adds no affected workload over the grid in either case. An installed eval-toolkit selector exposes a different numerical-contract issue: 27 workloads diverge from a rational reference, with median PSC about 3.75e-16 and no affected policy on the studied finite decimal lattices. Those tiny regions are not interpreted as operational bug rates. Partition and SMT agree on complete diagnostics through G=500. A separately implemented streaming consumer preserves certificate obligations while reducing measured auxiliary memory and runtime. Immutable releases are executed and accompanied by detached hash-bound reports. The contribution is scoped contract-aware diagnosis and independently checkable evidence, with practical use conditioned on the application's permitted policy set; broad deployment effectiveness and general algorithmic novelty remain unestablished.

'''
    text=text[:text.index('## Abstract')]+abstract+text[text.index('Keywords:'):]
    scipy=f'''### Additional documented defect in an independent upstream project

SciPy issue #6318 [27] reports incorrect nearest-neighbor interpolation for integer axes; merged PR #6351 [28] fixes overflow in midpoint construction by dividing before addition. We freeze the exact pre-merge parent `{bug['affected_commit']}` and merge `{bug['fixed_commit']}`, with source, upstream tests, SHA-256 values and BSD license. The original regression test uses int8 knots [0,50,127] and requires interpolation at those knots to reproduce their values. Executing its unchanged test body fails on affected source and passes on fixed source and installed SciPy {bug['scipy_runtime']}.

We compile the original interp1d class and its two fill-value helpers without rewriting method bodies. A compatibility namespace maps the removed NumPy float_ alias to float64 and supplies the modern _Interpolator1D base helper. Only the nearest branch on the stated finite one-dimensional inputs is evaluated. AST/source digests and the helper hash are recorded. This is isolated historical-source replay with a transparent bridge, not installation of an old SciPy binary, the reporter's complete original time series, or general equivalence of the historical and modern libraries. The overflow-causing integer addition remains unchanged; the matched fixed/current controls reproduce knot scores exactly.

The six prespecified axis fixtures include the upstream int8 axis, derived int16, Unix-second int32 and aligned large int64 axes, plus small-int32 and float64 controls. We additionally attach synthetic int32 Unix-second axes to the first 64 rows of all thirty existing pipeline score vectors and query at the observed knots. The scores/labels remain frozen; these row-index time carriers are constructed propagation fixtures, not independently collected time-series applications. Correct interpolation at observed knots is an identity requirement. The unchanged downstream consumer then compares selected IDs under the same rational precision objective.

| Evidence | Result |
|---|---|
| Workloads / variant-workload executions | {bug['workloads']} / {bug['variant_workload_pairs']} |
| Affected-source score changes / policy-divergent workloads | {bug['affected_score_changed']} / {bug['affected_policy_divergent']} |
| Snapshot / grid / full-domain detections on divergent workloads | {bug['snapshot_detected']} / {bug['grid_detected']} / {bug['complete_detected']} |
| Fixed-source and current policy false alarms | {bug['fixed_or_current_false_alarms']} |

The 108 input-bound core certificates are independently replayed using actual interpolation outputs, exact membership checking and source/input bindings. Among the 31 affected workloads, PSC ranges from {bug['positive_divergent_psc_min']:.6f} to {bug['positive_divergent_psc_max']:.6f}, markedly wider than the binary64 contract differences below. Five affected workloads are missed by snapshot; grid and full-domain both detect all 31. Thus incremental real-defect workload detection over grid remains zero; complete diagnostics add localization and replayable membership evidence. Thirty-four changed score vectors do not imply thirty-four policy regressions, and thirty-one divergent workloads remain one documented defect. Across studies, the confirmed-defect count is now two, in scikit-learn and SciPy; eval-toolkit remains a separate contract-differential case. These projects share numerical dependencies and provide no multi-team deployment or real-bug detection-rate estimate.

'''
    text=text.replace('## 8. RQ-C',scipy+'## 8. RQ-C',1)
    dist=sig['positive_psc_distribution'];drows=[f"| {key} | {dist[key]['value']:.6e} |" for key in ['min','q25','median','q75','max']]
    lattice=[f"| {r['decimal_places']} | {r['policies_per_workload']:,} | {r['affected_workloads']} / 30 | {r['affected_policy_workload_pairs']} |" for r in sig['decimal_policy_resolution']]
    comparison=sig['documented_scipy_defect_decimal_resolution'][0]
    practical='''### RQ-D Policy width and practical significance

The twenty-seven numerical-contract differentials have extremely small policy measure. We compute all quantiles using exact fractions and linear interpolation before converting only display values to scientific notation. Three further workloads have zero PSC; Boolean equivalence and endpoint evidence remain separate properties. The distribution below is conditional on the 27 positive-PSC workloads, not all thirty observations and not a probability distribution of deployed policies.

| Positive-PSC statistic | Value |
|---|---|
'''+ '\n'.join(drows)+f'''

At individual verified policies, membership can still change: across these fixtures the maximum changed-ID count is {sig['max_changed_observations']} of 64. The largest precision shortfall observed at stored probes is {sig['max_precision_shortfall']:.6e}; separately, the exact supremum across all covered cells is {sig['max_precision_shortfall_supremum']:.6e}. That supremum includes limits at open cell endpoints and need not be attained. These quantities do not turn a tiny arithmetic discrepancy into demonstrated harm. The observed labels provide no deployment-frequency, utility, monetary loss or human-outcome data.

We intersect the exact divergent components with four explicitly declared policy lattices on [0.30,0.90]. Policies are rational decimal targets, not exact embeddings of their binary64 approximations. Intersection is computed algebraically from integer bounds and endpoint ownership; it does not claim to make millions of public-API calls. Earlier complete partition validation supplies coverage of the intervals, and the validator cross-checks closed/open lattice boundaries.

| Decimal places | Allowed policies per workload | Workloads with an affected policy | Affected policy/workload pairs |
|---|---|---|---|
'''+ '\n'.join(lattice)+'''

For these measured workloads, applications restricted to any one of those decimal lattices have no affected allowed policy under the declared reference/interface mapping. That is equality on a specified finite policy set, not continuous-domain equivalence or a proof that arbitrary workloads are safe. Conversely, zero interval length can still include an allowed singleton; a dedicated boundary test prevents confusing PSC=0 with finite-set equality. The nineteen representable-binary64 examples use a different exact policy embedding, as explained above, and are not silently substituted for decimal targets.

The practical role of the tiny-region certificates is therefore narrow: auditing a strict numerical contract, documenting a numerical-interface migration, or deciding whether an explicitly permitted policy set intersects a difference. They do not demonstrate an extra bug or justify blocking every routine CI job. An application may accept the binary64 contract or define a restricted decimal policy set; such a choice must be declared before interpreting a report. We preserve the exact diagnostic result rather than erasing small regions with a tolerance and calling the versions universally equivalent. The separate SciPy defect study shows broad policy effects, but its constructed propagation cases likewise do not supply operational impact or deployment rates.

If an application already declares a small finite allowed set, exhaustive checking of every member is itself complete for that set. This study does not show that a continuous-domain certificate is cheaper or necessary in that setting. Its additional value is the reusable exact region description and contract-localized explanation; the actual frequency and utility of such reuse were not measured.

'''
    practical+=f"The same exact permitted-set assessment is applied separately to the SciPy defect fixtures: at two decimal places, {comparison['affected_workloads']} of {comparison['workloads']} workloads have affected targets, comprising {comparison['affected_policy_workload_pairs']:,} of {comparison['workloads']*comparison['policies_per_workload']:,} allowed policy/workload pairs. Per-case counts for all four resolutions are retained in scipy_allowed_policy_counts.csv. These are constructed-fixture coverage counts, not observed deployment frequencies or independent defect counts.\n\n"
    text=text.replace('## 10. Threats',practical+'## 10. Threats',1)
    big=[]
    for task in large['tasks']:
        med={method:np.median([float(r['total_checked_ms']) for r in raw if r['case_id']==task['case_id'] and r['method']==method]) for method in ['partition','smt_all_regions']}
        group=next(r for r in raw if r['case_id']==task['case_id']);big.append(f"| {task['g']} / {task['pattern']} | {group['critical_points']} | {task['components']} | {med['partition']:.2f} | {med['smt_all_regions']:.2f} |")
    scaling='''### RQ-B Extension to larger candidate counts

The previous G<=90 factorial is extended with six additional prespecified tasks at N=10,000, G in {250,500} and the same none/one/alternating omission patterns. Both algorithms still produce identical complete diagnostics. Three repetitions per method, randomized within each replicate, yield 36 raw timing records and twelve independently replayed certificates. No task is dropped for being unfavorable. Residual UNSAT is required for SMT completion; unknown or timeout would prevent certification.

| G / omission | Critical points | Components | Partition total ms | SMT total ms |
|---|---|---|---|---|
'''+ '\n'.join(big)+'''

Totals include fresh candidate preparation, complete region/witness production plus JSON and the same region checker. The new cases reach 430 critical points and 215 divergent components. Three repetitions are descriptive and are not pooled with the older five-repetition protocol. The prepared-membership region checker is distinct from the streaming consumer for the core certificate schema. These results extend the evaluated candidate range, but do not establish asymptotic superiority, a deployment SLO, or a win over an independently optimized AllSMT implementation. The baseline remains our direct Z3 encoding; modern enumeration methods [25] retain capabilities and optimizations this study does not benchmark.

'''
    text=text.replace('## 9. Integration',scaling+'## 9. Integration',1)
    contribution='''### Precise contribution relative to nearby methods

General parameter synthesis and AllSMT already supply machinery for exploring property regions; neither the finite partition fact nor complete-region capability is exclusive to this work. The contribution is a concrete verification interface with declared policy semantics, observation identities, endpoint ownership and input-bound diagnostic obligations, plus an independently implemented consumer and explicit integration limits. The strongest evidence is consistency under those obligations and measured engineering tradeoffs, rather than a new general solver principle.

| Closest foundation | What is established there | Specific work instantiated and evaluated here |
|---|---|---|
| Parametric verification and synthesis [6,7,20] | Reasoning about parameter-indexed properties and regions | Fixed empirical selected-ID equivalence, with exact policy/identity/numerical contracts and boundary ownership |
| Predicate enumeration and WMI [23-25] | Complete model-region exploration and integration | Matched selector diagnostics, exact PSC as uniform interval length and representative observation witnesses; no general enumeration novelty claimed |
| Certifying computations [9,17] | Producer/checker separation and evidence validation | A specified membership certificate and separately coded streaming consumer, replayed over 428 certificates with paired cost measurements |
| Rounding preimages [26] | Arithmetic reasoning about rounding cells | A checked mapping from an actual binary64 selector interface to rational cuts, followed by allowed-policy-set significance assessment |

The table identifies the implemented object and evidence; it is not a negative claim that existing tools cannot encode the same task. Our SMT baseline demonstrates that they can. The streaming data structures are established techniques, the source-replay bridges remain trusted integration code, and first-in-literature novelty is not established by this focused comparison. Two independently documented defects strengthen external evidence but do not by themselves prove a broad defect-detection advantage.

'''
    text=re.sub(r'### Closest algorithmic overlap and remaining contribution\n.*?(?=## 12\. Conclusion)','',text,flags=re.S)
    text=text.replace('## 12. Conclusion',contribution+'## 12. Conclusion',1)
    text=text.replace('One confirmed defect, shared numerical dependencies and one-host timings leave broader bug-detection rates, deployment budgets and first-in-literature novelty unresolved.','Two documented upstream defects, constructed propagation carriers, shared numerical dependencies and one-host timings leave broader bug-detection rates, deployment budgets and first-in-literature novelty unresolved.')
    text=text.replace('The V5 release follows the same non-circular protocol with twenty-three stages under Python 3.13.18.','The exact V5 ZIP also completed all twenty-three stages, SHA-256 `4a580830ee0a2c4d5cf78290b80312c28e8cc4a2f66fabfcc40568432492a2c1`, in 1,191.98 measured seconds with unchanged before/after archive hashes. Its report, logs and output digests are retained under evidence/V5_FINAL_RELEASE_EVIDENCE. V6 follows the same non-circular protocol with twenty-seven stages under Python 3.13.18.')
    text=text.replace('The actual V5 pass/fail outcome','The actual V6 pass/fail outcome')
    release='''### Immutable final-archive reproduction

The prior V5 archive, SHA-256 `4a580830ee0a2c4d5cf78290b80312c28e8cc4a2f66fabfcc40568432492a2c1`, was extracted and executed through all 23 stages. Its detached report records 1,452 verified manifest entries, unchanged before/after archive hashes and 1,191.98 measured seconds. The report, environment, logs and output digests are included under evidence/V5_FINAL_RELEASE_EVIDENCE; they provide direct evidence for that particular archive rather than an inference from an older internal status file.

V6 uses the same protocol with 27 stages under Python 3.13.18. Source, measured tables and rendered reading copies are frozen before packaging. The exact final ZIP is extracted and run; then its execution report is published outside that ZIP and delivered with it in a single DELIVERY bundle. A root READ_ME_FIRST.md identifies this handoff. Stale root run_all status/log files are omitted; the new execution creates its own. The frozen PDF retains its measured snapshot, while fresh raw timings and rebuilt Markdown are delivered separately. Timings may vary; exact logical outcomes and audits must agree. The actual V6 verdict and digest belong to that detached report and are not asserted through a self-referential hash inside the research ZIP. This is local author-side reproduction, not independent institutional replication.

'''
    text=re.sub(r'### Immutable final-archive reproduction\n.*?(?=### Precise contribution)',release,text,flags=re.S)
    text=text.replace('The latter differences require an explicit caller contract before they can be treated as regressions.','The numerical-interface differences have extremely small PSC and intersect none of the four studied decimal policy lattices; they require an explicit caller contract before being treated as regressions. The separate SciPy case has broad effects, although grid also finds its affected workloads.')
    text=text.replace('The external study adds one documented upstream defect, not a multi-project naturally occurring bug corpus.','The two documented defect studies use scoped historical-source replay and controlled propagation fixtures; they are not a representative multi-project real-bug corpus.')
    refs='''
[27] SciPy issue #6318 (2016). Scipy interp1d nearest not working for high values on x-axis. Upstream defect report. https://github.com/scipy/scipy/issues/6318

[28] SciPy PR #6351 (2016). BUG: #6318 Interp1d nearest integer x-axis overflow issue fixed. Merged 6 July 2016. https://github.com/scipy/scipy/pull/6351
'''
    (Q/'docs/V6_TARGETED_EVIDENCE.md').write_text(scipy+practical+scaling+contribution+refs,encoding='utf-8')
    return text+'\n'+refs
