"""Reconcile reuse costs, saved query answers and inherited-source bindings."""
from pathlib import Path
from fractions import Fraction as F
import csv,json,hashlib,statistics
import numpy as np
from reuse_cost_study import CASE_IDS,BATCHES,REPEATS,plans,direct_answer
from scipy_documented_defect import functions,cases
from independent_oracle import candidates,select
from policy_exact import DEFAULT
from policy_domain_query import contains
Q=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):return list(csv.DictReader(p.open(encoding='utf-8')))
def main():
    R=Q/'results/v8';prior=Q/'evidence/V7_FINAL_RELEASE_EVIDENCE';p=read(prior/'RELEASE_VERIFICATION.json')
    assert p['status']=='PASS' and len(p['stages'])==29 and all(s['exit_code']==0 for s in p['stages'])
    assert p['archive_sha256_before']==p['archive_sha256_after']=='a14ac1fc458b1b76e8a6cc25031723597648045dcaae866fd46a9b6a0f806d9a'
    for name,digest in read(prior/'EVIDENCE_MANIFEST.json').items():assert sha(prior/name)==digest
    raw=rows(R/'reuse_raw.csv');groups=rows(R/'reuse_summary.csv');summary=read(R/'reuse_cost_summary.json');protocol=read(R/'reuse_protocol.json');saved_plans=read(R/'reuse_query_plans.json')
    assert len(raw)==720 and len(groups)==144 and summary['source_sha256']==sha(Q/'reuse_cost_study.py')
    assert summary['status']=='PASS' and summary['smt_unknown']==0 and summary['matched_answers']==30420
    assert protocol['case_ids']==CASE_IDS and protocol['batch_sizes']==BATCHES and protocol['repetitions']==REPEATS
    assert len({(r['case_id'],r['kind'],r['batch'],r['replicate'],r['method']) for r in raw})==720
    for r in raw:
        phase=[float(r[k]) for k in ['setup_ms','queries_ms','total_ms']];assert all(v>=0 for v in phase) and abs(phase[0]+phase[1]-phase[2])<1e-8
        output=R/'reuse_outputs'/r['output_file'];assert sha(output)==r['output_sha256'];out=read(output);assert len(out)==int(r['batch'])
        key=f"{r['case_id']}__{r['kind']}__b{r['batch']}";plan=saved_plans[key];assert [v['affected'] for v in out]==plan['expected'] and int(r['affected_queries'])==sum(plan['expected'])
    for r in groups:
        selected=[v for v in raw if all(v[k]==r[k] for k in ['case_id','kind','batch','method'])];assert len(selected)==5 and {int(v['replicate']) for v in selected}==set(range(5))
        for phase in ['setup_ms','queries_ms','total_ms']:
            values=[float(v[phase]) for v in selected];assert float(r['median_'+phase])==statistics.median(values)
            assert float(r['iqr_'+phase])==float(np.quantile(values,.75)-np.quantile(values,.25))
    lookup={(r['case_id'],r['kind'],int(r['batch']),r['method']):float(r['median_total_ms']) for r in groups}
    for row in summary['observed_crossings']:
        name,kind,other=row['case_id'],row['kind'],row['comparator']
        expected=next((b for b in BATCHES if all(lookup[name,kind,t,'checked_certificate']<lookup[name,kind,t,other] for t in BATCHES if t>=b)),None)
        assert expected==row['first_observed_sustained_batch']
    # Independently execute the source outputs and every unique allowed-domain plan.
    funcs,_,_=functions();source_cases={v[0]:v for v in cases()};checks=0
    for name in CASE_IDS:
        _,x,scores,y,ids,rec=source_cases[name];old=funcs['fixed'](x,scores,kind='nearest')(x);new=funcs['affected'](x,scores,kind='nearest')(x)
        a=candidates(y,old,DEFAULT);b=candidates(y,new,DEFAULT);positive=bool(y.sum());breaks=sorted({p for p,k,n,bits in a+b})
        for kind in ['singleton','continuous_window']:
            for batch in BATCHES:
                key=f'{name}__{kind}__b{batch}';plan=saved_plans[key];assert plan['requests']==plans(kind,batch)
                truth=[direct_answer(a,b,positive,q,breaks)['affected'] for q in plan['requests']];assert truth==plan['expected'];checks+=len(truth)
                for method in ['checked_certificate','direct_masks','incremental_z3']:
                    for rep in range(5):
                        out=read(R/'reuse_outputs'/f'{key}__r{rep}__{method}.json')
                        for q,r in zip(plan['requests'],out):
                            if r['witness'] is not None:
                                v=F(r['witness']);assert select(a,v,positive,DEFAULT)[2]!=select(b,v,positive,DEFAULT)[2]
                                assert v in map(F,q['values']) if q['kind']=='finite' else contains(q,v)
    manifest=read(Q/'provenance/q2_reference/manifest.json')
    for name,item in manifest['files'].items():assert sha(Q/'provenance/q2_reference'/name)==item['sha256']
    manuscript=(Q/'provenance/q2_reference/main.tex').read_text(encoding='utf-8')
    assert 'Exact Candidate Frontier Comparison for Decision Regression Testing of Precision-Constrained Selectors' in manuscript
    assert '255' in manuscript and 'proper-prefix' in manuscript and 'B4' in manuscript
    result=dict(status='PASS',prior_v7_exact_stages=29,raw_measurements_reconciled=720,summary_groups_reconciled=144,unique_case_query_plans_replayed=checks,saved_method_query_answers_reconciled=30420,smt_unknown=0,q2_source_snapshot_hashes_verified=len(manifest['files']),scope='Measured computational reuse, not developer productivity or real production policy requirements; observed crossings may change with host/run.')
    (R/'validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
