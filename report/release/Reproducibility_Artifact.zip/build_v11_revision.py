"""Portability repair and submission documentation; no new empirical cohort."""
from pathlib import Path
import hashlib,json,re

def source_audit(Q,text):
    binding=json.loads((Q/'provenance/v11_source_bindings.json').read_text(encoding='utf-8'))
    for name,digest in binding['files'].items():
        assert hashlib.sha256((Q/name).read_bytes()).hexdigest()==digest,('Source binding mismatch',name)
    for name in binding['generated_lf_sources']:
        assert b'\r' not in (Q/name).read_bytes(),('Noncanonical generated source newline',name)
    result=dict(status='PASS',source_bindings=len(binding['files']),generated_lf_sources=len(binding['generated_lf_sources']),
                protocol_stages=33,scope='V11 repaired source bytes; inherited V9 bindings are historical, not a claim of unchanged V11 source.')
    out=Q/'results/v11';out.mkdir(parents=True,exist_ok=True)
    (out/'source_integrity.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    return result

def integrate(Q,text):
    text=text.replace('Research manuscript V10,','Research manuscript V11,').replace('41 core pytest test items','42 core pytest test items').replace('41 core tests pass','42 core tests pass')
    start=text.index('### Verified release provenance');end=text.index('## References',start)
    text=text[:start]+'''### Reproduction and source integrity

The standalone artifact contains the code, frozen inputs, dependencies and source-integrity bindings needed by its 33-stage default entry point. Files named after earlier revisions implement cumulative experiments and audits within this single artifact; reproducing the study does not require executing earlier release ZIPs, installing earlier project versions, or accessing a neighboring submission directory. Default execution reuses frozen scores; optional retraining and historical dependency-binary execution are distinct procedures with additional requirements.

V11 repairs platform-dependent output of generated Python snapshots: mutant and failure-fixture source files are written as explicit UTF-8 bytes with LF newlines. Their byte hashes remain checked; newline normalization is not applied to arbitrary source or input files. Copied execution-source snapshots retain the actual source bytes. A focused regression test exercises generation from CRLF input and rejects subsequent byte tampering. All source changes are recorded in the V11 binding manifest; the historical V10 classification of 138 strict bindings plus one controlled generated snapshot is not an assertion that V11 source remains unchanged.

The exact final artifact is frozen before execution; its detached execution report binds its SHA-256 and records every stage exit status. The report is distributed alongside the artifact, avoiding a self-referential archive hash. A local Windows execution establishes neither native Linux validation nor independent institutional reproduction. The reading copy uses the recorded measurement snapshot; rerun results retain their own timing records. See REPRODUCIBILITY_V11.md for commands, scope and release-evidence locations.

'''+text[end:]
    supplement=(Q/'docs/SUPPLEMENT_Q1_V10.md').read_text(encoding='utf-8').replace('for Q1 V10','for Q1 V11')
    supplement+='\n## S17 Cross platform source snapshot integrity\n\nV11 writes generated mutant and refusal-fixture Python sources using explicit UTF-8 bytes and LF newlines, then verifies their byte hashes. Execution-source copies retain actual source bytes. The default 33-stage chain is self-contained; revision-named files are cumulative study components, not dependencies on old release ZIPs. Historical V10 used 138 strict bindings and one controlled snapshot; V11 declares repaired source hashes separately. Native Linux execution has not been claimed.\n'
    (Q/'docs/SUPPLEMENT_Q1_V11.md').write_text(supplement,encoding='utf-8')
    source_audit(Q,text)
    return text
