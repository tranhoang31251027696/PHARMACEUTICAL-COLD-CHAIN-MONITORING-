"""Replay the second project and extended diagnostics; reconcile paired costs."""
from pathlib import Path
import json,csv,hashlib,sys,ast,xml.etree.ElementTree as ET
import numpy as np
from second_project_evaluation import Q,evidence,sha
from expanded_region_benchmark import fixture,prepare
from complete_region_comparison import verify_regions

def read(p):return json.loads(p.read_text(encoding='utf-8'))
def rows(p):return list(csv.DictReader(p.open(encoding='utf-8')))
def main():
    prior=Q/'evidence/V4_FINAL_RELEASE_EVIDENCE';pr=read(prior/'RELEASE_VERIFICATION.json')
    assert pr['status']=='PASS' and len(pr['stages'])==19 and pr['archive_sha256_before']==pr['archive_sha256_after']=='f45403ce8011adc3d084af2b432953286072fd8b6302e134ab1e087d4075b835'
    for name,digest in read(prior/'EVIDENCE_MANIFEST.json').items():assert sha(prior/name)==digest
    R=Q/'results/v5';second=read(R/'second_project_summary.json');assert second['status']=='PASS' and second['full_package_installed_and_executed'] and second['confirmed_defects_added']==0
    records={r['case_id']:r for r in read(Q/'inputs/manifest.json')['cases']};observed=0;div=0;grids=0;visible=0;visible_probes=0
    rr=rows(R/'second_project_results.csv');assert len(rr)==30
    for r in rr:
        rec=records[r['case_id']];path=Q/'inputs'/rec['file'];assert sha(path)==rec['sha256'];d=np.load(path);saved=read(R/'second_project_certificates'/r['certificate'])
        rebuilt=evidence(d['y'][:64],d['old'][:64],d['ids'][:64].tolist())
        for k,v in rebuilt.items():assert saved[k]==v,(r['case_id'],k)
        assert saved['source_input_sha256']==rec['sha256'] and saved['source_module_sha256']==second['source_module_sha256']
        assert len(saved['probes'])==int(r['policy_probes']) and len(saved['divergent_regions'])==int(r['components']) and saved['psc_exact']==r['psc_exact']
        observed+=len(saved['probes']);div+=not saved['equivalent_to_rational_reference'];grids+=saved['grid_detected']
        visible+=saved['representable_policy_difference'];visible_probes+=len(saved['representable_policy_probes'])
    assert observed==second['policy_probes']==884 and div==second['divergent_workloads']==27 and grids==second['grid_detected_workloads']==0
    assert visible==second['representable_policy_divergent_workloads']==19 and visible_probes==second['representable_policy_probes']==196
    expanded=read(R/'expanded_region_summary.json');assert expanded['status']=='PASS' and expanded['source_sha256']==sha(Q/'expanded_region_benchmark.py')
    pairs={};certcount=0;bycase={t['case_id']:t for t in expanded['tasks']}
    for p in (R/'expanded_region_certificates').glob('*.json'):
        saved=read(p);y,s=fixture(saved['n'],saved['g']);assert hashlib.sha256(y.astype('<i8').tobytes()+s.astype('<f8').tobytes()).hexdigest()==saved['input_sha256']
        gold,actual=prepare(y,s,saved['pattern']);c=saved['certificate'];verify_regions(gold,actual,c)
        if saved['case_id'] in pairs:assert c==pairs[saved['case_id']]
        pairs[saved['case_id']]=c;certcount+=1
        if saved['method']=='smt_all_regions':assert saved['algorithm_stats']['residual_result']=='unsat'
    raw=rows(R/'expanded_region_raw.csv');assert len(pairs)==27 and certcount==54 and len(raw)==270
    for case,c in pairs.items():
        for method in ['partition','smt_all_regions']:
            group=[r for r in raw if r['case_id']==case and r['method']==method];assert sorted(int(r['replicate']) for r in group)==list(range(5))
            for r in group:
                assert int(r['divergent_components'])==len(c['divergent_regions']) and r['psc_exact']==c['psc_exact']
                assert np.isclose(float(r['total_checked_ms']),sum(float(r[k]) for k in ['preparation_ms','producer_serialization_ms','checker_ms']),rtol=1e-12)
                assert all(float(r[k])>0 for k in ['preparation_ms','producer_serialization_ms','checker_ms'])
    raw=rows(R/'paired_checker_raw.csv');summary=rows(R/'paired_checker_summary.csv');meta=read(R/'paired_checker_metadata.json');assert meta['status']=='PASS' and len(raw)==72 and len(summary)==12
    for source,digest in meta['source_sha256'].items():assert sha(Q/source)==digest
    for s in summary:
        group=[r for r in raw if all(r[k]==s[k] for k in ['n','g','workload','method'])];timing=[r for r in group if r['phase']=='untraced'];memory=[r for r in group if r['phase']=='separate_memory']
        assert len(memory)==1 and sorted(int(r['replicate']) for r in timing)==list(range(5)) and len({r['input_sha256'] for r in group})==1
        assert all(not r['peak_aux_mib'] for r in timing) and not memory[0]['checker_ms'] and not memory[0]['parse_ms']
        v=[float(r['checker_ms']) for r in timing];q=np.percentile(v,[25,75],method='linear')
        for a,b in [(float(s['median_ms']),np.median(v)),(float(s['iqr_ms']),q[1]-q[0]),(float(s['peak_aux_mib']),float(memory[0]['peak_aux_mib']))]:assert np.isclose(a,b,rtol=1e-12,atol=1e-12)
        opposite=[r for r in raw if all(r[k]==s[k] for k in ['n','g','workload'])];assert len({r['input_sha256'] for r in opposite})==len({r['probes'] for r in opposite})==1
    audit=read(R/'streaming_artifact_verification.json');assert audit['status']=='PASS' and audit['certificates_independently_reverified']==428 and audit['critical_and_open_cell_probes']==41348
    tree=ast.parse((Q/'src/streaming_checker.py').read_text(encoding='utf-8'))
    imports=[n.module for n in ast.walk(tree) if isinstance(n,ast.ImportFrom)]+[a.name for n in ast.walk(tree) if isinstance(n,ast.Import) for a in n.names]
    assert not any(v and ('policy_exact' in v or 'independent_oracle' in v or 'heapq' in v) for v in imports)
    upstream=ET.parse(R/'upstream_threshold_tests.xml');assert sum(int(t.get('tests',0)) for t in upstream.iter('testsuite'))==18 and all(int(t.get('failures',0))+int(t.get('errors',0))==0 for t in upstream.iter('testsuite'))
    result={'status':'PASS','second_project_workloads_replayed':len(rr),'second_project_policy_probes_replayed':observed,'second_project_semantic_differentials':int(div),'additional_confirmed_defects':0,'expanded_region_tasks':len(pairs),'expanded_certificates_replayed':certcount,'expanded_timing_records_reconciled':270,'paired_checker_raw_records_reconciled':len(raw),'paired_checker_groups_reconciled':len(summary),'streaming_corpus_certificates':428,'upstream_threshold_tests':18,'independent_checker_has_no_production_import':True}
    (R/'validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
