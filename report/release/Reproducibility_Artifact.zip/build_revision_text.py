"""Generate substantive journal extensions from live revision result tables."""
from pathlib import Path
import json,csv

def write_extension(Q):
    D=Q/'docs';R=Q/'results/v2'
    p=json.loads((R/'program_summary.json').read_text(encoding='utf-8'));v=json.loads((R/'version_summary.json').read_text(encoding='utf-8'))
    phase=list(csv.DictReader((R/'ablation_summary.csv').open(encoding='utf-8')))
    rows=[]
    for n in ['1000','10000','100000']:
        values={r['phase']:r for r in phase if r['n']==n and r['witness']=='True'}
        rows.append('| '+n+' | '+' | '.join(f"{float(values[k]['median_ms']):.3f}" for k in ['construction_ms','sweep_excluding_witness_ms','witness_ms','assembly_and_hash_ms','serialization_ms','total_ms'])+' |')
    ablation='\n'.join(['| N | Construction | Sweep excluding witness | Witness | Assembly and hash | Serialization | Total |','|---|---|---|---|---|---|---|']+rows)
    source_rows=list(csv.DictReader((R/'program_results.csv').open(encoding='utf-8')))
    programtable=['| Source program | Runs | Nonconforming | Snapshot | Grid | Guard-complete |','|---|---|---|---|---|---|']
    for name in sorted({r['program'] for r in source_rows}):
        rr=[r for r in source_rows if r['program']==name];bad=[r for r in rr if r['conformance_failure']=='True']
        programtable.append(f"| {name} | {len(rr)} | {len(bad)} | {sum(r['snapshot_detected']=='True' for r in bad)} | {sum(r['grid_detected']=='True' for r in bad)} | {len(bad)} |")
    text='''## Appendix A Program conformance and the semantic information boundary

The first evaluation verifies declared old/new selector semantics. That question is useful when both implementations have faithful finite contracts, but it does not establish that an actual executable conforms to its advertised contract. We therefore add a separate program-output study. The expected specification remains unchanged for every program: whole-score-group threshold candidates, inclusive empirical precision, and maximum TP followed by maximum selected count. We never pass a mutant specification to the checker in this study.

The system under test is an executable Python module separate from the production policy comparator and independent oracle. Its build routine constructs actual Boolean candidate masks and integer counts. Its selection routine calls its own feasibility guard and uses its own priority code. Six source variants change those executable operations: strict precision, strict score thresholding, reversed secondary priority, omission of a middle group, inside-tie prefixes, and an incremented feasibility TP count. The generated source files and their SHA-256 values are retained. Tests execute the reference and each variant on the same 30 fitted-pipeline inputs. These are source mutants of a local selector, not six pre-existing products or a naturally occurring defect collection.

The adapter instruments calls to the executable feasibility guard and records the actual k/n values it receives. It obtains these values from the running program rather than from a supplied `new_spec`. It combines those events with the unchanged reference oracle's critical ratios and the policy-domain endpoints. It then calls the executable at every resulting critical point and open-cell representative. Expected memberships come from direct threshold-mask enumeration under the reference specification. Snapshot and thirteen-point baselines call that very same executable, receive the same observed output IDs, and use the same expected specification. Their distinction is policy coverage, so this comparison removes the semantic-information asymmetry of comparing score-only tools with a configured mutant model.

This adapter has an explicit and substantial trust boundary. The corpus is audited to use alpha only as an argument to the instrumented guard; an AST check enforces that syntactic restriction for the selection routine. Candidate construction and priority do not depend on alpha. The adapter checks that guard events remain the same at all evaluated policies. Under these conditions, program outcomes cannot change between the collected guard values. The argument would fail for hidden alpha-dependent branches, stateful selection, numerical precision guards not represented by the trace, or an uninstrumented external function. A consistent trace at sampled points alone would not prove event completeness for arbitrary code. We claim coverage for this audited corpus, not a universal dynamic-analysis theorem.

Instruments do not replace the executable's Boolean result: the wrapper records guard inputs and delegates the comparison to the program's original guard. Thus the strict-precision source variant keeps its strict comparison. Candidate-family and objective mutants also run their own changed code. The unchanged oracle specification supplies the desired behavior; it does not supply the changed implementation's semantics. Each certificate records the executable source hash, frozen input hash, collected guard values, complete probe list, expected and actual membership bitsets, and an observation-ID witness when they disagree. A replay audit re-executes every stored observation and verifies the bitsets and source binding.

PROGRAM_TABLE

Across 210 program/input executions, 136 fail reference conformance. The guard-complete adapter detects those 136, the thirteen-point baseline detects 111, and the alpha=0.50 snapshot detects 72. All 30 reference controls conform. The remaining source-mutant runs are equivalent only on their evaluated fixed input and domain; this is not global program equivalence. These totals are separate from, and must not be pooled with, the earlier 183/183 declared-semantics results. This study establishes that the method can consume outputs of real executable variants without being handed the mutant specification. It remains a local source-mutation experiment, and does not answer how well it integrates with an unrelated industrial selector.

## Appendix B Fresh dependency version executions

We execute actual SciPy 1.15.3 and 1.18.1 binaries in separate pre-existing Python environments. The worker asserts its loaded SciPy version, records Python and NumPy versions, executable and module paths, extracts and hashes the interpolation implementation, and hashes its generated score arrays. It reads frozen interpolation knots, calibration values, raw tuning scores and labels; those inputs are packaged with individual hashes. The ten cold-chain calibrators and the public WDBC pilot are included without selecting cases on the new result. Training and calibrator fitting are not repeated or changed during this comparison.

Both workers call `scipy.interpolate.interp1d` on the same clipped queries and calibration arrays. Cold-chain outputs are cast to float32 as in the inherited protocol; the public pilot retains its original output dtype. We compare older 1.15.3 outputs to newer 1.18.1 outputs under the same default selector contract on [0.30,0.90]. This direction is explicitly named because the earlier artifact sometimes used the newer environment as its reference. Policy divergence is symmetric, but old/new witness membership and some threshold descriptions are directional.

All eleven worker comparisons exhibit at least one changed score, and nine exhibit some policy divergence over the agreed domain. The exact certificates are independently checked against their actual version-produced arrays. This is fresh execution evidence for sensitivity to real dependency implementations on inherited fixed data. It is stronger provenance than an engineered float32 cast, but it is not eleven independent deployments, eleven new datasets, or nine confirmed library bugs. Different numerical implementations may both satisfy their advertised numerical requirements. In the absence of an upstream issue, specified bug-fix behavior or application requirement forbidding these changes, we report a version differential and a potential application regression, not a defect in SciPy.

Default standalone reproduction re-evaluates the frozen version-worker outputs and their certificates. Re-executing both binaries requires separately installed versions, because a single Python environment cannot load the two distributions reliably as the same module name. The worker commands and environment requirements are explicit. This optional binary-reexecution requirement does not affect regeneration of the main 98-case and mutation studies from the standalone ZIP. We executed both binaries locally in this revision and preserved their fresh logs; a future reproducer is not required to trust that history to re-evaluate the included score arrays.

## Appendix C Algorithmic cost decomposition

End-to-end timings do not identify which part of a certificate computation consumes time. We add a within-invocation ablation with instrumented stage boundaries in the production core. Construction includes input validation, sorting, candidate profiling, exact breakpoint construction and rank summaries. The sweep phase excludes time measured inside witness scans. Witness time records only scans for distinct divergent winning-state pairs. Assembly includes PSC computation and input hashing. Serialization measures JSON encoding outside the core. The certificate returned by an instrumented call is asserted equal to the uninstrumented result on a dedicated test; profiling fields are not inserted into the certificate or used by its logic.

The ablation uses three N/G settings, witness disabled/enabled, and ten rounds per condition, for 60 raw observations. Inputs are prepared outside the timer. Each condition receives a warmup and witness-mode order is randomized within a round. Unlike the original end-to-end traced protocol, this experiment disables tracemalloc. Stage medians below therefore belong to a distinct protocol and should not replace or be pooled with the earlier traced measurements.

ABLATION_TABLE

Values are milliseconds for witness-enabled divergent workloads. Each record also stores the measured end-to-end total and an unattributed residual. The validation checks that phase sums plus that residual equal the same invocation's total, and that witness-disabled calls record zero witness time. Medians of component stages generally need not sum to the median of totals; we do not force that identity or infer witness overhead by subtracting independent medians. The extra clock reads themselves incur overhead, and scheduler variation affects short phases.

The decomposition exposes both sorting/breakpoint work and output/witness work. Witness scans scale with the number of distinct divergent states, not just observation count. A low-cost invariant scan cannot stand in for successful witness construction. Likewise, an efficient policy sweep does not imply a constant-cost independently checkable certificate: hashing, serialization and an external mask-enumeration checker still consume resources. We keep algorithmic asymptotics, measured Python implementation costs, and the slower independent checker as separate claims.

## Appendix D Relation to existing verification and testing methods

Parameter-region verification predates this work. Storm's official parametric-model documentation demonstrates region checking and parameter-space partitioning [6]. Junges and colleagues study parameter synthesis and coverage of parameter space for Markov models [7]. Their models, probability properties and region procedures differ from deterministic threshold membership, but they rule out presenting region partitioning itself as our invention. We do not benchmark Storm as though it were a drop-in selected-membership comparator; such a comparison would require a faithful encoding and a common property.

Regression verification also already studies equivalence of closely related program versions [8]. Our restricted finite-input selector contract makes its policy critical values explicit and directly enumerable; it does not solve general program equivalence. The program-output experiment covers a known guard-constrained corpus rather than establishing a general-purpose regression verifier. Treating the old version as a de facto specification may preserve an old bug; applications that require correctness rather than compatibility need an agreed reference contract.

The separation between a producer and a checker is likewise established. Alkassar and colleagues describe verification of certifying computations [9]. Necula and Schneck's proof-carrying-code work studies machine-checkable safety evidence and the trusted checker boundary [10]. Our certificates are concrete finite membership evidence checked by another implementation. They are not machine-checked proofs of arbitrary executable safety, and their Python checker is not a formally verified trusted kernel. An input digest prevents silent accidental mismatches but neither authenticates the original observations nor proves adapter faithfulness.

Testing ML implementations through metamorphic properties and mutation analysis is also established. The 2021 work on stability-derived relations targets linear-classification programs [11], while Xie and colleagues study classifier implementation testing and actual faults in Weka [12]. Those programs and properties differ from our fixed-label threshold selector. Their empirical designs motivate evaluating executed code and avoiding an inference from model accuracy to program correctness. Our expanded corpus addresses direct execution for a local selector, but remains weaker external-validity evidence than a curated set of independently documented, naturally occurring defects.

The comparison below records what is demonstrated or discussed in the checked sources. “Not established here” means no matching capability was established in our inspected material; it is not proof that a tool or research area cannot support it. Complexity statements are for different mathematical objects and are not directly comparable.

| Approach | Domain and boundary treatment | Changed selector code | Checkable evidence | Complexity and comparison scope |
|---|---|---|---|---|
| Snapshot / fixed grid | Only sampled policies; no full-domain guarantee | Observes executable outputs at probes | Output differences | Number of probes times SUT cost |
| Score B4 | Full score-induced candidate family, no alpha-region verdict | Does not inspect selector code | Structural equality Boolean | Structural task rather than policy conformance |
| Storm / parameter synthesis [6,7] | Parametric probabilistic regions; exact setup and coverage depend on procedure | Requires a model of program behavior | Model/property analysis | Not the same selector input problem; no latency ranking claimed |
| Regression verification [8] | Equivalence of related programs, beyond a fixed alpha grid | Central research target | Verification results under its method | General program equivalence is not reduced to our N/G bound |
| Certifying computations / PCC [9,10] | Witness/checker and proof trust design, not this alpha contract | Depends on supplied proofs or verified computation | Core purpose | General framework, not a competing selector benchmark |
| ML metamorphic testing [11,12] | Relations across executions, not this full-domain contract | Executed classifier implementations | Violated relations and mutation evidence | A complementary testing methodology |
| Our declared-semantics certificate | Exact rational endpoints and open cells for fixed candidate contracts | Requires a faithful finite adapter | Input-bound interval and ID witness | O(N log N+G log G+K+ND), unit-cost fraction assumption |
| Our executed-program adapter | Complete for alpha-only-in-guard source corpus | Calls changed source directly; no new_spec | Executable hash and replayable membership probes | Depends on traced guards and executed SUT cost; no arbitrary-code guarantee |

A focused search across these five areas expands the primary-source basis and clarifies the closest conceptual overlap. It is still not a systematic review with exhaustive database coverage and forward/backward citation closure. The appropriate novelty claim is the specialized integration of endpoint-correct finite policy equivalence, verifiable membership evidence and explicitly scoped testing adapters. A first-in-literature claim remains unsupported. The expanded paper and artifact are provided for further technical review rather than labeled ready for acceptance at a particular journal.

## Appendix E Reproduction and assurance levels

The original standalone failure arose because the experiment driver read a historical 255-row grid CSV from a neighboring submission tree. The corrected driver reads a bundled `inputs/historical/` copy and asserts its checksum from the input manifest before any comparison. Default `run_all.py` works from frozen arrays within the extracted artifact; it does not refit models, reinstall dependency versions or need the old submission directory. Optional model refitting is a separate command with its source-data requirements documented. The distinction prevents the term “standalone” from silently including unbundled training assets.

Assurance has several layers. Unit/exhaustive tests validate finite implementations on small and randomized cases. The independent certificate checker reconstructs actual threshold masks on all stored application and declared-mutant certificates. The program adapter calls a separate executable and checks the unchanged reference contract under an explicit guard-coverage restriction. Fresh version workers establish what two actual dependency binaries computed. Checksummed packaging and a clean extraction run test delivery rather than mathematical correctness. None of these layers, alone or together, establishes authenticity of upstream measurements, population model quality, a universally correct verifier or an industrial real-bug detection rate.

The previous artifact is retained as a historical ZIP. Revised raw records are regenerated rather than mixed with old timings. Source snapshots bind the producer used for those records. A final manifest is generated after documents, evidence and reports have been assembled. The clean-run report names the extracted path, absence of neighboring SUBMISSION_PACKAGE, interpreter, stage exit codes and resulting logical summaries. It is a local clean reproduction, not independent human replication. A separate upstream-confirmed bug corpus and deployment study remain work outside the evidence completed here.
'''.replace('PROGRAM_TABLE','\n'.join(programtable)).replace('ABLATION_TABLE',ablation)
    (D/'JOURNAL_EXTENSION_V2.md').write_text(text,encoding='utf-8')
    refs='''
[6] Storm project. Running Storm on Parametric Models. Official documentation. https://www.stormchecker.org/documentation/usage/running-storm-on-parametric-models.html

[7] Junges, S.; Ábrahám, E.; Hensel, C.; Jansen, N.; Katoen, J.-P.; Quatmann, T.; Volk, M. Parameter synthesis for Markov models: covering the parameter space. Formal Methods in System Design. https://doi.org/10.1007/s10703-023-00442-x

[8] Godlin, B.; Strichman, O. (2009). Regression Verification. DAC. Author manuscript: https://ofers.dds.technion.ac.il/publications/dac09.pdf

[9] Alkassar, E.; Böhme, S.; Mehlhorn, K.; Rizkallah, C. (2013). A Framework for the Verification of Certifying Computations. https://arxiv.org/abs/1301.7462

[10] Necula, G. C.; Schneck, R. R. (2002). Proof-Carrying Code with Untrusted Proof Rules. International Symposium on Software Security. Author manuscript and formalization: https://people.eecs.berkeley.edu/~necula/ISSS02/

[11] Towards effective metamorphic testing by algorithm stability for linear classification programs. (2021). Journal of Systems and Software, 180, 111012. https://doi.org/10.1016/j.jss.2021.111012

[12] Testing and validating machine learning classifiers by metamorphic testing. (2011). Journal of Systems and Software. https://www.sciencedirect.com/science/article/pii/S0164121210003213

[13] SciPy project. Release news and versions 1.15.3 and 1.18.1. https://scipy.org/news/
'''
    (D/'V2_REFERENCES.md').write_text(refs,encoding='utf-8')
    report=f'''# Phản hồi và kết quả sửa Q1 phiên bản 2

## Các sửa đổi đã thực hiện

P0: Đóng CSV lịch sử trong inputs/historical, ràng buộc SHA-256, bỏ phụ thuộc SUBMISSION_PACKAGE khỏi lệnh chạy mặc định. Kiểm chứng bằng chạy run_all trong thư mục giải nén sạch; xem hồ sơ standalone_reproduction.json để biết kết quả thực thi, không suy ra từ kiểm tra đường dẫn.

P1 semantic independence: Thêm SUT thực thi và 6 source mutants. Checker gọi chương trình thật, giữ cùng hợp đồng tham chiếu và không nhận new_spec. {p['program_runs']} lượt / {p['policy_probes']} probes; {p['nonconforming_runs']} không tuân thủ, snapshot {p['snapshot_detected']}, grid {p['grid_detected']}, guard-complete {p['guard_complete_detected']}. Corpus có điều kiện alpha chỉ đi qua guard được instrument; chưa xác nhận được mọi chương trình tùy ý.

P1 dependency evidence: Đã thực thi hai môi trường SciPy thật 1.15.3/1.18.1 trên {v['fresh_version_comparisons']} bộ đầu vào; {v['policy_divergent_cases']} phân kỳ policy. Không gán chúng thành confirmed bugs. Mục real-SUT/bug corpus bên ngoài vẫn chưa hoàn thành; các đầu vào này kế thừa nghiên cứu trước.

P1 related work: Bổ sung parametric verification/Storm, regression verification, certifying computations/PCC và ML implementation testing, kèm bảng so sánh phạm vi. Đây là khảo sát tập trung mở rộng, chưa phải systematic review và không chứng minh first-in-literature novelty.

P1 manuscript: Mở rộng nội dung về program adapter, dependency versions, proof/trust boundaries, ablation và tái lập; bổ sung 13 nguồn tài liệu được kiểm tra ở mức ghi rõ. Cung cấp DOCX/PDF sau kiểm tra bố cục. Đây là bản thảo nghiên cứu đầy đủ hơn, không chứng nhận sẵn sàng được Q1 chấp nhận.

Moderate benchmark: 60 bản ghi ablation trong cùng invocation, chia construction, sweep, witness, assembly/hash và serialization. Các median được tính từ dữ liệu; không trừ hai median độc lập để suy chi phí witness.

## Phân biệt bằng chứng

183/183 của thí nghiệm cũ là declared-semantics verification. 136/136 của thí nghiệm mới là conformance trên chương trình mutant có trace guards đầy đủ. 9/11 version pairs nhạy policy không có nghĩa 9 lỗi SciPy. Không cộng ba denominator này thành một mutation score. Vi phạm ID được báo riêng, và 1/30 kết quả cast float32 của pipeline mới vẫn được giữ.
'''
    (Q/'RESPONSE_TO_REVIEW_V2.md').write_text(report,encoding='utf-8')
