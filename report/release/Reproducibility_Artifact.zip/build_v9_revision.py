"""Focus on diagnosis and distinguish API costs from evidence obligations."""
import json,csv,re

def integrate(Q,text):
    R=Q/'results/v9';summary=json.loads((R/'boolean_cost_summary.json').read_text(encoding='utf-8'));rows=list(csv.DictReader((R/'boolean_summary.csv').open(encoding='utf-8')))
    text=text.replace('# Exact Policy-Robust Regression Testing for Precision-Constrained Decision Pipelines','# Exact Policy-Aware Regression Diagnosis with Independently Checked Certificates',1)
    text=text.replace('Research manuscript V8 revised','Research manuscript V9 revised')
    supplement=(Q/'docs/SUPPLEMENT_Q1_V8.md').read_text(encoding='utf-8').replace('for Q1 V8','for Q1 V9')
    match=re.search(r'### Measured cost of repeated allowed domain decisions\n.*?(?=## 10\. Threats to validity)',text,re.S);assert match
    supplement+='\n## S14 Earlier V8 request cost protocol\n\n'+match.group().split('\n',1)[1]
    aliases={'upstream_int8':'Upstream int8','unix_seconds_int32':'Unix int32','small_int32_control':'Small int32 control','pipeline_axis_wdbc_logistic_isotonic_seed0':'WDBC seed 0','pipeline_axis_digits_svc_sigmoid_seed0':'Digits seed 0','pipeline_axis_generated_rf_quantized_seed0':'RF seed 0'}
    lookup={(r['case_id'],r['kind'],int(r['batch']),r['method']):r for r in rows};table=[]
    for name,label in aliases.items():
        for kind in ['singleton','continuous_window']:
            values=[lookup[name,kind,128,m] for m in summary['methods']]
            cells=[f"{float(v['median_total_ms']):.2f}" for v in values]
            table.append(f"| {label} | {'Point' if kind=='singleton' else 'Window'} | "+' | '.join(cells)+' |')
    paired=summary['paired_certificate_comparisons'];querywins=sum(r['query_phase_speedup']>1 for r in paired);totalwins=sum(r['total_speedup']>1 for r in paired)
    flow={(r['kind'],r['comparator']):r['boolean_certificate_faster_total_cases'] for r in summary['workflow_comparisons'] if r['batch']==128}
    section=f'''### Evidence obligations and the Boolean only certificate API

The earlier V8 experiment measured the cost of current implementations answering Boolean queries, not equal evidence-production obligations. Its full certificate API created counts or all intersections before projection. Direct masks and incremental Z3 did not emit or independently verify a complete diagnostic certificate. We retain those 720 measurements separately in Supplement S14 and results/v8; they are not pooled with the following experiment.

We add VerifiedBooleanIndex. Its constructor copies and independently verifies the complete input-bound certificate, merges adjacent unequal cells only when their shared endpoint is included, and freezes a rational interval index with the checked input digest. A matching singleton hole between two open unequal regions is preserved. A query searches the ordered component endpoints and returns only Boolean existence plus one rational policy witness; it never constructs the full intersection list. Finite-set and decimal-lattice queries retain explicit rational semantics, domain validation and endpoint ownership. Counts and complete intersected regions remain available from the original API. This is an application of established interval union and binary search, not new parameter-region theory.

After construction, interval and singleton queries take O(log C) rational comparisons plus bounded candidate checks over C maximal components. A finite set performs point queries after validation/deduplication. A lattice may scan O(C) components before finding a lattice member or establishing absence, so it has no logarithmic worst-case claim. Construction and full independent checking remain separate costs; arbitrary-precision operands matter. BOOLEAN_QUERY_AND_ASSURANCE.md gives the reasoning and exact interface. Four targeted tests exercise zero-measure divergence, a matching singleton hole, input tamper/immutable reuse and unsupported domains.

| Route | Complete certificate produced | Independent full certificate check | Query operation used here |
|---|---|---|---|
| Full certificate API | Yes | Yes | Full API, then Boolean/witness projection |
| Boolean certificate API | Yes | Yes, with the same checker | Indexed Boolean/witness lookup |
| Direct masks | No persisted complete certificate | No certificate to check | Exact masks/critical-cell evaluation |
| Incremental Z3 | No complete diagnostic certificate | No exported proof/certificate checked | SAT/UNSAT with rational SAT witness |

All four answer the same selected-ID existence question. This table distinguishes evidence obligations, not exact versus approximate answers. The assurance-matched panel compares the two certificate routes: both include construction, JSON roundtrip and independent full verification; the Boolean route additionally includes copying, merging, freezing and indexing. The four-route panel measures implementation request costs with different evidence artifacts and trust boundaries. Rechecking a positive witness outside timing does not independently certify a direct negative result or a solver's UNSAT proof.

### Paired query API costs on the existing plans

We reuse the same six V8 inputs, two request types and distinct rational point/window plans, with batch sizes 1/8/32/128. No new cases or production policies are claimed. Five fresh setups per batch/method, one warmup per case/type/method and seeded randomized method order yield 960 measurements and 192 median/IQR groups. The 2,028 existing case/query plans yield 40,560 repeated answers across four methods and five repetitions; all agree and saved rational witnesses are checked against independent selection. These repetitions do not enlarge the empirical defect corpus. The original direct-mask and incremental push/pop Z3 implementations are reused unchanged. Common interpolation, imports, disk I/O and human activity are excluded for every route. There is no result memoization and all requests within a batch differ.

The table shows batch-128 total median milliseconds, including each route's setup. Phase medians, IQRs and every other batch remain in boolean_summary.csv and boolean_raw.csv; no medians are pooled across inputs. The paired comparison uses these new measurements only.

| Workload | Request | Full certificate | Boolean certificate | Direct masks | Incremental Z3 |
|---|---|---|---|---|---|
'''+ '\n'.join(table)+f'''

In the assurance-matched panel, Boolean lookup lowers the query-phase median in {querywins}/12 batch-128 combinations, by {min(r['query_phase_speedup'] for r in paired):.2f}–{max(r['query_phase_speedup'] for r in paired):.2f} times. Including all setup, its total median is lower in {totalwins}/12 combinations; the remaining cases are retained. Thus part of V8's cost came from the full API's output construction, while construction and independent certificate checking still have a price. These are descriptive paired medians on one host, not a statistical significance result or a universal speed guarantee.

In the four-route request-cost panel, the Boolean route has lower total medians than direct masks for {flow['singleton','direct_masks']}/6 point and {flow['continuous_window','direct_masks']}/6 window inputs, and than this incremental Z3 encoding for {flow['singleton','incremental_z3']}/6 and {flow['continuous_window','incremental_z3']}/6. Those comparisons have the unequal obligations shown above and are not a ranking of equal verification guarantees or optimized external tools. Direct checking remains a valid simpler choice for a small finite allowed set. Computational reuse results do not measure developer debugging time, production policy requirements, institutional adoption or deployment break-even. The contribution remains exact diagnosis and checkable evidence with explicit interface and cost boundaries.

'''
    text=text[:match.start()]+section+text[match.end():]
    text=text.replace('This study does not show that a continuous-domain certificate is cheaper or necessary in that setting.','Continuous-domain certification is not required for completeness on that set; its cost tradeoff is evaluated separately below.')
    text=text.replace('when do measured certificate construction and checking costs amortize relative to direct masks or incremental SMT?','how do query-API cost and evidence-production obligations change the measured workflow tradeoff?')
    start=text.index('### Immutable final archive evidence');end=text.index('The contribution map in Supplement',start)
    text=text[:start]+'''### Immutable final archive evidence

The exact V8 ZIP has SHA-256 c196b5f591c9ee48e9e7d8fa6e72431204e05195b7ee7ed5365ed7742d6735ab. Its detached report records 31/31 stages passing, 2,459 verified manifest entries and unchanged archive hashes. This includes exit code zero for independent_certificate_audit, whose external-review execution had a timeout after writing its PASS report. The report, environment, logs and digests are now included under evidence/V8_FINAL_RELEASE_EVIDENCE, with every sidecar checked by validate_v9.py. This is author-side local execution evidence; it does not convert the reviewer's partial run into independent full reproduction.

V9 has 33 default stages, adding the Boolean API study and audit. The frozen research ZIP and subsequent detached report are paired in one upload-ready complete delivery. Reading copies retain the measured snapshot; the final extraction's raw timings and rebuilt Markdown are supplied separately. The research ZIP is never repacked after verification. No remote CI or independent developer study is claimed.

'''+text[end:]
    old='The domain-query interface has 288 answers matching SMT and 24,408 direct policy checks. The added 720-record batch experiment includes construction and independent checking costs and finds that direct masks usually remain cheaper. Verified reuse is an evidence representation and a measured engineering tradeoff, not an automatic speed or productivity benefit.'
    text=text.replace(old,'The Boolean-only API isolates avoidable query-output costs while retaining the same independently checked complete certificate as the full API. Their paired comparison is assurance matched; comparisons with direct masks and incremental SMT are explicitly request-cost comparisons with different evidence obligations. Measured gains depend on request type and input, and establish no general productivity benefit.')
    abstract='''## Abstract

Software changes can preserve a selected decision at one precision target while changing decisions elsewhere. We present exact policy-aware regression diagnostics for fixed observations, returning complete divergent regions with endpoint ownership and input-bound certificates checked by a separate implementation. The method specializes established finite-region and certifying-computation techniques; it does not introduce a new general parameter-synthesis algorithm. Controlled program experiments identify 136 nonconforming runs, versus 111 with a thirteen-point grid. Historical-source replay of two documented upstream defects supports applicability, while adding no affected workload over that grid. A Boolean-only query index avoids constructing full intersection output while retaining the full certificate's independent verification obligations. Paired measurements separate this API cost from certificate preparation and from direct-mask or incremental-SMT request costs, whose evidence obligations differ. The resulting contribution is auditable regression localization with explicit numerical semantics and measured engineering tradeoffs. Developer triage benefit and production-policy effectiveness remain unmeasured.

'''
    text=text[:text.index('## Abstract')]+abstract+text[text.index('Keywords:'):]
    text=re.sub(r'^Keywords:.*$', 'Keywords: regression diagnosis; precision constraints; policy equivalence; independently checked certificates; allowed policy domains.',text,flags=re.M)
    supplement+='\n## S15 Boolean API study and comparison panels\n\nThe exact protocol is results/v9/boolean_protocol.json. Both certificate routes pay construction, JSON roundtrip and the same independent full verification; the indexed route also pays copying/freezing/index construction. This is the assurance-matched API panel. Direct masks and incremental Z3 answer the same Boolean question without emitting/checking a complete diagnostic object, so four-route totals are a separate request-cost panel with unequal evidence obligations. The original six inputs and 2,028 plans are reused: 960 timing records, 192 groups and 40,560 repeated method answers are not new workloads or defects. Full per-phase medians/IQRs and raw observations are retained. A descriptive speed ratio is not a statistical or deployment guarantee. BOOLEAN_QUERY_AND_ASSURANCE.md gives component-merging/endpoint reasoning, asymptotic scope and refusal behavior.\n'
    (Q/'docs/SUPPLEMENT_Q1_V9.md').write_text(supplement,encoding='utf-8')
    return text

def vietnamese_report(Q):
    return '''# Kết quả Q1 V9 ngày 30 tháng 10 năm 2026

V9 tập trung exact policy-aware regression diagnosis và independent certificate checking. Abstract được rút gọn. Thêm VerifiedBooleanIndex: xác minh cùng complete input-bound certificate, đóng băng và lập chỉ mục các vùng khác nhau, rồi trả Boolean/witness mà không tạo full intersections. Không claim phát minh interval union/binary search.

Đối chứng mới tách hai panel: hai API certificate có cùng nghĩa vụ construction/JSON/full checking; bốn workflow trả cùng Boolean nhưng khác nghĩa vụ tạo/kiểm tra evidence. Cùng sáu input và 2.028 query plans có sẵn, 960 timings/192 nhóm và 40.560 repeated answers; không tăng số real bugs hay independent workloads. Có 41 core tests, thêm bốn tests nhắm endpoint holes, tamper/refusal và immutable reuse. Production policies/developer study vẫn chưa có.

Đúng report V8 31/31 và exit code của independent_certificate_audit đã có trong evidence/V8_FINAL_RELEASE_EVIDENCE. V9 có 33 stages; giao trọn complete delivery chứa đúng research ZIP và detached report, không repack ZIP sau kiểm chứng. Hồ sơ Q2 gốc giữ nguyên.
'''
