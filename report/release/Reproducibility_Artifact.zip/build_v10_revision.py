"""Targeted editorial revision; scientific implementations/protocol stay V9."""
import json,re,hashlib

TITLE='Exact Policy-Aware Regression Diagnosis for Precision-Constrained Threshold Selectors'

def context_audit(Q,text):
    if (Q/'provenance/v11_source_bindings.json').exists():
        from build_v11_revision import source_audit
        return source_audit(Q,text)
    def read(path):return json.loads(path.read_text(encoding='utf-8'))
    def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
    folder=Q/'evidence/V9_FINAL_RELEASE_EVIDENCE';report=read(folder/'RELEASE_VERIFICATION.json');expected='7cef6e2f0355f701c044f3a1e46239ccc016325706ad2f0aca48a807bda03340'
    assert report['status']=='PASS' and len(report['stages'])==33 and all(s['exit_code']==0 for s in report['stages'])
    assert report['archive_sha256_before']==report['archive_sha256_after']==expected
    assert next(s for s in report['stages'] if s['stage']=='independent_certificate_audit')['exit_code']==0
    sidecars=read(folder/'EVIDENCE_MANIFEST.json')
    for name,digest in sidecars.items():assert sha(folder/name)==digest
    science=read(Q/'provenance/v9_science_source_hashes.json');assert science['archive_sha256']==expected
    for name,digest in science['files'].items():
        # V9 archived snapshot predates its root driver environment-report fix.
        if name=='results/execution_source_snapshot/run_experiments.py':
            assert sha(Q/name) in {digest,science['files']['run_experiments.py']},('Generated snapshot source mismatch',name)
        else:assert sha(Q/name)==digest,('Scientific source changed',name)
    status=read(Q/'provenance/related_manuscript_status.json');assert status['citation_status'].startswith('Unpublished') and status['publication_doi'] is None
    assert text.splitlines()[0]=='# '+TITLE
    assert list(map(int,re.findall(r'^\[(\d+)\]',text,re.M)))==list(range(1,30))
    assert '[29]' in text.split('## 2. Research questions')[0] and 'unpublished' in text.lower()
    result=dict(status='PASS',prior_v9_exact_stages=33,prior_v9_archive_sha256=expected,prior_certificate_audit_exit_code=0,sidecars_hash_verified=len(sidecars),scientific_source_files_unchanged=len(science['files'])-1,generated_snapshot_binding='Snapshot must match archived V9 bytes or unchanged V9 root driver bytes; the archived snapshot predates an environment reporting fix',default_stage_driver_unchanged='run_all.py' in science['files'],scientific_protocol_stages=33,manuscript_title=TITLE,external_references_retained=28,related_unpublished_reference=29,publication_status_source='Direct user confirmation; no fabricated publication metadata',scope='Editorial scope/title/overlap and release-context checks; no new scientific experiment, property-test corpus or external validation claimed.')
    out=Q/'results/v10';out.mkdir(parents=True,exist_ok=True);(out/'editorial_context_validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8')

def integrate(Q,text):
    text=re.sub(r'^# .*$', '# '+TITLE,text,count=1,flags=re.M)
    text=re.sub(r'^\*\*Research manuscript V9.*$', '**Research manuscript V10, revised on 30 October 2026.**',text,count=1,flags=re.M)
    intro='''## 1. Problem, scope and contribution

For a precision-constrained threshold selector, a software change may preserve the selected observations at one policy while changing them elsewhere in an allowed domain. A score-structural change alone does not establish a policy regression. We compare selected observation IDs under an agreed empirical contract: labels and aligned IDs are fixed, candidates come from a finite family of score thresholds, and feasibility, priority and abstention are explicit. The question is equality throughout the caller's permitted policy set and, when equality fails, its exact location and a checkable observation witness.

Parameter-region reasoning [6,7,20], predicate enumeration [23–25] and certifying computations [9,17] provide the closest foundations. Our contribution is their specialization to this selector contract and an executable evidence pipeline. It comprises endpoint-sensitive diagnostic cells with exact numerical-interface semantics; input-bound certificates and a separately implemented consumer; and checked permitted-domain queries, evaluated with controlled programs, documented source replays and explicit cost protocols. Boolean and full-output certificate APIs are compared under the same certificate obligations, while direct-mask/SMT request costs are kept distinct. The finite partition, interval indexing and producer/checker principles are established techniques.

The related work Exact Candidate Frontier Comparison for Decision Regression Testing of Precision-Constrained Selectors [29] is an unpublished manuscript supplied by the authors, who confirmed that status for this revision. It already introduces the observation contract, compact candidate-frontier comparison and checked proper-prefix attribution. Its labels/ID conventions, inherited observations and 255 counterfactual grid records are reused here. This extension studies selected-ID equivalence over policy domains and adds complete interval certificates, independent streaming consumption, explicit rational/binary64 semantics, executable conformance studies and verified domain-query interfaces. INHERITANCE_AND_PUBLICATION_BOUNDARY.md maps the reused and added components to hash-bound source snapshots. The earlier contract, witness machinery and reused data are not counted as new contributions.

'''
    start=text.index('## 1.');end=text.index('## 2. Research questions',start);text=text[:start]+intro+text[end:]
    text=text.replace('Software changes can preserve a selected decision at one precision target while changing decisions elsewhere.','Changes to precision-constrained threshold selectors can preserve selected observations at one policy while changing them elsewhere.')
    threats='''## 10. Threats to validity

Internal and construct validity. The independently coded checker shares the written contract with the producer and may share conceptual errors; finite tests are not a machine-checked proof. Input hashes protect accidental binding integrity, not source authenticity or label quality. PSC measures interval length, excludes isolated points and is not a deployment probability. The declared-semantics study supplies mutant contracts; the program-conformance study instead uses an unchanged reference, with source admission and guard-coverage assumptions limiting its scope.

External validity. Historical cases are related, generated fixtures are controlled, and pipeline seeds repeat three local dataset families. The two documented defects are historical-source replays through compatibility bridges with constructed propagation carriers and shared dependencies. Grid13 detects every affected workload in both cases, so no added real-bug detection rate is established. Results concern fixed labeled inputs, not predictive generalization. There is no independent developer triage study, production-policy inventory or prospective deployment.

Performance validity. Results come from one host and modest repetitions; allocation tracing and untraced timings are separate protocols. Input/candidate structure and arbitrary-precision arithmetic matter, and checking/witness work can remain O(NG)/O(ND). The paired certificate APIs share full construction/checking obligations; four-route request costs do not share evidence-production obligations. Reported medians and speedups remain descriptive for each workload and protocol.

Contribution and overlap. Region partitioning, constrained selection, AllSMT and certificate checking have established foundations. The 28-source check is focused, not systematic, and does not prove absence of closer work. The related unpublished manuscript [29] is disclosed with its reused components; the current integration and evaluation do not establish general algorithmic originality or industrial effectiveness.

'''
    start=text.index('## 10. Threats to validity');end=text.index('## 11.',start);text=text[:start]+threats+text[end:]
    start=text.index('## 11.');end=text.index('## 12. Conclusion',start);old=text[start:end]
    match=re.search(r'\| Method considered \|.*?\n(?:\|[^\n]*\n)+',old);assert match
    table=match.group().replace('Eight external and 27 controlled tasks; complete outputs and checker agree','Eight external, 27 factorial and six larger-G tasks; complete outputs and checker agree')
    related='''## 11. Related work and closest comparison

Rath and Hughes [1], Mackey et al. [2] and Tasche [3] establish constrained threshold-selection foundations; scikit-learn documents the calibration [5] and public selector [21] interfaces used here. Metamorphic/mutation testing of optimization and classifier implementations [4,11,12] provides the testing context. The inherited candidate-frontier manuscript [29] is related prior work, with its reused contract, data and witness machinery identified in Section 1.

Storm and parameter synthesis [6,7,20], regression verification [8], certifying computations [9,17], proof-carrying code [10], robust classification [18] and parametric monitoring [19] reason about related properties or evidence boundaries. Predicate enumeration and AllSMT [23–25] already support general solution-region exploration; rounding-preimage reasoning [26] underlies the numerical-interface mapping. These are positive foundations, not claims that existing tools lack endpoint or full-region capabilities. Our empirical SMT baselines encode the selected-ID contract directly; they do not reproduce an independently optimized AllSMT implementation.

The table separates executed same-contract comparisons from conceptual foundations. Complete-region protocols and request-cost protocols retain different outputs, obligations and timing boundaries. Supplement S10–S11 contains the detailed source distinctions; BIBLIOGRAPHY_AUDIT_V8.md and its V10 addendum record the source/metadata-check scope.

'''+table+'\n'
    text=text[:start]+related+text[end:]
    conclusion='''## 12. Conclusion

For fixed observations and precision-constrained threshold selectors, the specified contract supports exact selected-ID equivalence, complete divergent regions with endpoint ownership and input-bound diagnostic evidence. An independently implemented consumer checks that evidence; the Boolean index avoids full query-output construction while retaining the same certificate obligations as the full API. Matched API costs and four-route request costs answer different questions and remain separated.

The evaluation supports scoped correctness, localization and engineering-cost findings. It does not establish additional affected-workload detection over grid on the two documented defects, general speed superiority, developer productivity or production-policy effectiveness. The contribution is a specialized auditable diagnostic pipeline, with established foundations and inherited work [29] explicitly disclosed.

'''
    start=text.index('## 12. Conclusion');end=text.index('## Reproducibility and declarations',start);text=text[:start]+conclusion+text[end:]
    release='''### Verified release provenance

The exact V9 research ZIP was executed through all 33 stages, including the certificate audit with exit code zero. Its hash-bound report, environment, logs and output digests are included under evidence/V9_FINAL_RELEASE_EVIDENCE. V10 retains the same scientific Python implementations and 33-stage protocol; source hashes are checked against V9. The exact V10 ZIP is frozen and executed before its detached report is paired with it in the complete reviewer delivery. The reading copy is a measured snapshot, and fresh rerun outputs are supplied separately. REPRODUCIBILITY_V10.md gives archive identities, commands and evidence scope. These are author-side local executions, not independent institutional reproduction.

'''
    text=text.replace('## References',release+'## References',1).replace('in this Q1 artifact','in this research artifact')
    text+='\n[29] Exact Candidate Frontier Comparison for Decision Regression Testing of Precision-Constrained Selectors. (2026). Unpublished related manuscript supplied by the authors; status confirmed by the authors for this revision. Source snapshot: provenance/q2_reference/main.tex.\n'
    supplement=(Q/'docs/SUPPLEMENT_Q1_V9.md').read_text(encoding='utf-8').replace('for Q1 V9','for Q1 V10')
    supplement+='\n## S16 V10 scope and overlap clarification\n\nV10 changes scope/title, repetition and release context; scientific implementations and the 33-stage protocol remain V9, bound in provenance/v9_science_source_hashes.json. Reference [29] is the authors\' confirmed unpublished related manuscript, separate from the 28 external sources. See the overlap map, status provenance and exact V9 detached execution report.\n'
    (Q/'docs/SUPPLEMENT_Q1_V10.md').write_text(supplement,encoding='utf-8')
    context_audit(Q,text)
    return text

def vietnamese_report(Q):
    return '''# Kết quả bản sửa V10 ngày 30 tháng 10 năm 2026

Đây là bản sửa biên tập và hồ sơ release theo phản biện V9, không thêm thuật toán, dataset, property-test corpus hay giao thức benchmark. Tiêu đề nêu rõ precision-constrained threshold selectors. Introduction, Threats, Related Work và Conclusion được rút gọn để giảm lặp; independently checked certificates vẫn là nội dung chính của Abstract/Contributions.

Người dùng xác nhận bài kế thừa chưa công bố; Main trích dẫn unpublished manuscript [29] và cập nhật overlap map. Không gán DOI/venue hoặc giả publication metadata. 28 nguồn bên ngoài được giữ riêng với reference unpublished mới.

V10 giữ nguyên scientific Python source và 33 default stages của V9, có đối chiếu hashes. Bằng chứng exact V9 33/33, gồm certificate audit exit 0, nằm trong evidence/V9_FINAL_RELEASE_EVIDENCE. Đúng ZIP V10 được freeze và chạy lại; report V10 đi cùng ZIP trong complete reviewer delivery. Giới hạn một host, ít repetitions, reused plans, source-replay bridges, no real-bug grid gain và chưa có developer/production study vẫn được giữ. Q2 gốc không bị sửa.
'''
