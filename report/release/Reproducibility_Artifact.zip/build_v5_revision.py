"""Integrate independently replayable V5 evidence without inflating bug counts."""
import json,csv,re,xml.etree.ElementTree as ET
import numpy as np

def vietnamese_report(Q):
    return '''# Kết quả Q1 V5 ngày 30/10/2026

Đã thực hiện các hướng theo phản biện V4. Bản đọc hiện tại là docs/MANUSCRIPT_Q1_V5.pdf và .docx; nguồn nội dung là docs/MANUSCRIPT_Q1.md.

- Checker streaming được viết độc lập với production/legacy checker, kiểm tra đủ 428 certificates và 41.348 probes. Phép đo ghép cặp 72 bản ghi (60 timing, 12 memory), tới 100.000 mẫu, giữ cùng nghĩa vụ hash/coverage/witness. Xem bảng thực đo results/v5/paired_checker_summary.csv.
- Dự án thứ hai eval-toolkit 1.12.0 được cài từ wheel nguồn nguyên vẹn tại commit ghim, chạy bằng Python 3.13.18. 18 upstream tests PASS. Trên 30 workload, 884 policy probes phát hiện 27 khác biệt ngữ nghĩa với oracle hữu tỉ; 196 probes tại policy biểu diễn được có khác biệt ở 19 workload. Không gọi các khác biệt này là confirmed bugs.
- Đối chứng complete-region mở rộng 27 task factorial, 270 timing records, 54 certificates, 0–39 components; mọi đầu ra partition/SMT khớp. Tám task external trước được giữ riêng.
- Bổ sung lập luận soundness của streaming và biên làm tròn, Related Work gần hơn và RQ5–RQ7.
- Báo cáo chạy đúng ZIP V4 đủ 19 stages nằm trong evidence/V4_FINAL_RELEASE_EVIDENCE. V5 dùng 23 stages, bằng chứng chạy trên đúng ZIP cuối được giao tách rời cùng gói delivery.

Các số đo lịch sử Python 3.12 và thí nghiệm V5 Python 3.13 được phân biệt. Không lấy tỷ số producer/checker từ hai giao thức khác nhau. Có hai dự án ngoài thực thi nhưng vẫn chỉ một upstream-confirmed defect; eval-toolkit dùng scikit-learn làm phụ thuộc. Chưa chứng minh independent deployment, multi-project defect-detection rate hoặc sẵn sàng nộp Q1. Xem RESPONSE_TO_REVIEW_V5.md và docs/REPRODUCIBILITY_V5.md.
'''

def integrate(Q,text):
    R=Q/'results/v5';read=lambda p:json.loads(p.read_text(encoding='utf-8'))
    second=read(R/'second_project_summary.json');paired=list(csv.DictReader((R/'paired_checker_summary.csv').open()));raw=list(csv.DictReader((R/'expanded_region_raw.csv').open()));expanded=read(R/'expanded_region_summary.json')
    tests=sum(int(t.get('tests',0)) for t in ET.parse(Q/'results/pytest.xml').iter('testsuite'))
    text=text.replace('All 25 pytest test items pass',f'All {tests} core pytest test items pass')
    text=text.replace('Research manuscript revised after technical review on 30 October 2026.','Research manuscript V5 revised after technical review on 30 October 2026.')
    text=text.replace('Eight matched tasks; complete outputs and independent checker agree','Eight external and 27 controlled tasks; complete outputs and checker agree')
    text=text.replace('It adds universal policy-domain comparison, endpoint-sensitive certificates, a domain-length metric, and controlled selector/numerical mutations.','It adds universal policy-domain comparison, endpoint-sensitive certificates, a domain-length metric, controlled selector/numerical mutations, and a separately implemented streaming consumer. The revision also makes binary64 policy boundaries explicit and checks integration on two externally authored projects.')
    text=text.replace('## 3. Contract','RQ5: How do partition and SMT compare when both must produce identical complete regions, endpoint ownership, PSC and representative witnesses, across input size, candidate count and divergent-component structure?\n\nRQ6: Can a separately implemented streaming consumer preserve all certificate obligations while reducing paired verification time and auxiliary memory?\n\nRQ7: What diagnostic differences arise when a second external project uses a binary64 public policy interface instead of an exact rational contract, and which of these are software defects?\n\n## 3. Contract',1)
    a=text.index('## Abstract');b=text.index('Keywords:',a)
    abstract='''## Abstract

Sampled precision policies can miss changed threshold decisions elsewhere in an allowed domain. We compute exact finite-input membership equivalence, endpoint-sensitive divergent regions and independently checkable certificates under an explicit selector contract. Controlled program experiments detect 136 nonconforming runs, versus 111 with a thirteen-point grid. One documented scikit-learn defect affects fifteen workloads, all found by both methods. A second installed external project, eval-toolkit, exposes binary64 policy boundaries: 27 of thirty fixed workloads differ from a rational reference in narrow regions missed by the grid; these are semantic differences, not confirmed upstream defects. Partition and SMT return identical complete diagnostics on eight external tasks and 27 controlled scaling tasks. A separate streaming certificate consumer preserves the checked obligations while avoiding retention of all threshold masks; paired measurements quantify its time and memory tradeoff through 100,000 observations. Immutable release archives are executed before detached hash-bound evidence is delivered. The contribution is specialized contract-aware diagnosis and scoped integration; general parameter-region reasoning, deployment readiness and multi-project defect-detection rates are not established.

'''
    text=text[:a]+abstract+text[b:]
    old='We also inspect a second independently authored project, eval-toolkit'
    start=text.find(old)
    if start>=0:
        end=text.find('\n\n',start)
        text=text[:start]+'''The preceding public-API study concerns a second component in scikit-learn. V4 additionally inspected eval-toolkit but did not execute it because its Python >=3.13 requirement conflicted with V4's Python 3.12.10 environment. That historical refusal is retained in the V4 results. V5 uses a separate Python 3.13.18 environment and executes the installed second project as described below; the former compatibility barrier is not represented as an executed case.''' +text[end:]
    cr=[]
    for n in [1000,10000,100000]:
        for work in ['invariant','divergent']:
            aa=next(r for r in paired if int(r['n'])==n and r['workload']==work and r['method']=='legacy');bb=next(r for r in paired if int(r['n'])==n and r['workload']==work and r['method']=='streamed')
            cr.append(f"| {n:,} / {work} | {float(aa['median_ms']):.2f} ({float(aa['iqr_ms']):.2f}) | {float(bb['median_ms']):.2f} ({float(bb['iqr_ms']):.2f}) | {float(aa['peak_aux_mib']):.2f} | {float(bb['peak_aux_mib']):.2f} |")
    checker='''### RQ6 Streaming certificate consumption

The legacy verifier first materializes all Boolean threshold masks. Its independently measured cost motivated a second consumer, not a change to the producer or finite partition theorem. The new implementation imports neither production code nor the legacy checker. It counts one threshold mask at a time, retaining only exact ratios, actual TP/N and candidate descriptors. A reverse suffix-maximum table over ascending feasibility ratios supplies exhaustive-priority winners by exact bisection. It reconstructs and packs only the current winning mask for each version. It uses no production priority heap or rank-containment comparator and retains no all-candidate bitset cache.

The suffix winner argument is direct: feasible candidates form a suffix (lower bound for inclusive feasibility, upper bound for strict feasibility), and reverse induction computes that suffix's maximum fixed priority. Independent critical-point construction, ordered certificate coverage and endpoint ownership then justify checking all atom representatives. A forward cell cursor validates each probe; actual bitsets validate equality, witness IDs/memberships and changed-row counts. Exact divergent length and PSC are independently recomputed. Detailed lemmas and conditional soundness are in STREAMING_CHECKER_AND_FLOAT_CUT_PROOFS.md. These are mathematical arguments plus tests, not a machine-checked proof or independent human replication.

The consumer uses O(N+G+K+C) auxiliary descriptors/probes and current-mask storage, excluding arbitrary-precision operand sizes, for K critical values and C certificate cells. Direct counting and winner reconstruction retain worst-case O(NG) work; split-tie ordering adds O(N log N), with ratio/query/probe sorting costs stated in the proof supplement. In particular, G=N can still be quadratic. Suffix maxima, bisection and streaming are established techniques [17], not new general primitives.

All 428 frozen application/mutation certificates are accepted under the same obligations as the legacy checker, covering 41,348 probes. New exhaustive small-input comparisons exercise seven specifications; tamper tests reject altered bindings, partitions, winners and metrics, and retain point-only non-equivalence. Thirty core tests pass; the upstream project's eighteen tests are counted separately.

The paired experiment regenerates the same six N/G fixtures as the earlier checker study, prepares an identical certificate/payload outside timing, warms up both consumers, and randomizes their order within each of five repetitions. JSON parsing is recorded separately. A sixth invocation per consumer/group traces memory independently. The sixty untraced timing records and twelve separate memory records are never pooled. Each row below compares identical inputs, policies, coverage, hash and witness obligations; these are not ratios against the differently instrumented producer benchmark.

| N / fixture | Legacy median (IQR), ms | Streaming median (IQR), ms | Legacy peak MiB | Streaming peak MiB |
|---|---|---|---|---|
'''+ '\n'.join(cr)+'''

Memory peaks are auxiliary allocations with inputs/certificate prepared in advance and one traced run per group. Five timings on one host do not establish a universal CI budget. The implementation preserves a deliberately different verification route while reducing retained masks; shared dependencies and mathematical assumptions remain trusted. Results show an implementation tradeoff under this contract, not a general theorem that checking is always cheaper than production.

'''
    text=re.sub(r'### Independent certificate consumption at scale\n.*?(?=## 10\. Threats)',checker,text,flags=re.S)
    text=text.replace('Thirty core tests pass',f'{tests} core tests pass')
    scaling=[];wins=0
    for case in sorted({r['case_id'] for r in raw}):
        aa=[r for r in raw if r['case_id']==case and r['method']=='partition'];bb=[r for r in raw if r['case_id']==case and r['method']=='smt_all_regions'];pa=np.median([float(r['total_checked_ms']) for r in aa]);pb=np.median([float(r['total_checked_ms']) for r in bb]);wins+=pa<pb
        if aa[0]['n']=='100000':scaling.append(f"| {aa[0]['g']} / {aa[0]['pattern']} | {aa[0]['critical_points']} | {aa[0]['divergent_components']} | {pa:.2f} | {pb:.2f} |")
    regions=f'''### RQ5 Diagnostic-complete comparison across workload structure

Both implementations must return the same maximal divergent components, exact endpoint ownership, exact PSC, separate Boolean equivalence and one representative policy/row witness per component. A representative witness is existential at its reported policy, not one observation changing throughout a component. SMT repeatedly finds a QF_LRA model, expands it to its complete feasibility-predicate cell, blocks that cell, and finishes only at residual UNSAT. Unknown/timeout prevents certification. General predicate enumeration is established [23-25]; complete diagnostics are not a unique capability of our partition method.

The eight V4 external affected/fixed tasks remain a separate check and still agree. We add a prespecified factorial design: N in {{1,000,10,000,100,000}}, G in {{10,30,90}}, and no, one-middle, or alternating candidate omission. Scores form G tied groups with gradually decreasing group-positive proportions; fixed-seed permutations remove dependence on row order. These designed families yield {expanded['component_range'][0]}–{expanded['component_range'][1]} divergent components. They are controlled tasks, not new upstream defects or independent deployments. Every one of the 27 tasks is retained, including empty-divergence controls.

Five repetitions per method/task, with randomized method order inside each repetition, produce 270 timing records and 54 saved certificates. Both methods receive the same candidate family, regenerate counts/masks during each timed preparation, emit the same diagnostic JSON and invoke the same independent region checker. All complete outputs agree and every saved certificate is replayed. Preparation, producer plus serialization, checker, total checked cost, candidate counts, exact critical-point count, divergent components, probes, bytes and solver calls are retained separately. Thus input-size effects are not inferred from a preparation-excluded timer alone.

The table shows N=100,000; the raw factorial records preserve the other scales. Total includes fresh preparation, complete diagnostic production/JSON and independent checking. Entries are within-task medians of five runs, not pooled medians across heterogeneous tasks.

| G / omission | Critical points | Components | Partition total ms | SMT total ms |
|---|---|---|---|---|
'''+ '\n'.join(scaling)+f'''

Across all 27 designed tasks, partition has the smaller total median on {wins}; the other {27-wins} have an equal or smaller SMT median. These descriptive comparisons do not establish statistical significance, superiority for arbitrary selectors or parity with an optimized general AllSMT solver. This is our direct Z3 encoding and generic external-table partition adapter, not a reproduction of TabularAllSMT or a benchmark of the compact rank-based producer. The region checker still enumerates prepared memberships and is distinct from the new streaming consumer for the core certificate format. Evidence supports scoped cost characterization and common diagnostic correctness; broader performance claims remain unsupported.

'''
    text=re.sub(r'### Matched complete-region diagnostics, including certification costs\n.*?(?=### Immutable final-archive reproduction)','',text,flags=re.S)
    text=text.replace('## 9. Integration',regions+'## 9. Integration',1)
    external=f'''### RQ7 An executed second project and its actual policy semantics

We build a wheel from the complete, unmodified eval-toolkit 1.12.0 source at commit `a6400e74c4534d6d79f17dee11ad903b6d664980`, retaining hashes, its MIT license and package metadata. Python 3.13.18 satisfies its >=3.13 requirement. The installed TargetPrecisionSelector is called through its actual public API; no method body is extracted, patched or replaced with a custom scorer. All eighteen packaged upstream threshold tests pass. The package and source are distributed for offline installation. The two externally authored projects executed across the studies are now scikit-learn and eval-toolkit, although the latter depends on scikit-learn's precision-recall routine; this is not independent numerical infrastructure or independent institutional deployment.

The workload rule is fixed: first 64 rows of all thirty existing pipeline inputs, with no positive-case filtering. The wrapper passes float(alpha) to the public precision parameter and maps only the documented no-feasible RuntimeError to abstention. Its exact-reference objective is still maximum (TP,N); in the same nested family, this equals the project's smallest-feasible-threshold objective. Input validation, source identity and candidate counts are checked. Actual floating precision values are compared against direct integer membership counts.

It would be unsound to assume a binary64 guard changes exactly at the rational ratio k/n. For an actual binary64 precision p, let q=nextafter(p,+infinity) and c=(exact(p)+exact(q))/2. The public predicate p >= float(alpha) changes at c, including equality exactly when p has the even significand. The proof follows monotone nearest/even rounding and is a selector-specific application of established rounding-preimage reasoning [26]. We explicitly check midpoint ownership and both neighboring cells on the runtime. The complete critical set is the union of rational-reference cuts, these rounding-cell cuts and domain endpoints. A model of these guards is checked against every actual public-API output, including all endpoints; unsupported numerical behavior must prevent certification.

Across thirty workloads, {second['policy_probes']} critical-point/midpoint policies and {second['public_calls']} public invocations (including the grid/snapshot baselines) are executed. The guard model matches every actual output. Twenty-seven workloads have narrow differences from the exact rational reference; neither snapshot nor the thirteen-point grid detects any of them. These are twenty-seven semantic differentials, not twenty-seven bugs or regressions between upstream releases. The library documents a floating policy interface, so the rational reference is a caller-selected stronger/different contract, not an upstream requirement it is shown to violate. The upstream-confirmed defect count remains one; on that documented scikit-learn defect, incremental detection over grid remains zero.

Each input-bound certificate preserves exact rounding-cut fractions, ownership, actual/reference bitsets, row witnesses, complete divergent regions and PSC. The validator calls the installed selector again at all 884 policies and checks every stored field. We additionally probe actual representable binary64 precision policies: {second['representable_policy_probes']} such probes expose differences on {second['representable_policy_divergent_workloads']} workloads. Grid/snapshot targets are exact rational fractions, whereas this additional group embeds each binary64 value by its exact integer ratio; it does not reinterpret a decimal grid target as its binary approximation. Thus the continuous-domain finding is not automatically equated to a difference at a policy the float API can represent. With labels [1,1,0,0,0] ordered by decreasing distinct score, the representable float 0.4 exceeds exact 2/5: at the exact rational embedding of that float, the float selector admits all five while the rational reference admits four. At exact decimal 2/5 both admit five. This is a designed explanation of distinct policy contracts, not a newly documented upstream bug. Tiny interval length is not a deployment probability or impact estimate. Adoption should decide whether binary64 semantics are acceptable, rather than treating every differential as a release-blocking defect.

'''
    text=text.replace('## 10. Threats',external+'## 10. Threats')
    text=text.replace('The V4 release follows the same non-circular protocol with nineteen stages.','The V4 release also completed nineteen stages on its exact ZIP, SHA-256 `f45403ce8011adc3d084af2b432953286072fd8b6302e134ab1e087d4075b835`, with unchanged before/after hashes, 1,269 manifest files and 1,037 result-output digests. Its detached report and stage logs are included under evidence/V4_FINAL_RELEASE_EVIDENCE in this revision; they must accompany the old archive rather than be inferred from its historical internal status file. The V5 release follows the same non-circular protocol with twenty-three stages under Python 3.13.18.')
    text=text.replace('The actual V4 pass/fail outcome and digest belong to the detached release report delivered with the archive','The actual V5 pass/fail outcome and digest belong to the detached release report delivered with the archive')
    text=text.replace('Freeze source, measured tables and rendered reading copies first;','The new archive omits stale root run_all status/log files; fresh execution creates its own. Freeze source, measured tables and rendered reading copies first;')
    closest='''### Closest algorithmic overlap and remaining contribution

The closest overlap is concrete. Morettin et al. [24] use SMT predicate abstraction to enumerate models for weighted integration; our uniform one-dimensional PSC is not a new general integration principle. Spallitta et al. [25] develop disjoint projected enumeration with more sophisticated solver techniques than our blocking-cell baseline. We therefore do not interpret a win over our encoding as a win over state-of-the-art AllSMT. Andrlon's rounding-preimage analysis [26] establishes a wider arithmetic foundation than the single guard mapping used here. Certifying-computation frameworks [9,17] already motivate a simple independent consumer. Suffix maxima and one-mask-at-a-time processing are implementation choices within that tradition. These sources narrow the proposed contribution to the fully specified precision-selector contract, exact boundary-aware diagnostic artifacts, an independently implemented consumer with measured tradeoffs, and checked integration on two external projects. They do not establish first-in-literature novelty of partitioning, rounding preimages, enumeration or streaming.

'''
    text=text.replace('## 12. Conclusion',closest+'## 12. Conclusion')
    conclusion='''## 12. Conclusion

The specified finite selector contract supports exact membership comparison with explicit ownership of policy endpoints and independently replayable diagnostic evidence. Partition and SMT both produce complete regions; the expanded matched study characterizes their costs rather than assigning exclusive capability to one method. A separately implemented streaming consumer preserves the certificate obligations and reduces measured retained-memory and checking costs on paired fixtures, while retaining worst-case O(NG) scanning work. Executing two external projects demonstrates an upstream defect's policy propagation and the separate effect of binary64 interface semantics. The latter differences require an explicit caller contract before they can be treated as regressions. One confirmed defect, shared numerical dependencies and one-host timings leave broader bug-detection rates, deployment budgets and first-in-literature novelty unresolved.

'''
    text=re.sub(r'## 12\. Conclusion\n.*?(?=## Reproducibility and declarations)',conclusion,text,flags=re.S)
    refs='''
[24] Morettin, P.; Passerini, A.; Sebastiani, R. (2017). Efficient Weighted Model Integration via SMT-Based Predicate Abstraction. IJCAI. Author manuscript: https://sml.disi.unitn.it/papers/ijcai17.pdf

[25] Spallitta, G.; Sebastiani, R.; Biere, A. (2025). Disjoint projected enumeration for SAT and SMT without blocking clauses. Artificial Intelligence, 345, 104346. https://doi.org/10.1016/j.artint.2025.104346

[26] Andrlon, M. (2023). Finding Normal Binary Floating-Point Factors Efficiently. Journal of Automated Reasoning, 67, article 11. https://doi.org/10.1007/s10817-023-09659-1
'''
    (Q/'docs/V5_ADDITIONAL_EVIDENCE.md').write_text(checker+regions+external+closest+refs,encoding='utf-8')
    return text+'\n'+refs
