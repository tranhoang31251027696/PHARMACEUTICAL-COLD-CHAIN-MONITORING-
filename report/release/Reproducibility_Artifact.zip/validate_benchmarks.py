"""Audit timing summaries and reconstruct each timed certificate workload."""
from pathlib import Path
import sys,json,csv,hashlib
import numpy as np
Q=Path(__file__).resolve().parent;sys.path.insert(0,str(Q/'src'))
from policy_exact import compare_policies
from independent_oracle import verify

def main():
    R=Q/'results';read=lambda name:list(csv.DictReader((R/name).open(encoding='utf-8')))
    raw=read('certificate_timings.csv');count=0;hashes=[]
    for n,g in [(1000,20),(10000,100),(100000,500)]:
        rng=np.random.default_rng(n+g);a=rng.integers(0,g,n)/(g-1);y=rng.integers(0,2,n);ids=list(range(n))
        for workload in ['invariant','divergent']:
            b=a.copy() if workload=='invariant' else a+rng.choice([-1,0,1],n)*1e-8
            c=compare_policies(y,a,b,ids=ids);v=verify(y,a,b,ids,c);count+=1
            hashes.append({'n':n,'g':g,'workload':workload,'input_sha256':c['input_sha256'],'oracle_probes':v['probes']})
            for mode in [False,True]:
                cc=c if mode else compare_policies(y,a,b,ids=ids,with_witness=False)
                rr=[r for r in raw if r['n']==str(n) and r['workload']==workload and r['witness']==str(mode)]
                assert len(rr)==10
                for row in rr:
                    assert int(row['cells'])==len(cc['cells']) and float(row['psc'])==cc['psc']
                    assert int(row['bytes'])==len(json.dumps(cc).encode())
                    assert int(row['witness_cells'])==sum(x['witness'] is not None for x in cc['cells'])
            for _ in range(10):rng.permutation([False,True])
    matched=read('matched_method_timings.csv');summaries=read('matched_method_summary.csv')
    assert len(matched)==270 and len(summaries)==45
    for s in summaries:
        rr=[r for r in matched if all(r[k]==s[k] for k in ['pipeline','workload','method'])]
        assert len(rr)==6 and {int(r['replicate']) for r in rr}==set(range(6))
        v=[float(r['elapsed_ms']) for r in rr];q=np.percentile(v,[25,75],method='linear')
        assert np.isclose(np.median(v),float(s['median_ms']),atol=1e-12,rtol=0)
        assert np.isclose(q[1]-q[0],float(s['iqr_ms']),atol=1e-12,rtol=0)
    metadata=json.loads((R/'matched_method_metadata.json').read_text(encoding='utf-8'))
    for name,digest in metadata['source_sha256'].items():assert hashlib.sha256((Q/name.replace('\\','/')).read_bytes()).hexdigest()==digest
    sourcefiles=[R/'execution_source_snapshot/run_experiments.py',R/'execution_source_snapshot/policy_exact.py']
    result={'status':'PASS','certificate_timing_rows':len(raw),'reconstructed_workloads':count,'workload_hashes':hashes,'matched_method_rows':len(matched),'matched_method_groups':len(summaries),'measurement_source_sha256':{f.relative_to(Q).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in sourcefiles},'raw_record_sha256':{name:hashlib.sha256((R/name).read_bytes()).hexdigest() for name in ['certificate_timings.csv','certificate_timing_summary.csv','matched_method_timings.csv','matched_method_summary.csv']}}
    (R/'benchmark_validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
