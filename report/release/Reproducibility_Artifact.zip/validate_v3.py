"""Replay all external certificates and cross-check adverse/SMT/CI evidence."""
from pathlib import Path
from fractions import Fraction
import sys,json,csv,hashlib
import numpy as np
import z3
from sklearn.metrics import precision_recall_curve
Q=Path(__file__).resolve().parent;sys.path.insert(0,str(Q/'src'))
from external_sut_evaluation import upstream_functions,actual_table
from independent_oracle import candidates,select
from policy_exact import DEFAULT
from adapter_admission import admission_result

def main():
    R=Q/'results/v3';manifest=json.loads((Q/'inputs/external_sut/manifest.json').read_text(encoding='utf-8'));records={r['case_id']:r for r in manifest['cases']};functions=upstream_functions()
    results=list(csv.DictReader((R/'external_sut_results.csv').open()));certificates=0;probes=0
    for row in results:
        rec=records[row['case_id']];f=Q/'inputs/external_sut'/rec['file'];assert hashlib.sha256(f.read_bytes()).hexdigest()==rec['sha256'];d=np.load(f);y=d['y'];s=d['scores'];ids=d['ids'].tolist()
        c=json.loads((Q/row['certificate_file']).read_text(encoding='utf-8'));assert c['input_sha256']==rec['sha256']
        fn=precision_recall_curve if row['variant']=='installed_current' else functions[row['variant']][0]
        actual,_=actual_table(fn,y,s);gold=candidates(y,s,DEFAULT);lo=Fraction(3,10);hi=Fraction(9,10)
        br=sorted({lo,hi}|{p for p,*_ in actual+gold if lo<p<hi});pp=sorted(set(br)|{(a+b)/2 for a,b in zip(br,br[1:])})
        assert c['critical_values']==list(map(str,br)) and [r['alpha'] for r in c['probes']]==list(map(str,pp))
        lookup={}
        for r in c['probes']:
            a=Fraction(r['alpha']);e=select(gold,a,True,DEFAULT);v=select(actual,a,True,DEFAULT);xor=e[2]^v[2];lookup[a]=bool(xor)
            assert r['expected_bits']==hex(e[2]) and r['actual_bits']==hex(v[2]) and r['equal']==(not xor)
            assert r['expected_n']==e[1] and r['actual_n']==v[1]
            if xor:
                i=(xor&-xor).bit_length()-1;assert r['witness_id']==ids[i]
            else:assert r['witness_id'] is None
            probes+=1
        length=sum((b-a for a,b in zip(br,br[1:]) if lookup[(a+b)/2]),Fraction(0))
        assert Fraction(c['psc_exact'])==length/(hi-lo) and c['equivalent']==(not any(lookup.values()))
        assert (not c['equivalent'])==(row['policy_divergent']=='True');certificates+=1
    failures=json.loads((R/'failure_results.json').read_text());assert len(failures)==15
    for f in (R/'failure_fixtures').glob('*.py'):
        out=admission_result(f.read_text(encoding='utf-8'));assert out['status']=='UNSUPPORTED' and not out['certified']
    assert all(f['status']=='UNSUPPORTED' and not f['certified'] for f in failures)
    ci=list(csv.DictReader((R/'ci_timings.csv').open()));assert len(ci)==60 and all(int(r['exit_code']) in [0,1] and float(r['process_ms'])>=float(r['gate_ms']) for r in ci)
    smt=list(csv.DictReader((R/'smt_results.csv').open()));assert len(smt)==279
    verdict={(r['case_id'],r['variant']):r['policy_divergent']=='True' for r in results}
    # Re-run the persisted SMT-LIB tasks, not just a saved PASS flag.
    for (cid,variant),bad in verdict.items():
        solver=z3.SolverFor('QF_LRA');solver.set(timeout=5000)
        # Python handles Unicode paths; the solver parser receives SMT text.
        solver.from_string((R/'smt_queries'/f'{cid}_{variant}.smt2').read_text(encoding='utf-8'));answer=solver.check()
        assert answer!=z3.unknown and (answer==z3.sat)==bad
    for r in smt:
        assert (r['z3_result']=='sat')==verdict[(r['case_id'],r['variant'])]
        if r['model_alpha']:
            rec=records[r['case_id']];d=np.load(Q/'inputs/external_sut'/rec['file']);gold=candidates(d['y'],d['scores'],DEFAULT);fn=precision_recall_curve if r['variant']=='installed_current' else functions[r['variant']][0];actual,_=actual_table(fn,d['y'],d['scores']);a=Fraction(r['model_alpha']);assert select(gold,a,True,DEFAULT)[2]!=select(actual,a,True,DEFAULT)[2]
    result={'status':'PASS','external_certificates_replayed':certificates,'external_policy_probes':probes,'failure_modes_rejected':len(failures),'ci_process_measurements':len(ci),'smt_records_verified':len(smt),'smtlib_tasks_resolved':len(verdict),'old_v2_status':'The unchanged core results remain separate; executed-program adapter has additionally been hardened and rerun.'}
    (R/'validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
