"""Focus the main paper on the contract, diagnostics and verified domain reuse."""
import json,re

def integrate(Q,text):
    summary=json.loads((Q/'results/v7/domain_query_summary.json').read_text(encoding='utf-8'))
    # Preserve complete removed sections in a source-backed supplement.
    supplement=['# Supplementary experimental protocols and evidence for Q1 V7',
        'These sections retain the earlier experimental detail. They complement the main paper and the formal specification, proofs, raw records and executable audits distributed in the artifact. Timing protocols and cohorts remain separate.']
    moves=[('Fresh dependency version executions','Version outputs, numerical bridges and the distinction between policy differences and defects are detailed in Supplement S1.'),
           ('Program conformance and the semantic information boundary','Supplement S2 documents source admission and the distinction between observed conformance and inference of an arbitrary program specification.'),
           ('Matched-input implementation costs','Supplement S3 retains the preparation-matched implementation timing protocol. Its methods have different diagnostic scope and are not a capability-adjusted speed ranking.'),
           ('Algorithmic cost decomposition','Supplement S4 reports the within-invocation phase ablation. Component medians need not sum to the median total.'),
           ('Fail closed when program assumptions are unsupported','Supplement S5 documents unsupported-source fixtures, runtime refusals and CLI exit semantics. Refusal is never interpreted as equivalence.'),
           ('Local CI execution and frequency context','Supplement S6 reports actual local subprocess invocations. There is no remote CI, deployment SLO or measured policy-frequency claim.'),
           ('Onboarding a public external selector beyond the source allowlist','Supplement S7 documents the executed TunedThresholdClassifierCV public-API adapter, its exact scorer and configuration refusals. It is another component of scikit-learn, not an additional independent project.'),
           ('Direct SMT baseline on the same equivalence contract','Supplement S8 retains the 93-task Boolean SMT study. The complete-region comparisons and policy-domain query study address richer matched outputs separately.'),
           ('Reproduction and assurance levels','Supplement S9 details the historical standalone repair, frozen-input execution, optional retraining and the limits of each assurance layer.')]
    for number,(heading,replacement) in enumerate(moves,1):
        pattern=r'### '+re.escape(heading)+r'\n.*?(?=\n##|\Z)';match=re.search(pattern,text,re.S);assert match,heading
        supplement.append('## S'+str(number)+' '+heading+'\n\n'+match.group().split('\n',1)[1].strip())
        text=text[:match.start()]+replacement+'\n\n'+text[match.end():]
    text=text.replace('Research manuscript V6 revised','Research manuscript V7 revised')
    # Historic references remain in their individual study contexts.
    old='### Immutable final-archive reproduction'
    start=text.index(old);end=text.index('### Precise contribution relative to nearby methods',start)
    text=text[:start]+'''### Immutable final archive evidence

The exact V6 research archive has SHA-256 ec708e725b6ee0f369c156ddaec401f6bdcc8d8ad0681d1e8026638096128de0. Its detached report records all 27 stages passing, 1,630 verified manifest entries and unchanged before/after archive hashes. The full report, environment, logs and output digests are now included under evidence/V6_FINAL_RELEASE_EVIDENCE. This closes the prior handoff gap; a reviewer's partial execution is still not relabeled full independent reproduction.

V7 adds the domain-query study and audit for 29 default stages. The frozen research ZIP and its detached execution report are distributed together in the DELIVERY archive. The final V7 verdict belongs to that report, which is generated after freezing the research ZIP. The reading copy retains its measured snapshot; new timing records and rebuilt Markdown are separately supplied from the final extraction. These are author-side local executions, not independent institutional or remote-CI replications.

'''+text[end:]
    rows=[]
    names={'grid13':'Thirteen-point grid','declared_three':'Declared set {0.50,0.80,0.90}','decimal2':'Decimal lattice 2 places','decimal3':'Decimal lattice 3 places','decimal4':'Decimal lattice 4 places','decimal6':'Decimal lattice 6 places','whole_interval':'Closed interval [0.30,0.90]','high_interval':'Closed interval [0.80,0.90]'}
    for r in summary['by_query']:
        count='Continuous' if r['allowed_count_per_workload'] is None else f"{r['allowed_count_per_workload']:,}"
        hits='Not a finite count' if r['affected_policy_workload_pairs'] is None else f"{r['affected_policy_workload_pairs']:,}"
        rows.append(f"| {names[r['query']]} | {count} | {r['affected_workloads']} / 36 | {hits} |")
    section='''### Verified reuse for declared policy domains

A positive grid result answers whether a tested policy exhibits a difference. A release decision may instead ask which allowed targets are affected, whether every target in a proposed interval is safe, or whether a changed permitted set still intersects a previously diagnosed difference. We implement an explicit rational-domain query interface after independent input-bound certificate verification. It accepts finite sets, decimal lattices and intervals with declared endpoint ownership; it returns affected counts for finite domains or exact intersected cells for intervals, plus a rational witness when affected. Tampered input, an out-of-domain request and a binary64 query passed to the rational interface are refused. The result is conditional on the frozen inputs, admitted selector contract and successful certificate verification.

We predeclare eight scenarios and apply every one to all 36 existing SciPy affected-source workloads, without selecting for query outcomes. The finite set {0.50,0.80,0.90}, decimal lattices on [0.30,0.90], and continuous intervals are study scenarios, not elicited requirements from deployed applications. Original interpolation code is executed once per variant/workload to obtain the scores. Certificates are then independently checked before reuse. Direct mask enumeration uses those cached executed outputs and separately prepared candidate masks; it does not rerun interpolation for every target.

| Allowed policy scenario | Policies per workload | Workloads with an affected target | Affected policy/workload pairs |
|---|---|---|---|
'''+ '\n'.join(rows)+'''

All 288 query answers agree with a direct Z3 encoding constructed from independently enumerated candidate masks, not from certificate regions. The SMT objective compares selected-ID bitsets, so differing score orderings remain covered. A lattice uses an integer policy index; an interval uses a real policy variable. SAT supplies a rational witness checked against direct selection, UNSAT establishes absence for that encoded query, and timeout/unknown aborts the study. No unknown occurs. Exhaustive enumeration of both finite sets and the two- and three-place lattices checks 24,408 policies and agrees on all affected counts. Four- and six-place counts come from exact lattice intersection, not millions of API calls. Per-query records retain descriptive single-invocation costs and separately measured initial verification; they are not a repeated timing benchmark or an amortization/speed claim.

For pipeline_axis_generated_rf_quantized_seed7, the continuous interval is affected but the declared three-element set is not. Thus a domain-specific report can support accepting that scenario's finite policy set while continuing to report non-equivalence elsewhere. This does not make that policy set a real deployment requirement, nor does it show a new defect missed by grid. On both documented defects the thirteen-point grid already detects every affected workload. The added evidence concerns exact scope, counts, boundaries and reuse of a checked diagnostic object.

General SMT can answer the same questions and agrees here. For a fixed small finite set, exhaustive direct testing is complete for that set and can be the simpler engineering choice. A checked certificate is a useful reusable representation when multiple rational-domain queries or exact localization are required; its net cost depends on construction, verification, storage and query volume. We have not measured developer triage benefit, a deployment break-even point, or superiority over an independently optimized parametric verification tool. This study supports functional diagnostic utility and explicit limitations, rather than a broader real-bug detection claim.

'''
    text=text.replace('## 10. Threats to validity',section+'## 10. Threats to validity',1)
    text=text.replace('## 12. Conclusion\n\n','## 12. Conclusion\n\nThe added domain-query interface produces 288 answers matching SMT, with 24,408 direct policy checks. It makes permitted-domain diagnosis executable after certificate verification; it establishes functional reuse on controlled fixtures, while developer benefit and deployment break-even remain unmeasured.\n\n',1)
    text=text.replace('The contribution is scoped contract-aware diagnosis and independently checkable evidence,','A further 288 declared-policy-domain queries agree with SMT and 24,408 direct policy checks. The contribution is scoped contract-aware diagnosis and independently checkable evidence,')
    (Q/'docs/SUPPLEMENT_Q1_V7.md').write_text('\n\n'.join(supplement)+'\n',encoding='utf-8')
    return text

def vietnamese_report(Q):
    return '''# Kết quả Q1 V7 ngày 30 tháng 10 năm 2026

V7 thu gọn bản chính và chuyển các giao thức phụ sang SUPPLEMENT_Q1_V7. Nghiên cứu mới dùng toàn bộ 36 workload SciPy có sẵn, tám kịch bản policy được khai báo trong nghiên cứu, 288 truy vấn khớp SMT và 24.408 chính sách được liệt kê trực tiếp. Không tính thêm lỗi upstream hay deployment. Công cụ truy vấn kiểm tra certificate gắn với input trước khi trả lời finite-set/lattice/interval, giữ đúng điểm biên và từ chối nhầm ngữ nghĩa rational/binary64.

Chứng cứ chạy đúng ZIP V6 đủ 27/27 stages nay nằm ngay trong evidence/V6_FINAL_RELEASE_EVIDENCE. V7 có 29 default stages; verdict trên đúng ZIP cuối nằm trong detached report và DELIVERY. Hai lỗi upstream vẫn được grid phát hiện đủ; không có claim tăng real-bug detection, ưu thế solver tổng quát, hiệu quả developer triage hay bảo đảm được nhận Q1. Hồ sơ Q2 gốc được giữ nguyên.
'''
