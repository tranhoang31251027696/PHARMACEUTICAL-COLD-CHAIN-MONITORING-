"""Additional explicit provenance checks for each external certificate."""
from pathlib import Path
import json,csv,hashlib
Q=Path(__file__).resolve().parent

def main():
    source=Q/'vendor/external_sklearn';m=json.loads((source/'SOURCE_MANIFEST.json').read_text(encoding='utf-8'))
    for rec in m.values():
        for name,meta in rec['files'].items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==meta['sha256']
    variants={'affected':'1.0.2','fixed':'23214_merged'};rows=list(csv.DictReader((Q/'results/v3/external_sut_results.csv').open(encoding='utf-8')))
    for row in rows:
        c=json.loads((Q/row['certificate_file']).read_text(encoding='utf-8'))
        assert c['schema']=='external-upstream-candidate-conformance/1' and c['issue']=='scikit-learn#23213'
        assert c['case_id']==row['case_id'] and c['variant']==row['variant'] and c['domain']==['3/10','9/10']
        assert c['historical_binary_execution'] is False
        if row['variant']=='installed_current':assert c['source_sha256'] is None and c['upstream_commit'] is None
        else:
            rec=m[variants[row['variant']]];name=next(n for n in rec['files'] if n.endswith('_ranking.py'))
            assert c['source_sha256']==rec['files'][name]['sha256'] and c['upstream_commit']==rec['commit']
    result={'status':'PASS','external_certificates_source_and_domain_bound':len(rows),'upstream_snapshots_hash_checked':len(m),'historical_binary_execution_claimed':False}
    (Q/'results/v3/external_binding_validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
