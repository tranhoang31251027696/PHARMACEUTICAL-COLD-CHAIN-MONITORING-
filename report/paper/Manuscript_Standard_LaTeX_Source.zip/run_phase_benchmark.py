"""
Phase-level benchmark comparing Boundary-Aware Direct Probing with Proposed Framework.
Measures:
- Preprocessing (sorting scores, candidate extraction)
- Core Search / Sweep:
    - Direct Boundary Probing (exhaustive evaluation of all 2K-1 canonical atoms without heap sweep)
    - Sweep Producer (heap-based monotone sweep + prefix rank checks)
- Certificate Assembly, Witness Extraction, and SHA-256 Input Digest
- Independent Streaming Verification
- Sub-domain Query Lattice Reuse
Across randomized repetitions with median and IQR reporting.
"""
import sys, time, json, hashlib, csv, argparse
from pathlib import Path
from fractions import Fraction
import numpy as np

# Resolve project / artifact root
script_dir = Path(__file__).resolve().parent
if (script_dir / 'src' / 'policy_exact.py').exists():
    APP_ROOT = script_dir
elif (script_dir.parent / 'src' / 'Q1' / 'src' / 'policy_exact.py').exists():
    APP_ROOT = script_dir.parent / 'src' / 'Q1'
else:
    APP_ROOT = script_dir

sys.path.insert(0, str(APP_ROOT))
sys.path.insert(0, str(APP_ROOT / 'src'))
sys.path.insert(0, str(APP_ROOT / 'vendor'))

from policy_exact import inputs, profile, winner, compare_policies, DEFAULT, rational
from policy_domain_query import answer
from streaming_checker import verify as streaming_verify

def evaluate_direct_probing_core(y, a_order, a_cands, b_order, b_cands, B, N, spec_a, spec_b):
    """
    Direct boundary probing operating on precomputed candidate descriptors.
    Exhaustively checks all 2K-1 canonical atoms: K boundary singletons and K-1 open-atom midpoints.
    For each probe, scans candidates linearly to find max TP,
    reconstructs selected bitsets, and checks equality.
    """
    diff_count = 0
    # Probe all K singletons
    for pt in B:
        best_a = None
        for c in a_cands:
            valid = c['p'] >= pt if spec_a['precision'] == 'inclusive' else c['p'] > pt
            if valid:
                key = (c['tp'], c['n'] if spec_a['objective'] == 'max_tp_max_n' else -c['n'])
                if best_a is None or key > best_a[0]:
                    best_a = (key, c['n'])
        na = best_a[1] if best_a else 0
        
        best_b = None
        for c in b_cands:
            valid = c['p'] >= pt if spec_b['precision'] == 'inclusive' else c['p'] > pt
            if valid:
                key = (c['tp'], c['n'] if spec_b['objective'] == 'max_tp_max_n' else -c['n'])
                if best_b is None or key > best_b[0]:
                    best_b = (key, c['n'])
        nb = best_b[1] if best_b else 0
        
        if na != nb:
            diff_count += 1
        elif na > 0:
            ma = np.zeros(N, bool); ma[a_order[:na]] = True
            mb = np.zeros(N, bool); mb[b_order[:nb]] = True
            if not np.array_equal(ma, mb):
                diff_count += 1
                
    # Probe all K-1 midpoints
    for i in range(1, len(B)):
        mid = (B[i-1] + B[i]) / 2
        best_a = None
        for c in a_cands:
            valid = c['p'] >= mid if spec_a['precision'] == 'inclusive' else c['p'] > mid
            if valid:
                key = (c['tp'], c['n'] if spec_a['objective'] == 'max_tp_max_n' else -c['n'])
                if best_a is None or key > best_a[0]:
                    best_a = (key, c['n'])
        na = best_a[1] if best_a else 0
        
        best_b = None
        for c in b_cands:
            valid = c['p'] >= mid if spec_b['precision'] == 'inclusive' else c['p'] > mid
            if valid:
                key = (c['tp'], c['n'] if spec_b['objective'] == 'max_tp_max_n' else -c['n'])
                if best_b is None or key > best_b[0]:
                    best_b = (key, c['n'])
        nb = best_b[1] if best_b else 0
        
        if na != nb:
            diff_count += 1
        elif na > 0:
            ma = np.zeros(N, bool); ma[a_order[:na]] = True
            mb = np.zeros(N, bool); mb[b_order[:nb]] = True
            if not np.array_equal(ma, mb):
                diff_count += 1
                
    return diff_count

def run_phase_benchmark(repetitions=5, out_raw=None, out_summary=None):
    manifest_path = APP_ROOT / 'inputs/manifest.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    
    # 4 distinct representative cohorts
    target_cohorts = [
        ('WDBC (N=143)', 'wdbc_logistic_isotonic_seed0'),
        ('Digits (N=450)', 'digits_svc_sigmoid_seed0'),
        ('Generated RF (N=600)', 'generated_rf_quantized_seed0'),
        ('Plain Cold-Chain (N=37,471)', 'plain_6h__manual_float64_endpoint')
    ]
    
    cases = []
    for label, cid in target_cohorts:
        c = next(x for x in manifest['cases'] if x['case_id'] == cid)
        cases.append((label, c))
        
    raw_records = []
    summary_rows = []
    
    for label, case in cases:
        data_path = APP_ROOT / 'inputs' / case['file']
        data = np.load(data_path)
        y = data['y']
        a = data['old']
        b = a.copy() # invariant baseline comparison
        ids = data['ids'].tolist()
        N = len(y)
        
        # Determine critical points count
        pa = profile(y, a, DEFAULT); pb = profile(y, b, DEFAULT)
        ratios_a = {c['p'] for c in pa['candidates'] if Fraction(3, 10) < c['p'] < Fraction(9, 10)}
        ratios_b = {c['p'] for c in pb['candidates'] if Fraction(3, 10) < c['p'] < Fraction(9, 10)}
        B = sorted({Fraction(3, 10), Fraction(9, 10)} | ratios_a | ratios_b)
        K = len(B)
        G = len(pa['candidates'])
        
        # Run repetitions
        rep_direct_core = []
        rep_sweep_core = []
        rep_cert_full = []
        rep_stream_check = []
        rep_reuse_us = []
        
        for rep in range(repetitions):
            # 1. Direct Probing Core (on precomputed candidates across 2K-1 probes)
            t0 = time.perf_counter_ns()
            diff_cnt = evaluate_direct_probing_core(y, pa['order'], pa['candidates'], pb['order'], pb['candidates'], B, N, DEFAULT, DEFAULT)
            t_direct = (time.perf_counter_ns() - t0) / 1e6
            rep_direct_core.append(t_direct)
            
            # 2. Sweep Producer Core + Cert Assembly (compare_policies)
            timings = {}
            t0 = time.perf_counter_ns()
            cert = compare_policies(y, a, b, lo='0.30', hi='0.90', ids=ids, new_spec=DEFAULT, with_witness=True, stage_timings=timings)
            t_cert_total = (time.perf_counter_ns() - t0) / 1e6
            t_sweep_core = timings.get('sweep_excluding_witness_ms', 0.0) + timings.get('witness_ms', 0.0)
            rep_sweep_core.append(t_sweep_core)
            rep_cert_full.append(t_cert_total)
            
            # 3. Streaming Independent Consumer Verification
            t0 = time.perf_counter_ns()
            streaming_verify(y, a, b, ids, cert)
            t_stream = (time.perf_counter_ns() - t0) / 1e6
            rep_stream_check.append(t_stream)
            
            # 4. Microsecond Query Reuse
            query = dict(semantics='rational', kind='interval', lo='0.50', hi='0.70', left_closed=True, right_closed=True)
            t0 = time.perf_counter_ns()
            res = answer(cert, query)
            t_reuse = (time.perf_counter_ns() - t0) / 1e3 # microseconds
            rep_reuse_us.append(t_reuse)
            
            raw_records.append({
                'cohort': label,
                'repetition': rep,
                'N': N,
                'G': G,
                'K': K,
                'canonical_atoms_probed': 2 * K - 1,
                'direct_probing_core_ms': t_direct,
                'sweep_producer_core_ms': t_sweep_core,
                'producer_total_cert_ms': t_cert_total,
                'streaming_verify_ms': t_stream,
                'reuse_us': t_reuse
            })
            
        def stats(arr):
            med = float(np.median(arr))
            q25, q75 = np.percentile(arr, [25, 75])
            iqr = float(q75 - q25)
            return med, iqr
            
        med_direct, iqr_direct = stats(rep_direct_core)
        med_sweep, iqr_sweep = stats(rep_sweep_core)
        med_cert, iqr_cert = stats(rep_cert_full)
        med_stream, iqr_stream = stats(rep_stream_check)
        med_reuse, iqr_reuse = stats(rep_reuse_us)
        
        speedup_core = med_direct / med_sweep if med_sweep > 0 else 1.0
        
        summary_rows.append({
            'cohort': label,
            'N': N,
            'G': G,
            'K': K,
            'canonical_atoms_probed': 2 * K - 1,
            'direct_probing_core_median_ms': med_direct,
            'direct_probing_core_iqr_ms': iqr_direct,
            'sweep_core_median_ms': med_sweep,
            'sweep_core_iqr_ms': iqr_sweep,
            'speedup_core': speedup_core,
            'producer_total_cert_median_ms': med_cert,
            'producer_total_cert_iqr_ms': iqr_cert,
            'streaming_verify_median_ms': med_stream,
            'streaming_verify_iqr_ms': iqr_stream,
            'reuse_us': med_reuse
        })

    print("=" * 120)
    print("PHASE-LEVEL COMPARISON: DIRECT BOUNDARY PROBING VS. SWEEP CERTIFICATE")
    print("=" * 120)
    print(f"{'Cohort':<26} | {'N':<6} | {'G':<5} | {'K':<4} | {'Direct Core (ms)':<16} | {'Sweep Core (ms)':<15} | {'Core Spd':<8} | {'Prod Full (ms)':<15} | {'StreamChk (ms)':<14}")
    print("-" * 120)
    for r in summary_rows:
        print(f"{r['cohort']:<26} | {r['N']:<6} | {r['G']:<5} | {r['K']:<4} | "
              f"{r['direct_probing_core_median_ms']:>6.2f} (IQR {r['direct_probing_core_iqr_ms']:>4.2f}) | "
              f"{r['sweep_core_median_ms']:>6.2f} (IQR {r['sweep_core_iqr_ms']:>4.2f}) | "
              f"{r['speedup_core']:>6.1f}x | "
              f"{r['producer_total_cert_median_ms']:>6.2f} (IQR {r['producer_total_cert_iqr_ms']:>4.2f}) | "
              f"{r['streaming_verify_median_ms']:>6.2f} (IQR {r['streaming_verify_iqr_ms']:>4.2f})")
    print("=" * 120)
    
    # Save CSV and JSON
    if out_raw is None:
        out_raw = script_dir / 'phase_benchmark_raw.csv'
    else:
        out_raw = Path(out_raw)
    out_raw.parent.mkdir(parents=True, exist_ok=True)
    with open(out_raw, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(raw_records[0].keys()))
        w.writeheader()
        w.writerows(raw_records)
        
    if out_summary is None:
        out_summary = script_dir / 'phase_benchmark_summary.json'
    else:
        out_summary = Path(out_summary)
    out_summary.parent.mkdir(parents=True, exist_ok=True)
    out_summary.write_text(json.dumps({
        'status': 'PASS',
        'repetitions': repetitions,
        'timing_metric': 'perf_counter_ns',
        'host': 'Windows x86_64, Python 3.11',
        'methodology_notes': {
            'canonical_atoms_probed': 'Exhaustively evaluates candidate descriptors at all 2K-1 canonical atoms (comprising K boundary singletons and K-1 open-atom midpoints). Reconstructs bitsets and compares IDs; excludes input hashing and certificate generation.',
            'sweep_core': 'Heap-sweep algorithm across K atoms with prefix-max rank comparisons; excludes input hashing and JSON serialization.',
            'producer_total_cert': 'Complete producer workflow including input validation, SHA-256 digest, sweep, witness extraction, and certificate formatting.',
            'streaming_verify': 'Independent consumer verification in O(1) simultaneously active masks with input digest verification and direct bitset checks.',
            'reuse_us': 'Sub-domain interval query answering from verified certificate in O(log(M+1)) rational operations.'
        },
        'summary': summary_rows
    }, indent=2), encoding='utf-8')
    print(f"Benchmark complete. Raw data saved to {out_raw.name}; summary saved to {out_summary.name}.")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Phase-level benchmark comparing direct probing and sweep certification.")
    parser.add_argument('--repetitions', type=int, default=5, help="Number of repetitions per cohort")
    parser.add_argument('--out-raw', type=str, default=None, help="Output path for raw records CSV")
    parser.add_argument('--out-summary', type=str, default=None, help="Output path for summary JSON")
    args = parser.parse_args()
    run_phase_benchmark(repetitions=args.repetitions, out_raw=args.out_raw, out_summary=args.out_summary)
